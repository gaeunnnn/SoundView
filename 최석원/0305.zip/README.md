
  # 특화

  This is a code bundle for 특화. The original project is available at https://www.figma.com/design/8ufmjsBJqnjuAKNJV1zadg/%ED%8A%B9%ED%99%94.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  