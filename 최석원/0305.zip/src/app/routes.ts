import { createBrowserRouter } from "react-router";
import { LoginPage } from "./components/login-page";
import { AppLayout } from "./components/app-layout";
import { DashboardPage } from "./components/dashboard-page";
import { CaptionPage } from "./components/caption-page";
import { ResultPage } from "./components/result-page";

export const router = createBrowserRouter([
  { path: "/", Component: LoginPage },
  { path: "/result", Component: ResultPage },
  { path: "/caption", Component: CaptionPage },
  {
    Component: AppLayout,
    children: [
      { path: "/dashboard", Component: DashboardPage },
    ],
  },
]);