import { useState, useEffect, useRef, forwardRef, useCallback } from "react";
import { useNavigate, useOutletContext } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { createVideoEditStateFromSounds, saveVideoEditState } from "../utils/video-state";
import {
  SlidersHorizontal,
  Play,
  MoreHorizontal,
  Plus,
  Upload,
  Wand2,
  Download,
  CheckCircle2,
  Clock,
  ChevronDown,
  X,
  Heart,
  Edit,
  Trash2,
  Share2,
  AlertTriangle,
  Check,
  Users,
  Pencil,
  FolderInput,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import type { LayoutContext } from "./app-layout";
import { DRIVES } from "./app-layout";
import type { CustomDrive } from "./app-layout";

// ── Images ───────────────────────────────────────────────────────────────────
const IMG_FIREWORK = "https://images.unsplash.com/photo-1753614982374-07f89c5024a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXJld29ya3MlMjBuaWdodCUyMHNreSUyMGZlc3RpdmFsfGVufDF8fHx8MTc3MjY0ODg3OHww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_ALLEY    = "https://images.unsplash.com/photo-1562829612-55b71f529a49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXJyb3clMjBhbGxleSUyMHN0cmVldCUyMGV2ZW5pbmclMjBrb3JlYXxlbnwxfHx8fDE3NzI2NzU0MTV8MA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_FOOD     = "https://images.unsplash.com/photo-1758779527927-56c21385ffce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMG1lYWwlMjBjaG9wc3RpY2tzJTIwcGxhdGUlMjByZXN0YXVyYW50fGVufDF8fHx8MTc3MjY3NTY4M3ww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_LATTE    = "https://images.unsplash.com/photo-1758180447681-970a25db7d98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWZlJTIwbGF0dGUlMjBhcnQlMjB0YWJsZSUyMGNvenl8ZW58MXx8fHwxNzcyNjc1NDE2fDA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_BRUNCH   = "https://images.unsplash.com/photo-1707222634706-e781864429fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicnVuY2glMjBwYW5jYWtlJTIwdGFibGUlMjBtb3JuaW5nfGVufDF8fHx8MTc3MjY3NTQyMHww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_RAINY    = "https://images.unsplash.com/photo-1638228236517-799a136763b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyYWlueSUyMHN0cmVldCUyMG5pZ2h0JTIwcmVmbGVjdGlvbiUyMHVyYmFufGVufDF8fHx8MTc3MjY3NTQxN3ww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_CAFE     = "https://images.unsplash.com/photo-1698548551773-ab5d78e994a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBjYWZlJTIwbGF0dGUlMjBjYXN1YWwlMjBzbWFydHBob25lfGVufDF8fHx8MTc3MjY3NTE1NHww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_SUNSET   = "https://images.unsplash.com/photo-1770021601385-af0bf0136762?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjByb29mdG9wJTIwY2l0eSUyMGV2ZW5pbmclMjBjYXN1YWx8ZW58MXx8fHwxNzcyNjc1NjgxfDA&ixlib=rb-4.1.0&q=80&w=400";

type SortKey = "최신순" | "오래된 순" | "이름 순" | "길이 순";

const ALL_VIDEOS = [
  { id: 1, title: "불꽃놀이",                thumb: IMG_FIREWORK, date: "2026.02.28", duration: "2:18",  owner: "my",    hasCaptions: true, liked: false },
  { id: 2, title: "퇴근길 골목 풍경",        thumb: IMG_ALLEY,    date: "2026.02.25", duration: "1:45",  owner: "my",    hasCaptions: true, liked: true  },
  { id: 3, title: "친구들이랑 저녁 먹는 중",  thumb: IMG_FOOD,     date: "2026.02.20", duration: "2:10",  owner: "my",    hasCaptions: true, liked: false },
  { id: 4, title: "카페에서 라떼 한 잔",      thumb: IMG_LATTE,    date: "2026.02.18", duration: "0:58",  owner: "my",    hasCaptions: true, liked: true  },
  { id: 5, title: "주말 브런치",              thumb: IMG_BRUNCH,   date: "2026.02.15", duration: "1:23",  owner: "my",    hasCaptions: true, liked: false },
  { id: 6, title: "카페에서 찍은 짧은 영상",  thumb: IMG_CAFE,     date: "2026.02.10", duration: "1:42",  owner: "jieun", hasCaptions: true, liked: true  },
  { id: 7, title: "옥상에서 본 노을",         thumb: IMG_SUNSET,   date: "2026.02.08", duration: "1:35",  owner: "junho", hasCaptions: true, liked: false },
  { id: 8, title: "비 오는 날 거리",          thumb: IMG_RAINY,    date: "2026.02.01", duration: "2:07",  owner: "my",    hasCaptions: true, liked: true  },
];

// Mock timeline data for each video (simulating detected sounds)
const MOCK_SOUNDS = [
  { id: 0, time: "00:03", emoji: "🐶", text: "강아지 짖음" },
  { id: 1, time: "00:12", emoji: "🚪", text: "문 닫히는 소리" },
  { id: 2, time: "00:28", emoji: "🎵", text: "배경음악 시작" },
  { id: 3, time: "00:45", emoji: "👏", text: "박수 소리" },
  { id: 4, time: "01:03", emoji: "🪟", text: "유리 깨지는 소리" },
  { id: 5, time: "01:18", emoji: "📞", text: "전화벨 소리" },
  { id: 6, time: "01:35", emoji: "🌧️", text: "빗소리" },
  { id: 7, time: "02:01", emoji: "🎤", text: "노래 소리" },
  { id: 8, time: "02:30", emoji: "💨", text: "바람 소리" },
  { id: 9, time: "02:55", emoji: "🦅", text: "새 소리" },
];

// ── Video Card ───────────────────────────────────────────────────────────────
type VideoCardProps = {
  video: typeof ALL_VIDEOS[0]; 
  onPlay: () => void;
  activeDriveId: string;
  onLikeToggle: (id: number) => void;
  onEdit?: (video: typeof ALL_VIDEOS[0]) => void;
  onShare?: (video: typeof ALL_VIDEOS[0]) => void;
  onDelete?: (video: typeof ALL_VIDEOS[0]) => void;
  onRenameTitle?: (videoId: number, newTitle: string) => void;
  isMenuOpen: boolean;
  onToggleMenu: (videoId: number) => void;
  onCloseMenu: () => void;
};

const VideoCard = forwardRef<HTMLDivElement, VideoCardProps>(function VideoCard({ 
  video, 
  onPlay, 
  activeDriveId, 
  onLikeToggle,
  onEdit,
  onShare,
  onDelete,
  onRenameTitle,
  isMenuOpen,
  onToggleMenu,
  onCloseMenu,
}, ref) {
  const [isLiked, setIsLiked] = useState(video.liked);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editTitleValue, setEditTitleValue] = useState(video.title);
  const titleInputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  
  const isMyDrive = activeDriveId === "my";
  const isFriendDrive = activeDriveId !== "my";
  
  // Show edit/delete menu for ALL videos in my drive
  const showEditMenu = isMyDrive;
  
  // Show like button only in friend drives
  const showLikeButton = isFriendDrive;
  
  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
    onLikeToggle(video.id);
  };

  // Close menu on outside click
  useEffect(() => {
    if (!isMenuOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onCloseMenu();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isMenuOpen, onCloseMenu]);

  // Focus input when editing starts
  useEffect(() => {
    if (isEditingTitle && titleInputRef.current) {
      titleInputRef.current.focus();
      titleInputRef.current.select();
    }
  }, [isEditingTitle]);

  const handleTitleEditStart = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditTitleValue(video.title);
    setIsEditingTitle(true);
  };

  const handleTitleSave = () => {
    const trimmed = editTitleValue.trim();
    if (trimmed && trimmed !== video.title) {
      onRenameTitle?.(video.id, trimmed);
    }
    setIsEditingTitle(false);
  };

  const handleTitleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleTitleSave();
    } else if (e.key === "Escape") {
      setEditTitleValue(video.title);
      setIsEditingTitle(false);
    }
  };

  return (
    <motion.div
      ref={ref}
      className="bg-white rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all group cursor-pointer"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
      transition={{ duration: 0.25 }}
      layout
      onClick={onPlay}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden bg-slate-100 rounded-t-xl">
        <ImageWithFallback
          src={video.thumb}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
        />
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/25 transition-colors flex items-center justify-center">
          <button
            onClick={onPlay}
            className="w-9 h-9 rounded-full bg-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
          >
            <Play className="w-3.5 h-3.5 text-slate-800 ml-0.5" />
          </button>
        </div>
        {/* Duration */}
        <div
          className="absolute bottom-2 right-2 bg-slate-900/70 text-white rounded-md px-1.5 py-0.5 backdrop-blur-sm"
          style={{ fontSize: "0.62rem" }}
        >
          <Clock className="w-2 h-2 inline mr-0.5 opacity-70" />
          {video.duration}
        </div>
        
        {/* Like button (Friend drives only) */}
        {showLikeButton && (
          <button
            onClick={handleLikeClick}
            className={`absolute top-2 left-2 w-7 h-7 rounded-full backdrop-blur-md flex items-center justify-center transition-all ${
              isLiked 
                ? "bg-red-500 text-white" 
                : "bg-white/90 text-slate-400 hover:text-red-500"
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked ? "fill-current" : ""}`} />
          </button>
        )}
      </div>

      {/* Info */}
      <div className="px-3 py-2.5">
        <div className="flex items-start justify-between gap-1">
          {isEditingTitle ? (
            <input
              ref={titleInputRef}
              type="text"
              value={editTitleValue}
              onChange={(e) => setEditTitleValue(e.target.value)}
              onBlur={handleTitleSave}
              onKeyDown={handleTitleKeyDown}
              onClick={(e) => e.stopPropagation()}
              className="text-slate-800 flex-1 min-w-0 bg-slate-50 border border-blue-300 rounded-md px-1.5 py-0.5 outline-none ring-2 ring-blue-100"
              style={{ fontSize: "0.82rem" }}
            />
          ) : (
            <div className="flex items-center gap-1 flex-1 min-w-0">
              <p className="text-slate-800 truncate" style={{ fontSize: "0.82rem" }}>
                {video.title}
              </p>
              {isMyDrive && (
                <button
                  onClick={handleTitleEditStart}
                  className="shrink-0 w-5 h-5 flex items-center justify-center rounded text-slate-300 hover:text-blue-500 hover:bg-blue-50 transition-colors opacity-0 group-hover:opacity-100"
                  aria-label="제목 수정"
                >
                  <Pencil className="w-3 h-3" />
                </button>
              )}
            </div>
          )}
          
          {/* ⋯ menu button — always visible for all cards in my drive */}
          {showEditMenu && (
            <div className="relative shrink-0" ref={menuRef}>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  onToggleMenu(video.id);
                }}
                className="w-6 h-6 flex items-center justify-center rounded-md hover:bg-slate-100 active:bg-slate-200 transition-colors text-slate-400 hover:text-slate-600"
                style={{ pointerEvents: "auto" }}
                aria-label="영상 메뉴"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>

              {/* Dropdown menu */}
              {isMenuOpen && (
                <div
                  className="absolute right-0 top-7 w-32 bg-white border border-slate-200 rounded-xl py-1 z-[60]"
                  style={{
                    boxShadow: "0 8px 30px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06)",
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseMenu();
                      onEdit?.(video);
                    }}
                    className="flex items-center gap-2.5 w-full text-left px-3.5 py-2 hover:bg-slate-50 transition-colors text-slate-700"
                    style={{ fontSize: "0.8rem" }}
                  >
                    <Edit className="w-3.5 h-3.5 text-slate-400" />
                    편집
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseMenu();
                      onShare?.(video);
                    }}
                    className="flex items-center gap-2.5 w-full text-left px-3.5 py-2 hover:bg-slate-50 transition-colors text-slate-700"
                    style={{ fontSize: "0.8rem" }}
                  >
                    <Share2 className="w-3.5 h-3.5 text-slate-400" />
                    공유
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseMenu();
                      onDelete?.(video);
                    }}
                    className="flex items-center gap-2.5 w-full text-left px-3.5 py-2 hover:bg-red-50 transition-colors text-red-500"
                    style={{ fontSize: "0.8rem" }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    삭제
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-slate-400" style={{ fontSize: "0.7rem" }}>
            {video.date}
          </span>
          {video.owner !== "my" && (
            <span
              className="bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded"
              style={{ fontSize: "0.65rem" }}
            >
              {video.owner === "jieun" ? "김지은" : "박준호"}
            </span>
          )}
          {!video.hasCaptions && (
            <span className="ml-auto text-slate-300" style={{ fontSize: "0.65rem" }}>
              자막 없음
            </span>
          )}
        </div>
      </div>
    </motion.div>
  );
});

// ── Delete Confirmation Dialog ────────────────────────────────────────────────
function DeleteConfirmDialog({
  videoTitle,
  onConfirm,
  onCancel,
}: {
  videoTitle: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40" onClick={onCancel} />

      {/* Dialog */}
      <motion.div
        className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-200 w-[360px] overflow-hidden"
        initial={{ scale: 0.92, opacity: 0, y: 10 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 5 }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
      >
        <div className="px-6 pt-6 pb-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center shrink-0">
              <Trash2 className="w-5 h-5 text-red-500" />
            </div>
            <h3 className="text-slate-900" style={{ fontSize: "1rem" }}>
              영상 삭제
            </h3>
          </div>
          <p className="text-slate-500 ml-[52px]" style={{ fontSize: "0.85rem", lineHeight: "1.5" }}>
            이 영상을 삭제하시겠습니까?
          </p>
          <p className="text-slate-400 ml-[52px] mt-1 truncate" style={{ fontSize: "0.78rem" }}>
            "{videoTitle}"
          </p>
        </div>

        <div className="flex items-center gap-2 px-6 pb-5 pt-2 justify-end">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            style={{ fontSize: "0.82rem" }}
          >
            취소
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white transition-colors shadow-sm"
            style={{ fontSize: "0.82rem" }}
          >
            삭제
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ── Dashboard Page ────────────────────────────────────────────────────────────
export function DashboardPage() {
  const { activeDriveId, customDrives, driveRenames } = useOutletContext<LayoutContext>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("전체 영상");
  const [sortOpen, setSortOpen] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>("최신순");
  const [fabOpen, setFabOpen] = useState(false);
  const [deletedIds, setDeletedIds] = useState<number[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<typeof ALL_VIDEOS[0] | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [menuOpen, setMenuOpen] = useState<number | null>(null);
  const [shareTarget, setShareTarget] = useState<typeof ALL_VIDEOS[0] | null>(null);
  const [selectedDriveId, setSelectedDriveId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "info">("success");
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importSelectedIds, setImportSelectedIds] = useState<number[]>([]);
  const [showMembersPopover, setShowMembersPopover] = useState(false);
  const membersButtonRef = useRef<HTMLButtonElement>(null);
  const membersPopoverRef = useRef<HTMLDivElement>(null);
  
  // Close members popover on outside click
  useEffect(() => {
    if (!showMembersPopover) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (
        membersPopoverRef.current && !membersPopoverRef.current.contains(e.target as Node) &&
        membersButtonRef.current && !membersButtonRef.current.contains(e.target as Node)
      ) {
        setShowMembersPopover(false);
      }
    };
    // Use requestAnimationFrame to avoid the opening click from immediately closing
    const raf = requestAnimationFrame(() => {
      document.addEventListener("click", handleClickOutside, true);
    });
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, [showMembersPopover]);

  // Show toast helper
  const showToast = useCallback((message: string, type: "success" | "info" = "success") => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    setToastMessage(message);
    setToastType(type);
    toastTimerRef.current = setTimeout(() => setToastMessage(null), 3000);
  }, []);

  // Cleanup toast timer
  useEffect(() => {
    return () => {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    };
  }, []);

  // Handler to open Result Player with video data
  const openResultPlayer = (video: typeof ALL_VIDEOS[0]) => {
    // If the video has saved timeline/emojiOn (from prior editing), use that data
    const savedVideo = video as any;
    let videoEditState;

    if (savedVideo.timeline && savedVideo.timeline.length > 0) {
      // Video was previously edited and saved — restore its exact state
      videoEditState = {
        version: 3,
        videoId: `video-${video.id}`,
        videoTitle: video.title,
        videoThumbnail: video.thumb,
        videoSource: video.thumb,
        timeline: savedVideo.timeline,
        emojiOn: savedVideo.emojiOn ?? true,
        captionOn: true,
        sensitivity: 70,
        captionStyle: "기본",
        duration: 754,
      };
    } else {
      videoEditState = createVideoEditStateFromSounds(
        MOCK_SOUNDS,
        {
          videoId: `video-${video.id}`,
          videoTitle: video.title,
          videoThumbnail: video.thumb,
          videoSource: video.thumb,
          emojiOn: true,
          captionOn: true,
          sensitivity: 70,
          captionStyle: "기본",
          duration: 754,
        }
      );
    }
    
    saveVideoEditState(videoEditState);
    navigate("/result", { state: videoEditState });
  };

  // Handle edit — same as play (opens result player for editing)
  const handleEdit = (video: typeof ALL_VIDEOS[0]) => {
    openResultPlayer(video);
  };

  // Handle share — open share modal
  const handleShareRequest = (video: typeof ALL_VIDEOS[0]) => {
    setShareTarget(video);
    setSelectedDriveId(null);
  };

  // Confirm share
  const handleShareConfirm = () => {
    if (!shareTarget || !selectedDriveId) return;

    // Duplicate video data into the selected friend drive
    const sharedVideosKey = `sharedVideos_${selectedDriveId}`;
    const existingJson = localStorage.getItem(sharedVideosKey);
    const existing = existingJson ? JSON.parse(existingJson) : [];
    
    // Create a copy with a new unique id and the friend as owner
    const sharedCopy = {
      ...shareTarget,
      id: Date.now(), // unique id for the copy
      owner: selectedDriveId,
      date: new Date().toISOString().slice(0, 10).replace(/-/g, "."),
    };
    existing.push(sharedCopy);
    localStorage.setItem(sharedVideosKey, JSON.stringify(existing));

    setShareTarget(null);
    setSelectedDriveId(null);
    showToast("선택한 드라이브에 공유되었습니다.", "success");
  };

  // Handle delete — show confirmation (does NOT actually delete)
  const handleDeleteRequest = (video: typeof ALL_VIDEOS[0]) => {
    setDeleteTarget(video);
  };

  // Confirm delete — actually remove the video
  const handleDeleteConfirm = () => {
    if (!deleteTarget) return;
    setDeletedIds(prev => [...prev, deleteTarget.id]);
    // Also remove from localStorage savedVideos if present
    const savedJson = localStorage.getItem('savedVideos');
    if (savedJson) {
      const saved = JSON.parse(savedJson);
      const filtered = saved.filter((v: any) => v.id !== deleteTarget.id);
      localStorage.setItem('savedVideos', JSON.stringify(filtered));
    }
    showToast(`"${deleteTarget.title}" 영상이 삭제되었습니다.`, "success");
    setDeleteTarget(null);
    setRefreshKey(prev => prev + 1);
  };

  // Load saved videos from localStorage
  const savedVideosJson = localStorage.getItem('savedVideos');
  const savedVideos = savedVideosJson ? JSON.parse(savedVideosJson) : [];

  // Load persisted title renames
  const renamedJson = localStorage.getItem('renamedTitles');
  const renamedTitles: Record<number, string> = renamedJson ? JSON.parse(renamedJson) : {};
  
  // Combine saved videos with initial videos, excluding deleted ones,
  // and apply any persisted title renames
  const allVideos = [...savedVideos, ...ALL_VIDEOS]
    .filter(v => !deletedIds.includes(v.id))
    .map(v => renamedTitles[v.id] ? { ...v, title: renamedTitles[v.id] } : v);

  const isMyDrive = activeDriveId === "my";

  let filtered = allVideos.filter((v) => {
    if (activeDriveId === "my") return v.owner === "my" || v.liked;
    return v.owner === activeDriveId;
  });
  if (activeTab === "내가 만든 영상") filtered = filtered.filter((v) => v.owner === "my");
  if (activeTab === "좋아요 누른 영상") filtered = filtered.filter((v) => v.liked);

  const sorted = [...filtered].sort((a, b) => {
    if (sortKey === "이름 순") return a.title.localeCompare(b.title);
    if (sortKey === "오래된 순") return a.date.localeCompare(b.date);
    if (sortKey === "길이 순") return b.duration.localeCompare(a.duration);
    return b.date.localeCompare(a.date);
  });

  // Different tabs for "내 드라이브" vs "공유 드라이브"
  const TABS = isMyDrive 
    ? ["전체 영상", "좋아요 누른 영상"]
    : ["전체 영상", "내가 만든 영상"];
  const SORT_OPTIONS: SortKey[] = ["최신순", "오래된 순", "이름 순", "길이 순"];

  const fabActions = isMyDrive
    ? [
        { label: "변환하기", icon: Wand2, key: "convert" as const, style: "bg-blue-600 text-white hover:bg-blue-700 shadow-md shadow-blue-200" },
      ]
    : [
        { label: "가져오기", icon: FolderInput, key: "import" as const, style: "bg-emerald-600 text-white hover:bg-emerald-700 shadow-md shadow-emerald-200" },
      ];

  const driveName = (() => {
    if (activeDriveId === "my") return "내 드라이브";
    // Check built-in drives with renames
    const builtIn = DRIVES.find(d => d.id === activeDriveId);
    if (builtIn) return driveRenames?.[builtIn.id] || builtIn.name;
    // Check custom drives
    const custom = customDrives?.find(d => d.id === activeDriveId);
    return custom ? custom.name : "드라이브";
  })();

  // Compute drive members for shared drives
  const driveMembers: string[] = (() => {
    if (isMyDrive) return [];
    // Built-in shared drives: always 2 members (me + the other person)
    const BUILTIN_MEMBERS: Record<string, string[]> = {
      jieun: ["박민준", "김지은"],
      junho: ["박민준", "박준호"],
    };
    if (BUILTIN_MEMBERS[activeDriveId]) return BUILTIN_MEMBERS[activeDriveId];
    // Custom drives
    const custom = customDrives?.find(d => d.id === activeDriveId);
    return custom ? custom.members : [];
  })();

  // Avatar colors for member list
  const MEMBER_COLORS = [
    "from-blue-400 to-blue-600",
    "from-violet-400 to-pink-400",
    "from-emerald-400 to-teal-500",
    "from-amber-400 to-orange-500",
    "from-rose-400 to-red-500",
    "from-cyan-400 to-blue-500",
  ];

  return (
    <div className="relative flex flex-col h-full">
      {/* Page header */}
      <div className="bg-white border-b border-slate-100 px-7 pt-6 pb-4">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div>
              <h1 className="text-slate-900" style={{ fontSize: "1.2rem" }}>
                {driveName}
              </h1>
              <div className="flex items-center gap-2 mt-0.5">
                <p className="text-slate-400" style={{ fontSize: "0.78rem" }}>
                  {sorted.length}개의 영상
                </p>

                {/* Members badge (shared drives only) */}
                {!isMyDrive && driveMembers.length > 0 && (
                  <div className="relative">
                    <button
                      ref={membersButtonRef}
                      onClick={() => setShowMembersPopover(!showMembersPopover)}
                      className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md border transition-all ${
                        showMembersPopover
                          ? "border-blue-300 bg-blue-50 text-blue-600"
                          : "border-slate-200 text-slate-400 hover:bg-slate-50 hover:border-slate-300 hover:text-slate-500"
                      }`}
                      style={{ fontSize: "0.7rem" }}
                    >
                      <Users className="w-3 h-3" />
                      <span>{driveMembers.length}명</span>
                    </button>

                    {/* Members popover */}
                    <AnimatePresence>
                      {showMembersPopover && (
                        <motion.div
                          ref={membersPopoverRef}
                          className="absolute left-0 top-full mt-2 w-52 bg-white border border-slate-200 rounded-xl py-2 z-30"
                          style={{
                            boxShadow: "0 8px 30px rgba(0,0,0,0.10), 0 2px 8px rgba(0,0,0,0.05)",
                          }}
                          initial={{ opacity: 0, y: -4, scale: 0.96 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: -4, scale: 0.96 }}
                          transition={{ duration: 0.12 }}
                        >
                          <p
                            className="px-3.5 pb-1.5 text-slate-400 uppercase"
                            style={{ fontSize: "0.6rem", letterSpacing: "0.08em" }}
                          >
                            참여자 {driveMembers.length}명
                          </p>
                          {driveMembers.map((member, idx) => {
                            const isMe = member === "박민준";
                            const colorClass = MEMBER_COLORS[idx % MEMBER_COLORS.length];
                            return (
                              <div
                                key={member}
                                className="flex items-center gap-2.5 px-3.5 py-2 hover:bg-slate-50 transition-colors"
                              >
                                <div
                                  className={`w-6 h-6 rounded-full bg-gradient-to-br ${colorClass} flex items-center justify-center text-white shrink-0`}
                                  style={{ fontSize: "0.5rem" }}
                                >
                                  {member.charAt(0)}
                                </div>
                                <span className="text-slate-700 flex-1" style={{ fontSize: "0.8rem" }}>
                                  {member}
                                </span>
                                {isMe && (
                                  <span
                                    className="text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded"
                                    style={{ fontSize: "0.6rem" }}
                                  >
                                    나
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sort */}
          <div className="relative">
            <button
              onClick={() => setSortOpen(!sortOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors"
              style={{ fontSize: "0.78rem" }}
            >
              <SlidersHorizontal className="w-3 h-3 text-slate-400" />
              {sortKey}
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
            {sortOpen && (
              <div className="absolute right-0 top-full mt-1 w-36 bg-white border border-slate-200 rounded-xl shadow-lg shadow-slate-100 py-1 z-20">
                {SORT_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => { setSortKey(opt); setSortOpen(false); }}
                    className={`w-full text-left px-3.5 py-1.5 hover:bg-slate-50 transition-colors flex items-center justify-between ${sortKey === opt ? "text-blue-600" : "text-slate-700"}`}
                    style={{ fontSize: "0.78rem" }}
                  >
                    {opt}
                    {sortKey === opt && <CheckCircle2 className="w-3 h-3 text-blue-500" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Filter tabs — pill style */}
        <div className="flex items-center gap-1">
          {TABS.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1.5 rounded-lg transition-all ${
                activeTab === tab
                  ? "bg-blue-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-700 hover:bg-slate-100"
              }`}
              style={{ fontSize: "0.78rem" }}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Video grid */}
      <div className="flex-1 overflow-y-auto p-7 pb-24">
        {sorted.length > 0 ? (
          <motion.div className="grid grid-cols-2 xl:grid-cols-3 gap-4" layout>
            <AnimatePresence mode="popLayout">
              {sorted.map((video) => (
                <VideoCard 
                  key={video.id} 
                  video={video} 
                  onPlay={() => openResultPlayer(video)} 
                  activeDriveId={activeDriveId} 
                  onLikeToggle={(id) => {
                    const index = ALL_VIDEOS.findIndex(v => v.id === id);
                    if (index !== -1) {
                      ALL_VIDEOS[index].liked = !ALL_VIDEOS[index].liked;
                    }
                  }} 
                  onEdit={handleEdit}
                  onShare={handleShareRequest}
                  onDelete={handleDeleteRequest}
                  onRenameTitle={(videoId, newTitle) => {
                    // 1) Try hardcoded ALL_VIDEOS
                    const index = ALL_VIDEOS.findIndex(v => v.id === videoId);
                    if (index !== -1) {
                      ALL_VIDEOS[index].title = newTitle;
                    }
                    // 2) Try localStorage savedVideos
                    const savedJson = localStorage.getItem('savedVideos');
                    if (savedJson) {
                      const saved = JSON.parse(savedJson);
                      const savedIdx = saved.findIndex((v: any) => v.id === videoId);
                      if (savedIdx !== -1) {
                        saved[savedIdx].title = newTitle;
                        localStorage.setItem('savedVideos', JSON.stringify(saved));
                      }
                    }
                    // 3) Persist title rename
                    const renamedJson = localStorage.getItem('renamedTitles');
                    const renamedTitles: Record<number, string> = renamedJson ? JSON.parse(renamedJson) : {};
                    renamedTitles[videoId] = newTitle;
                    localStorage.setItem('renamedTitles', JSON.stringify(renamedTitles));
                    setRefreshKey(prev => prev + 1);
                    showToast("제목이 변경되었습니다.", "success");
                  }}
                  isMenuOpen={menuOpen === video.id}
                  onToggleMenu={(videoId) => setMenuOpen(prev => prev === videoId ? null : videoId)}
                  onCloseMenu={() => setMenuOpen(null)}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div className="flex flex-col items-center justify-center h-60 text-slate-400">
            <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mb-4">
              <Play className="w-6 h-6 text-slate-300" />
            </div>
            <p style={{ fontSize: "0.88rem" }}>영상이 없습니다</p>
            <p className="mt-1 text-slate-300" style={{ fontSize: "0.78rem" }}>새 영상을 업로드해 시작하세요</p>
          </div>
        )}
      </div>

      {/* ── FAB Speed Dial ── */}
      <AnimatePresence>
        {fabOpen && (
          <motion.div
            className="fixed inset-0 z-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            onClick={() => setFabOpen(false)}
          />
        )}
      </AnimatePresence>
      <div className="fixed bottom-7 right-7 flex flex-col items-end gap-2.5 z-30">
        <AnimatePresence>
          {fabOpen &&
            fabActions.map((action, i) => {
              const Icon = action.icon;
              return (
                <motion.button
                  key={action.label}
                  onClick={() => {
                    setFabOpen(false);
                    if (action.key === "import") {
                      setImportSelectedIds([]);
                      setShowImportModal(true);
                    } else {
                      navigate("/caption");
                    }
                  }}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-colors ${action.style}`}
                  style={{ fontSize: "0.82rem" }}
                  initial={{ opacity: 0, y: 10, scale: 0.92 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 6, scale: 0.92 }}
                  transition={{ duration: 0.15, delay: i * 0.04 }}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {action.label}
                </motion.button>
              );
            })}
        </AnimatePresence>

        <motion.button
          onClick={() => setFabOpen(!fabOpen)}
          className="w-12 h-12 rounded-xl bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center shadow-xl shadow-blue-500/25 transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.94 }}
          animate={{ rotate: fabOpen ? 45 : 0 }}
          transition={{ duration: 0.18 }}
        >
          {fabOpen ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
        </motion.button>
      </div>

      {/* Delete confirmation dialog */}
      <AnimatePresence>
        {deleteTarget && (
          <DeleteConfirmDialog
            videoTitle={deleteTarget.title}
            onConfirm={handleDeleteConfirm}
            onCancel={() => setDeleteTarget(null)}
          />
        )}
      </AnimatePresence>

      {/* Share modal */}
      <AnimatePresence>
        {shareTarget && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            <div className="absolute inset-0 bg-black/40" onClick={() => setShareTarget(null)} />
            <motion.div
              className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-200 w-[400px] overflow-hidden"
              initial={{ scale: 0.92, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 5 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
            >
              {/* Header */}
              <div className="px-6 pt-6 pb-3">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
                    <Share2 className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-slate-900" style={{ fontSize: "1rem" }}>
                      드라이브에 공유
                    </h3>
                    <p className="text-slate-400 mt-0.5 truncate max-w-[260px]" style={{ fontSize: "0.75rem" }}>
                      "{shareTarget.title}"
                    </p>
                  </div>
                </div>
              </div>

              {/* Drive list */}
              <div className="px-6 pb-4">
                <p className="text-slate-500 mb-3" style={{ fontSize: "0.78rem" }}>
                  공유할 드라이브를 선택하세요
                </p>
                <div className="flex flex-col gap-1.5">
                  {[...DRIVES.filter(d => d.type === "shared"), ...(customDrives || [])].map((drive) => {
                    const isSelected = selectedDriveId === drive.id;
                    const displayName = driveRenames?.[drive.id] || drive.name;
                    return (
                      <button
                        key={drive.id}
                        onClick={() => setSelectedDriveId(isSelected ? null : drive.id)}
                        className={`flex items-center gap-3 w-full text-left px-4 py-3 rounded-xl border transition-all ${
                          isSelected
                            ? "border-blue-500 bg-blue-50/60 ring-1 ring-blue-500/20"
                            : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                          isSelected ? "bg-blue-500 text-white" : "bg-slate-100 text-slate-500"
                        }`} style={{ fontSize: "0.65rem" }}>
                          {isSelected ? <Check className="w-3.5 h-3.5" /> : <Users className="w-3.5 h-3.5" />}
                        </div>
                        <span className={`${isSelected ? "text-blue-700" : "text-slate-700"}`} style={{ fontSize: "0.85rem" }}>
                          {displayName}
                        </span>
                        {isSelected && (
                          <CheckCircle2 className="w-4 h-4 text-blue-500 ml-auto" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 px-6 pb-5 pt-1 justify-end border-t border-slate-100">
                <button
                  onClick={() => setShareTarget(null)}
                  className="px-4 py-2 mt-3 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  style={{ fontSize: "0.82rem" }}
                >
                  취소
                </button>
                <button
                  onClick={handleShareConfirm}
                  disabled={!selectedDriveId}
                  className={`px-4 py-2 mt-3 rounded-lg transition-colors shadow-sm ${
                    selectedDriveId
                      ? "bg-blue-600 hover:bg-blue-700 text-white"
                      : "bg-slate-100 text-slate-400 cursor-not-allowed"
                  }`}
                  style={{ fontSize: "0.82rem" }}
                >
                  공유하기
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Import from My Drive modal */}
      <AnimatePresence>
        {showImportModal && (() => {
          // Get all videos from "내 드라이브"
          const myDriveVideos = allVideos.filter(v => v.owner === "my");
          const handleImportConfirm = () => {
            if (importSelectedIds.length === 0) return;
            const importedVideos = myDriveVideos.filter(v => importSelectedIds.includes(v.id));
            const sharedVideosKey = `sharedVideos_${activeDriveId}`;
            const existingJson = localStorage.getItem(sharedVideosKey);
            const existing = existingJson ? JSON.parse(existingJson) : [];
            for (const video of importedVideos) {
              existing.push({
                ...video,
                id: Date.now() + Math.random(),
                owner: activeDriveId,
                date: new Date().toISOString().slice(0, 10).replace(/-/g, "."),
              });
            }
            localStorage.setItem(sharedVideosKey, JSON.stringify(existing));
            setShowImportModal(false);
            setImportSelectedIds([]);
            showToast(`${importedVideos.length}개의 영상을 가져왔습니다.`, "success");
            setRefreshKey(prev => prev + 1);
          };

          return (
            <motion.div
              className="fixed inset-0 z-50 flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <div className="absolute inset-0 bg-black/40" onClick={() => setShowImportModal(false)} />
              <motion.div
                className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-200 w-[480px] max-h-[80vh] flex flex-col overflow-hidden"
                initial={{ scale: 0.92, opacity: 0, y: 10 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 5 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
              >
                {/* Header */}
                <div className="px-6 pt-6 pb-3 shrink-0">
                  <div className="flex items-center gap-3 mb-1">
                    <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center shrink-0">
                      <FolderInput className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <h3 className="text-slate-900" style={{ fontSize: "1rem" }}>
                        내 드라이브에서 가져오기
                      </h3>
                      <p className="text-slate-400 mt-0.5" style={{ fontSize: "0.75rem" }}>
                        가져올 영상을 선택하세요
                      </p>
                    </div>
                  </div>
                </div>

                {/* Video list */}
                <div className="px-6 pb-4 flex-1 overflow-y-auto">
                  {myDriveVideos.length > 0 ? (
                    <div className="flex flex-col gap-1.5">
                      {myDriveVideos.map((video) => {
                        const isSelected = importSelectedIds.includes(video.id);
                        return (
                          <button
                            key={video.id}
                            onClick={() =>
                              setImportSelectedIds(prev =>
                                isSelected
                                  ? prev.filter(id => id !== video.id)
                                  : [...prev, video.id]
                              )
                            }
                            className={`flex items-center gap-3 w-full text-left px-3 py-2.5 rounded-xl border transition-all ${
                              isSelected
                                ? "border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500/20"
                                : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                            }`}
                          >
                            {/* Thumbnail */}
                            <div className="w-16 h-10 rounded-lg overflow-hidden bg-slate-100 shrink-0">
                              <ImageWithFallback
                                src={video.thumb}
                                alt={video.title}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            {/* Info */}
                            <div className="flex-1 min-w-0">
                              <p className={`truncate ${isSelected ? "text-emerald-700" : "text-slate-700"}`} style={{ fontSize: "0.84rem" }}>
                                {video.title}
                              </p>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="text-slate-400" style={{ fontSize: "0.68rem" }}>
                                  {video.date}
                                </span>
                                <span className="text-slate-300" style={{ fontSize: "0.68rem" }}>
                                  {video.duration}
                                </span>
                              </div>
                            </div>
                            {/* Checkbox */}
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 transition-all ${
                              isSelected
                                ? "bg-emerald-500 text-white"
                                : "border-2 border-slate-200"
                            }`}>
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-10 text-slate-400">
                      <Play className="w-8 h-8 text-slate-200 mb-2" />
                      <p style={{ fontSize: "0.84rem" }}>내 드라이브에 영상이 없습니다</p>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between px-6 pb-5 pt-3 border-t border-slate-100 shrink-0">
                  <span className="text-slate-400" style={{ fontSize: "0.75rem" }}>
                    {importSelectedIds.length > 0
                      ? `${importSelectedIds.length}개 선택됨`
                      : "영상을 선택하세요"}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowImportModal(false)}
                      className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                      style={{ fontSize: "0.82rem" }}
                    >
                      취소
                    </button>
                    <button
                      onClick={handleImportConfirm}
                      disabled={importSelectedIds.length === 0}
                      className={`px-4 py-2 rounded-lg transition-colors shadow-sm ${
                        importSelectedIds.length > 0
                          ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                          : "bg-slate-100 text-slate-400 cursor-not-allowed"
                      }`}
                      style={{ fontSize: "0.82rem" }}
                    >
                      가져오기
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {/* Toast notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            className="fixed bottom-8 left-1/2 z-[70] flex items-center gap-2.5 px-5 py-3 bg-slate-900 text-white rounded-xl shadow-xl"
            style={{ fontSize: "0.84rem" }}
            initial={{ opacity: 0, y: 20, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 10, x: "-50%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
          >
            {toastType === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}