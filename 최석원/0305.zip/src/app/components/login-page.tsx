import { useState } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "motion/react";
import { useNavigate } from "react-router";
import {
  Volume2,
  VolumeX,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const fireworksThumb =
  "https://images.unsplash.com/photo-1729931597118-e49ddbea68ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdodCUyMHNreSUyMGZpcmV3b3JrcyUyMGNvbG9yZnVsJTIwZXhwbG9zaW9uJTIwY2VsZWJyYXRpb258ZW58MXx8fHwxNzcyNjAxMDMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

// ── Floating caption chips for AFTER card ─────────────────────────────────────
const CAPTIONS = [
  { icon: "🎆", text: "[불꽃 터지는 소리]", delay: 0,   x: "5%",  y: "12%" },
  { icon: "👏", text: "[사람들 환호]",      delay: 1.6,  x: "44%", y: "52%" },
  { icon: "🔊", text: "폭발음",            delay: 2.8,  x: "6%",  y: "62%" },
  { icon: "🎇", text: "반짝이는 소리",     delay: 0.8,  x: "46%", y: "16%" },
];

function FloatingCaptions() {
  return (
    <>
      {CAPTIONS.map((c, i) => (
        <motion.div
          key={i}
          className="absolute z-10 flex items-center gap-1.5 bg-white/95 backdrop-blur-md text-slate-700 px-2.5 py-1 rounded-full border border-white/40 shadow-lg"
          style={{ left: c.x, top: c.y, fontSize: "0.66rem", whiteSpace: "nowrap" }}
          initial={{ opacity: 0, scale: 0.8, y: 6 }}
          animate={{ 
            opacity: [0, 1, 1, 0], 
            scale: [0.8, 1, 1, 0.95], 
            y: [6, 0, 0, -4],
            x: [0, 2, -2, 0]
          }}
          transition={{ duration: 3.5, delay: c.delay, repeat: Infinity, repeatDelay: 2.5, ease: "easeInOut" }}
        >
          <span>{c.icon}</span>
          <span>{c.text}</span>
        </motion.div>
      ))}
    </>
  );
}

// ── Kakao logo ────────────────────────────────────────────────────────────────
function KakaoLogo() {
  return (
    <svg width="18" height="18" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M128 36C70.562 36 24 72.713 24 118.165C24 147.593 43.07 173.539 72.03 188.476L62.244 224.849C61.442 227.863 64.957 230.276 67.588 228.51L110.89 200.482C116.476 201.052 122.18 201.33 128 201.33C185.438 201.33 232 164.617 232 118.165C232 72.713 185.438 36 128 36Z"
        fill="#3C1E1E"
      />
    </svg>
  );
}

// ── Progress bar ──────────────────────────────────────────────────────────────
function ProgressBar({ accent }: { accent: string }) {
  return (
    <div className="h-[3px] w-full bg-white/20 overflow-hidden">
      <motion.div
        className={`h-full ${accent}`}
        animate={{ width: ["0%", "100%"] }}
        transition={{ duration: 9, repeat: Infinity, ease: "linear" }}
      />
    </div>
  );
}

// ── Brand Logo Mark ───────────────────────────────────────────────────────────
function BrandLogoMark({ size = 44 }: { size?: number }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 44 44" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2563EB" />
          <stop offset="100%" stopColor="#3B82F6" />
        </linearGradient>
      </defs>
      <rect width="44" height="44" rx="13" fill="url(#logoGradient)" />
      {/* Speaker body */}
      <path d="M18 17.5L18 26.5L23 26.5L29.5 31L29.5 13L23 17.5Z" fill="white" />
      {/* Sound wave 1 */}
      <path d="M13 22 Q13 17 17 16" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.5" />
      {/* Sound wave 2 */}
      <path d="M11 22 Q11 14 17 13" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.28" />
      {/* Subtitle lines */}
      <rect x="9"  y="35" width="10" height="1.8" rx="0.9" fill="white" opacity="0.75" />
      <rect x="21" y="35" width="14" height="1.8" rx="0.9" fill="white" opacity="0.75" />
      <rect x="9"  y="39" width="6"  height="1.8" rx="0.9" fill="white" opacity="0.42" />
      <rect x="17" y="39" width="12" height="1.8" rx="0.9" fill="white" opacity="0.42" />
    </svg>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export function LoginPage() {
  const navigate = useNavigate();
  const [hovered, setHovered] = useState(false);
  
  // Mouse position for parallax effect
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  
  // Smooth spring animation for mouse movement
  const springConfig = { damping: 25, stiffness: 150 };
  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [7, -7]), springConfig);
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-7, 7]), springConfig);
  
  // Handle mouse move for 3D effect
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const x = (e.clientX - rect.left) / width - 0.5;
    const y = (e.clientY - rect.top) / height - 0.5;
    mouseX.set(x);
    mouseY.set(y);
  };
  
  // Reset position when mouse leaves
  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
    setHovered(false);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col lg:flex-row">

      {/* ════ LEFT — Hero Section ════ */}
      <div className="flex flex-col justify-center px-8 py-14 lg:px-16 xl:px-24 lg:w-1/2 lg:min-h-screen">

        {/* ── Brand logo ── */}
        <div className="mb-12">
          <div className="flex items-center gap-3">
            <BrandLogoMark size={48} />
            <span className="text-slate-900 text-xl font-semibold tracking-tight">
              SoundSee
            </span>
          </div>
        </div>

        {/* ── Tagline ── */}
        <h1
          className="text-slate-900 mb-6"
          style={{ 
            fontSize: "clamp(2.5rem, 5vw, 4rem)", 
            lineHeight: 1.1, 
            letterSpacing: "-0.03em", 
            fontWeight: 700 
          }}
        >
          눈으로{" "}
          <span
            style={{
              background: "linear-gradient(135deg, #2563EB 0%, #3B82F6 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            들으세요
          </span>
        </h1>

        {/* ── Description ── */}
        <p
          className="text-slate-600 mb-10"
          style={{ fontSize: "1.125rem", lineHeight: 1.7 }}
        >
          AI가 영상 속 소리를 인식해
          <br />
          자막과 이모티콘으로 보여줍니다.
        </p>

        {/* ── Kakao login button (NO ANIMATIONS) ── */}
        <div className="mb-10">
          <button
            onClick={() => navigate("/dashboard")}
            className="flex items-center justify-center gap-3 w-full max-w-md bg-[#FEE500] text-[#191919] rounded-xl px-8 py-4 font-semibold text-base cursor-pointer shadow-md"
          >
            <KakaoLogo />
            카카오톡으로 로그인
          </button>
        </div>
      </div>

      {/* ════ RIGHT — AI Caption Preview (FULL HEIGHT) ════ */}
      <div className="flex items-center justify-center bg-slate-50 px-8 py-12 lg:py-16 lg:px-12 lg:w-1/2 lg:min-h-screen">
        <div className="w-full max-w-3xl">
          {/* Section label */}
          <div className="flex items-center gap-2 mb-6">
            <span className="w-2 h-2 bg-blue-500 rounded-full" />
            <span className="text-slate-600 text-sm font-semibold tracking-wide">
              AI 자막 미리보기
            </span>
          </div>

          {/* ── Comparison card with 3D effect (ANIMATED CARDS) ── */}
          <div
            className="relative"
            style={{ perspective: 1400 }}
          >
            <motion.div
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xl"
              style={{
                rotateX,
                rotateY,
                transformStyle: "preserve-3d",
              }}
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setHovered(true)}
              onMouseLeave={handleMouseLeave}
              animate={{
                y: [0, -8, 0],
                boxShadow: hovered 
                  ? ["0 25px 50px -12px rgba(0, 0, 0, 0.2)", "0 35px 70px -15px rgba(0, 0, 0, 0.3)", "0 25px 50px -12px rgba(0, 0, 0, 0.2)"]
                  : ["0 20px 40px -12px rgba(0, 0, 0, 0.15)", "0 25px 50px -12px rgba(0, 0, 0, 0.18)", "0 20px 40px -12px rgba(0, 0, 0, 0.15)"],
              }}
              transition={{
                y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
                boxShadow: { duration: 4, repeat: Infinity, ease: "easeInOut" },
              }}
            >
              <div className="grid grid-cols-2">
                {/* BEFORE CARD */}
                <motion.div 
                  className="relative border-r border-slate-200"
                  style={{
                    transformStyle: "preserve-3d",
                    transform: "translateZ(20px)",
                  }}
                  animate={{
                    x: hovered ? [-2, 2, -2] : 0,
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <div className="relative overflow-hidden">
                    <motion.div
                      animate={{
                        scale: hovered ? 1.05 : 1,
                      }}
                      transition={{ duration: 0.6, ease: "easeOut" }}
                    >
                      <ImageWithFallback
                        src={fireworksThumb}
                        alt="일반 영상"
                        className="w-full object-cover grayscale brightness-75"
                        style={{ aspectRatio: "16/10" }}
                      />
                    </motion.div>
                    
                    {/* Badge */}
                    <div
                      className="absolute top-4 left-4 flex items-center gap-2 bg-white/95 backdrop-blur-sm text-slate-700 border border-slate-200 px-3 py-1.5 rounded-full shadow-sm text-xs font-medium"
                    >
                      <VolumeX className="w-3.5 h-3.5" />
                      일반 영상
                    </div>
                    
                    {/* Center icon */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <motion.div
                        className="w-16 h-16 rounded-full bg-white/90 backdrop-blur-sm border border-slate-200 flex items-center justify-center shadow-lg"
                        animate={{ 
                          scale: hovered ? [1, 1.15, 1] : 1,
                          rotate: hovered ? [0, -8, 8, 0] : 0,
                        }}
                        transition={{ 
                          duration: 2.5,
                          repeat: hovered ? Infinity : 0,
                          ease: "easeInOut",
                        }}
                      >
                        <VolumeX className="w-7 h-7 text-slate-400" />
                      </motion.div>
                    </div>
                    
                    {/* Progress */}
                    <div className="absolute bottom-0 left-0 right-0">
                      <ProgressBar accent="bg-slate-400" />
                    </div>
                  </div>
                  <div className="px-4 py-3 bg-slate-50">
                    <span className="text-slate-500 text-xs font-bold tracking-wider uppercase">
                      BEFORE
                    </span>
                  </div>
                </motion.div>

                {/* AFTER CARD */}
                <motion.div 
                  className="relative"
                  style={{
                    transformStyle: "preserve-3d",
                    transform: "translateZ(40px)",
                  }}
                  animate={{
                    x: hovered ? [2, -2, 2] : 0,
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <div className="relative overflow-hidden">
                    {/* Soft glow effect around AI card */}
                    <motion.div
                      className="absolute inset-0 z-0 rounded-lg"
                      animate={{
                        boxShadow: [
                          "0 0 20px rgba(37, 99, 235, 0.3)",
                          "0 0 40px rgba(37, 99, 235, 0.5)",
                          "0 0 20px rgba(37, 99, 235, 0.3)",
                        ],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                    />
                    
                    <motion.div
                      animate={{
                        scale: hovered ? 1.08 : 1,
                      }}
                      transition={{ duration: 0.6, ease: "easeOut" }}
                    >
                      <ImageWithFallback
                        src={fireworksThumb}
                        alt="AI 자막 영상"
                        className="w-full object-cover brightness-95"
                        style={{ aspectRatio: "16/10" }}
                      />
                    </motion.div>
                    
                    {/* Floating captions */}
                    <FloatingCaptions />
                    
                    {/* Badge */}
                    <div
                      className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-blue-600 text-white px-3 py-1.5 rounded-full shadow-md text-xs font-medium"
                    >
                      <span className="w-1.5 h-1.5 bg-emerald-300 rounded-full" />
                      AI 자막
                    </div>
                    
                    {/* Center icon with glow */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <motion.div
                        className="w-16 h-16 rounded-full bg-blue-600 border border-blue-400 flex items-center justify-center shadow-lg"
                        animate={{
                          scale: [1, 1.2, 1],
                          rotate: [0, 180, 360],
                          boxShadow: [
                            "0 0 0 0 rgba(37, 99, 235, 0.7)",
                            "0 0 0 25px rgba(37, 99, 235, 0)",
                            "0 0 0 0 rgba(37, 99, 235, 0)",
                          ],
                        }}
                        transition={{ 
                          scale: { duration: 2.5, repeat: Infinity, ease: "easeInOut" },
                          rotate: { duration: 8, repeat: Infinity, ease: "linear" },
                          boxShadow: { duration: 2.5, repeat: Infinity, ease: "easeInOut" },
                        }}
                      >
                        <Volume2 className="w-7 h-7 text-white" />
                      </motion.div>
                    </div>
                    
                    {/* Caption bar */}
                    <div className="absolute bottom-0 left-0 right-0">
                      <ProgressBar accent="bg-blue-400" />
                      <motion.div
                        className="bg-slate-900/90 backdrop-blur-sm px-4 py-2.5 text-center text-white text-sm"
                        animate={{ opacity: [0.85, 1, 0.85] }}
                        transition={{ duration: 2.5, repeat: Infinity }}
                      >
                        🎆 [불꽃 터지는 소리] · 자막 자동 생성 중
                      </motion.div>
                    </div>
                  </div>
                  <div className="px-4 py-3 bg-blue-50">
                    <span className="text-blue-600 text-xs font-bold tracking-wider uppercase">
                      AFTER
                    </span>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}