Update and improve the Login Page design with the following changes.

1) Header and branding
Remove the top navigation bar on the Login Page.

Place the brand logo at the top of the hero section.

Directly below the logo, add the main tagline:
"눈으로 들으세요"

Below the tagline, include a short service description:
"AI가 영상 속 소리를 인식해 자막과 이모티콘으로 보여줍니다."

Use a clean white background with blue accent colors.

2) Feature highlight section (UX improvement)

Between the service description and the Kakao login button, add a small feature highlight section.

Create three small cards arranged horizontally.

Each card should include an icon, title, and short description.

Card 1
Icon: sound or AI icon
Title: "AI 소리 인식"
Description: "영상 속 환경음을 자동으로 분석합니다"

Card 2
Icon: subtitle icon
Title: "자동 자막 생성"
Description: "소리를 이해하기 쉬운 자막으로 변환합니다"

Card 3
Icon: emoji icon
Title: "이모티콘 표현"
Description: "소리를 시각적인 아이콘으로 보여줍니다"

The cards should use a minimal white design with soft blue accents.

3) AI caption preview comparison

Under the "AI 자막 미리보기" section, display two comparison video cards.

Both video thumbnails should use the SAME image.

Use a fireworks scene as the image (night sky fireworks).

Left card (Before):
Normal video without captions.

Right card (After):
Same fireworks image but with floating caption overlays and emojis.

Example overlays:
🎆 [불꽃 터지는 소리]
👏 [사람들 환호]

This helps demonstrate the AI caption feature visually.

4) Remove lower vlog video

Remove the dog daily vlog video section below the comparison preview.

Instead, create an information section using modern cards.

Include elements such as:

• AI sound detection
• Dynamic sound captions
• Emoji-based sound visualization
• Accessible video experience

Design this section as clean feature blocks that match the page style.

5) Layout adjustment

The page is split into two halves.

Swap the left and right sections completely.
Move all design elements along with them so the layout remains visually balanced.

Increase the size of the preview video area after removing the lower video section.

6) Design style

Use a light theme with white background.

Primary accent color: modern blue.

Use blue for buttons, highlights, and active UI elements.

The overall design should feel like a modern SaaS product landing page focused on accessibility.