Design a modern desktop web application UI for an AI video caption platform for hearing accessibility.

Use a blue color theme inspired by accessibility and hearing awareness.

All interface text should be in Korean.

Create 4 main screens and connect them with navigation interactions.

Screen 1 — Login Page

Create a login page.

Layout:

Center area:

Before / After video comparison.

Left side:

normal video without captions.

Right side:

video with AI generated sound captions.

Headline text:

"눈으로 들으세요"

Description:

"AI가 영상 속 소리를 인식해 자막과 이모티콘으로 보여줍니다."

Bottom section:

Large yellow button.

Text:

"카카오톡으로 로그인"

Interaction:

When the user clicks the Kakao login button,
navigate to the Main Dashboard screen.

Screen 2 — Main Dashboard

This is the main workspace.

Top navigation bar:

Left:

App logo

Right:

User profile avatar

Left sidebar:

Title:

"드라이브"

List of drives shared with friends.

Bottom buttons:

"친구 찾기"

"드라이브 만들기"

Main area:

Grid layout showing uploaded videos.

Top center filters:

"정렬"

"전체 영상"

"내가 만든 영상"

"내가 저장한 영상"

Bottom right floating action button.

If the user is inside My Drive, show:

"변환하기"

"업로드 하기"

If the user is inside Shared Drive, show:

"공유하기"

"가져오기"

Interaction:

When the user clicks any of these buttons

"변환하기"

"업로드 하기"

"공유하기"

"가져오기"

navigate to the Video Caption Generation page.

Screen 3 — Video Caption Generation Page

This page is used to generate AI captions.

Center area:

Large video preview.

Buttons below the video:

"영상 업로드"

"AI 자막 생성"

Right side settings panel:

Options:

"자막 표시"

"이모티콘 표시"

"소리 인식 민감도"

Bottom area:

AI processing progress bar.

Text:

"AI가 영상 속 소리를 분석 중입니다"

Screen 4 — Video Result Page

Video player showing generated captions.

Center:

Large video player.

Bottom center:

Dynamic sound captions.

Examples:

"[문 닫힘]"

"[강아지 짖음]"

Bottom left:

Toggle switch.

Text:

"이모티콘 표시 ON / OFF"

Right side vertical panel:

Timeline of detected sounds.

Each item shows

timestamp + sound label.

Example:

00:12 강아지 짖음

00:28 문 닫힘

01:03 유리 깨짐

Include a collapse / expand button.