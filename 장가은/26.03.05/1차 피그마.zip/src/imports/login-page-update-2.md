Modify the Login Page layout with the following strict rules.

Do not ignore these instructions.

--------------------------------------------------

1. PAGE LAYOUT

The page must be divided into two sections.

LEFT SIDE (Hero section)

Place the following elements vertically:

1. Brand logo at the top

2. Below the logo add the text:
눈으로 들으세요

3. Below the text add a short description:
AI가 영상 속 소리를 인식해 자막과 이모티콘으로 보여줍니다.

4. Below the description place a login button:
카카오톡으로 로그인

The left section should be simple and clean.

--------------------------------------------------

2. REMOVE TOP NAVIGATION

Remove the top navigation bar completely on the login page.

--------------------------------------------------

3. REMOVE ALL FEATURE CARDS

Delete all cards that contain text including:

AI 소리 인식  
자동 자막 생성  
이모티콘 표현  

Delete any statistic cards such as:

자막 정확도  
평균 응답 속도  
지원 언어  
12,000+명이 이미 사용 중  

Delete the dog vlog video section.

Do not replace these with new cards.

--------------------------------------------------

4. RIGHT SIDE AI CAPTION PREVIEW

The AI caption preview must fill the ENTIRE right half of the screen.

It should occupy the full height and width of the right side.

Inside this preview show two large comparison video cards.

Both video thumbnails MUST use the same image.

Use a fireworks scene (night fireworks) as the thumbnail.

Left card (Before)

Normal video  
No captions

Right card (After)

Same fireworks image  
Show AI caption overlays

Example overlays:

🎆 [불꽃 터지는 소리]  
👏 [사람들 환호]

--------------------------------------------------

5. REMOVE BUTTON ANIMATIONS

Buttons must NOT have animations.

Remove all hover animations  
Remove scale effects  
Remove glow effects  
Remove motion effects

Buttons should remain static.

--------------------------------------------------

6. VIDEO CARD ANIMATION

Apply animation ONLY to the entire video cards.

Do not animate small UI elements.

The animation must affect the whole card.

Examples of animation effects:

subtle floating motion of the card  
slight 3D depth effect  
soft hover scale of the whole card  
smooth parallax movement  
soft shadow movement  

The animation should make the video cards feel dynamic and premium.

The animation must be applied to the full video cards, not to buttons or small components.

--------------------------------------------------

7. DESIGN STYLE

Use a clean white background.

Primary accent color: blue.

Minimal modern SaaS design.

Focus on high readability and spacious layout.