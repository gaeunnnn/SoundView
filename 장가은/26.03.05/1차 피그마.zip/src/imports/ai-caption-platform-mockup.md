Create a modern web app UI mockup for an AI video caption platform for hearing accessibility.
The UI should be clean, minimal, and accessibility-focused with a modern SaaS style.

Use 4 main screens.

1. Login Page

Design a login page for an AI caption service.

Layout:

Center section:

Large before / after video comparison

Left: normal video

Right: video with AI dynamic sound captions

Headline text:
"Listen with Your Eyes"

Short description:
"AI detects sounds in videos and converts them into captions and visual icons."

Bottom section:

Kakao Social Login Button

Large yellow Kakao style button

Text: "Login with Kakao"

Style:

Dark video background

Modern hero section

Minimal UI

2. Main Dashboard Page

Design the main workspace where users manage video drives and videos.

Layout:

Top Navigation Bar:

Left: App Logo

Right: User profile avatar

Left Sidebar:

Title: Drives

List of shared drives with friends.

Buttons at bottom:

Find Friends

Create Drive

Main Content Area:

Video grid showing uploaded videos.

Top Center Filters:

Sort button

All Videos

My Videos

Saved Videos

Each video card contains:

thumbnail

title

upload date

Floating Action Button (bottom right):

If My Drive

Convert Video

Upload Video

If Shared Drive

Share

Import Video

3. Video Caption Generation Page

Page where a user uploads a video and generates AI sound captions.

Layout:

Center area:

Large video preview window

Below video:

Upload Video button

Generate AI Captions button

Right side panel:

Settings:

Caption language

Sound detection sensitivity

Toggle: Emoji mode

Toggle: Sound caption mode

Bottom:

Progress bar showing AI processing status

4. Video Result / Playback Page

Video player page showing the generated captions and sound icons.

Layout:

Center:

Large video player

Bottom center:

Dynamic captions

Example:

[Dog barking]
[Door closing]

Bottom left:

Emoji ON/OFF toggle

Example icons appear on screen when enabled.

Right side vertical panel:

Timeline of detected sounds

Each entry shows:

timestamp

sound type

Example:

00:12 Dog Bark
00:28 Door Close
01:03 Glass Break

Panel has a collapse / expand button

Design Style

Clean SaaS product UI

Accessibility focused

Soft rounded components

Neutral background

Accent color: blue or purple

Modern video platform feel