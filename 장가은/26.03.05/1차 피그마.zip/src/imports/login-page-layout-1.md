Update the Login Page layout with the following rules.

--------------------------------------------------

1. PAGE STRUCTURE

The screen must be divided into two halves.

LEFT SIDE (Hero section)

Place the following elements vertically:

1. Brand logo
2. Text:
눈으로 들으세요
3. Description text:
AI가 영상 속 소리를 인식해 자막과 이모티콘으로 보여줍니다.
4. Login button:
카카오톡으로 로그인

Keep the left side clean and minimal.

--------------------------------------------------

2. RIGHT SIDE AI CAPTION PREVIEW

The entire RIGHT HALF of the screen must be filled with the AI caption preview component.

The preview component must expand to fill the full height and full width of the right side.

Do not place any additional sections below it.

This preview area should visually dominate the right half of the screen.

--------------------------------------------------

3. VIDEO PREVIEW CONTENT

Inside the preview area display two comparison video cards.

Both cards must use the same thumbnail image.

Use a fireworks scene as the thumbnail.

Left card (Before)
Normal video without captions.

Right card (After)
Same fireworks image with AI caption overlays.

Example overlays:

🎆 [불꽃 터지는 소리]  
👏 [사람들 환호]

--------------------------------------------------

4. VIDEO CARD ANIMATION

Apply animation to the entire video cards.

Do not animate buttons or small UI components.

The animation should affect the whole video cards.

Use modern premium animation inspired by high-end websites.

Examples:

- subtle floating motion of the cards
- slight 3D tilt effect
- smooth parallax movement
- soft glow highlight around the AI video card
- smooth hover scale effect of the entire card

Animations should make the preview area feel dynamic and visually impressive.

--------------------------------------------------

5. DESIGN STYLE

Use a clean white background.

Primary accent color: blue.

Modern SaaS interface style.

Focus on a premium and spacious layout.