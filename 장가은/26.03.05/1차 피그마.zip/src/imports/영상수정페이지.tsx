import svgPaths from "./svg-rtv3cxpx09";
import imgImageWithFallback from "figma:asset/dee7eda1d512409d25776a893a235714eb5218a0.png";

function ArrowLeft() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="ArrowLeft">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="ArrowLeft">
          <path d={svgPaths.p203476e0} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M12.6667 8H3.33333" id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Span() {
  return (
    <div className="flex-[1_0_0] h-[19.672px] min-h-px min-w-px relative" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[19.68px] relative shrink-0 text-[#45556c] text-[13.12px] text-center whitespace-nowrap">대시보드로 돌아가기</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="flex-[1_0_0] h-[19.672px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <ArrowLeft />
        <Span />
      </div>
    </div>
  );
}

function Container() {
  return <div className="bg-[#e2e8f0] h-[20px] shrink-0 w-px" data-name="Container" />;
}

function Subtitles() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Subtitles">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Subtitles">
          <path d={svgPaths.p2bb74980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p3420b580} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[#155dfc] relative rounded-[8px] shrink-0 size-[24px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Subtitles />
      </div>
    </div>
  );
}

function Span1() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[21.6px] left-0 text-[#1d293d] text-[14.4px] top-[-2.5px] whitespace-nowrap">SoundSee</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[100.305px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container2 />
        <Span1 />
      </div>
    </div>
  );
}

function Div1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[269.617px]" data-name="div">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
        <Button />
        <Container />
        <Container1 />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-white h-[52px] relative shrink-0 w-[1099px]" data-name="header">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-px pl-[20px] pr-[809.383px] relative size-full">
        <Div1 />
      </div>
    </div>
  );
}

function H() {
  return (
    <div className="content-stretch flex h-[28.805px] items-start relative shrink-0 w-full" data-name="h1">
      <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[28.8px] min-h-px min-w-px relative text-[#0f172b] text-[19.2px]">결과 플레이어</p>
    </div>
  );
}

function P() {
  return (
    <div className="content-stretch flex h-[18.711px] items-start relative shrink-0 w-full" data-name="p">
      <p className="font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[18.72px] relative shrink-0 text-[#90a1b9] text-[12.48px] whitespace-nowrap">자연_다큐멘터리_vol1.mp4 · AI 자막 적용됨</p>
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[49.516px] relative shrink-0 w-[234.594px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start relative size-full">
        <H />
        <P />
      </div>
    </div>
  );
}

function Download() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[10.2px]" data-name="Download">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Download">
          <path d={svgPaths.p23ad1400} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p19411800} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 10V2" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#155dfc] h-[36.398px] relative rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] shrink-0 w-[104.055px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Download />
        <p className="-translate-x-1/2 absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[20.4px] left-[63.5px] text-[13.6px] text-center text-white top-[5px] whitespace-nowrap">저장하기</p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute content-stretch flex h-[49.516px] items-start justify-between left-[28px] top-[28px] w-[763px]" data-name="Container">
      <Container6 />
      <Button1 />
    </div>
  );
}

function Subtitles1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Subtitles">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Subtitles">
          <path d={svgPaths.p1e6afe00} id="Vector" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1ab1e900} id="Vector_2" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Span2() {
  return (
    <div className="bg-[#f0fdfa] flex-[1_0_0] h-[24.711px] min-h-px min-w-px relative rounded-[10px]" data-name="span">
      <div aria-hidden="true" className="absolute border border-[#cbfbf1] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center px-[11px] py-[3px] relative size-full">
          <p className="font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[18.72px] relative shrink-0 text-[#00786f] text-[12.48px] whitespace-nowrap">💨 [바람 소리]</p>
        </div>
      </div>
    </div>
  );
}

function Span3() {
  return (
    <div className="h-[17.281px] relative shrink-0 w-[28.789px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[17.28px] relative shrink-0 text-[#90a1b9] text-[11.52px] whitespace-nowrap">02:30</p>
      </div>
    </div>
  );
}

function MotionSpan() {
  return <div className="bg-[#51a2ff] h-[6.344px] rounded-[16777200px] shrink-0 w-[2px]" data-name="motion.span" />;
}

function MotionSpan1() {
  return <div className="bg-[#51a2ff] h-[3.023px] rounded-[16777200px] shrink-0 w-[2px]" data-name="motion.span" />;
}

function MotionSpan2() {
  return <div className="bg-[#51a2ff] flex-[1_0_0] h-[4.609px] min-h-px min-w-px rounded-[16777200px]" data-name="motion.span" />;
}

function Span4() {
  return (
    <div className="h-[12px] relative shrink-0 w-[10px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[2px] items-end relative size-full">
        <MotionSpan />
        <MotionSpan1 />
        <MotionSpan2 />
      </div>
    </div>
  );
}

function MotionDiv() {
  return (
    <div className="h-[24.711px] relative shrink-0 w-[191.289px]" data-name="motion.div">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Subtitles1 />
        <Span2 />
        <Span3 />
        <Span4 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="bg-white flex-[1_0_0] h-[52px] min-h-px min-w-px relative rounded-[14px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center pl-[17px] pr-px py-px relative size-full">
          <MotionDiv />
        </div>
      </div>
    </div>
  );
}

function SmileIcon() {
  return (
    <div className="absolute left-[17px] size-[16px] top-[13px]" data-name="SmileIcon">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_8_289)" id="SmileIcon">
          <path d={svgPaths.p39ee6532} id="Vector" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p30be9df0} id="Vector_2" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M6 6H6.00667" id="Vector_3" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M10 6H10.0067" id="Vector_4" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_8_289">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Span5() {
  return (
    <div className="absolute content-stretch flex h-[19.195px] items-start left-[43px] top-[11.4px] w-[74.242px]" data-name="span">
      <p className="font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[19.2px] relative shrink-0 text-[#45556c] text-[12.8px] whitespace-nowrap">이모티콘 표시</p>
    </div>
  );
}

function Span6() {
  return (
    <div className="absolute content-stretch flex h-[17.281px] items-start left-[173.24px] top-[12.36px] w-[16.883px]" data-name="span">
      <p className="font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[17.28px] relative shrink-0 text-[#155dfc] text-[11.52px] whitespace-nowrap">ON</p>
    </div>
  );
}

function Span7() {
  return <div className="bg-white h-[16px] rounded-[16777200px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] shrink-0 w-full" data-name="span" />;
}

function Button2() {
  return (
    <div className="absolute bg-[#155dfc] content-stretch flex flex-col h-[20px] items-start left-[127.24px] pl-[36px] pr-[-16px] pt-[2px] rounded-[16777200px] top-[11px] w-[36px]" data-name="button">
      <Span7 />
    </div>
  );
}

function Container9() {
  return (
    <div className="bg-white h-[42px] relative rounded-[14px] shrink-0 w-[207.125px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <SmileIcon />
        <Span5 />
        <Span6 />
        <Button2 />
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[52px] items-center left-[28px] top-[584px] w-[763px]" data-name="Container">
      <Container8 />
      <Container9 />
    </div>
  );
}

function ImageWithFallback() {
  return (
    <div className="absolute h-[470.484px] left-0 opacity-90 top-0 w-[763px]" data-name="ImageWithFallback">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageWithFallback} />
    </div>
  );
}

function MotionDiv1() {
  return (
    <div className="absolute h-[52.805px] left-[694.66px] top-[20px] w-[48.336px]" data-name="motion.div">
      <p className="absolute font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[52.8px] left-0 text-[#0a0a0a] text-[35.2px] top-[-1.5px] whitespace-nowrap">💨</p>
    </div>
  );
}

function Container13() {
  return <div className="absolute bg-[#51a2ff] h-[4px] left-0 rounded-[16777200px] top-0 w-[569.578px]" data-name="Container" />;
}

function Container14() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[2.91px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container15() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[11.63px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container16() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[27.14px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container17() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[43.63px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container18() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[61.08px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container19() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[75.62px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container20() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[92.1px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container21() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[117.3px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container22() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[145.42px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container23() {
  return <div className="absolute bg-[rgba(255,255,255,0.5)] left-[169.66px] rounded-[16777200px] size-[4px] top-0" data-name="Container" />;
}

function Container12() {
  return (
    <div className="bg-[rgba(255,255,255,0.2)] h-[4px] relative rounded-[16777200px] shrink-0 w-full" data-name="Container">
      <Container13 />
      <Container14 />
      <Container15 />
      <Container16 />
      <Container17 />
      <Container18 />
      <Container19 />
      <Container20 />
      <Container21 />
      <Container22 />
      <Container23 />
    </div>
  );
}

function SkipBack() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="SkipBack">
      <div className="absolute inset-[16.67%_20.83%_16.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-6.25%_-10%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 12">
            <path d={svgPaths.p35601980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[20.83%_79.17%_20.83%_20.83%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.33333 10.6667">
            <path d="M0.666667 10V0.666667" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-0 size-[16px] top-[8px]" data-name="button">
      <SkipBack />
    </div>
  );
}

function Pause() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Pause">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Pause">
          <path d={svgPaths.p8521c00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p897e280} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.2)] content-stretch flex items-center justify-center left-[24px] rounded-[16777200px] size-[32px] top-0" data-name="button">
      <Pause />
    </div>
  );
}

function SkipForward() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="SkipForward">
      <div className="absolute inset-[16.67%_37.5%_16.67%_20.83%]" data-name="Vector">
        <div className="absolute inset-[-6.25%_-10%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 12">
            <path d={svgPaths.p3c5f9380} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[20.83%_20.83%_20.83%_79.17%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.33333 10.6667">
            <path d="M0.666667 0.666667V10" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[64px] size-[16px] top-[8px]" data-name="button">
      <SkipForward />
    </div>
  );
}

function Volume() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Volume2">
      <div className="absolute inset-[16.66%_54.17%_16.65%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-6.25%_-11.11%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7.33333 12.004">
            <path d={svgPaths.p23c5d100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%_29.17%_37.5%_66.67%]" data-name="Vector">
        <div className="absolute inset-[-16.67%_-100%_-16.67%_-100.01%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.00004 5.33341">
            <path d={svgPaths.p3dd33d10} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[23.48%_8.33%_23.48%_80.68%]" data-name="Vector">
        <div className="absolute inset-[-7.86%_-37.94%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 3.09072 9.81867">
            <path d={svgPaths.p33513d80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[92px] size-[16px] top-[8px]" data-name="button">
      <Volume />
    </div>
  );
}

function Span8() {
  return (
    <div className="absolute content-stretch flex h-[17.281px] items-start left-[120px] top-[7.36px] w-[68.563px]" data-name="span">
      <p className="font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[17.28px] relative shrink-0 text-[11.52px] text-[rgba(255,255,255,0.5)] whitespace-nowrap">09:47 / 12:34</p>
    </div>
  );
}

function Container25() {
  return (
    <div className="h-[32px] relative shrink-0 w-[188.563px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button3 />
        <Button4 />
        <Button5 />
        <Button6 />
        <Span8 />
      </div>
    </div>
  );
}

function Settings() {
  return (
    <div className="h-[14px] overflow-clip relative shrink-0 w-full" data-name="Settings">
      <div className="absolute inset-[8.33%_12.43%]" data-name="Vector">
        <div className="absolute inset-[-5%_-5.54%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6872 12.8333">
            <path d={svgPaths.p19ed0080} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4.66667 4.66667">
            <path d={svgPaths.p22c75d80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.16667" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Settings />
      </div>
    </div>
  );
}

function Maximize() {
  return (
    <div className="h-[14px] overflow-clip relative shrink-0 w-full" data-name="Maximize2">
      <div className="absolute inset-[12.5%_12.5%_62.5%_62.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4.66667 4.66667">
            <path d={svgPaths.p282cab80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[62.5%_62.5%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4.66667 4.66667">
            <path d={svgPaths.p1d7fd880} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_12.5%_58.33%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.25 5.25">
            <path d={svgPaths.p16799680} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.16667" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[58.33%_58.33%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.25 5.25">
            <path d={svgPaths.p27dac600} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.16667" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="flex-[1_0_0] h-[14px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Maximize />
      </div>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[14px] relative shrink-0 w-[36px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Button7 />
        <Button8 />
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="content-stretch flex h-[32px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container25 />
      <Container26 />
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute bg-gradient-to-t content-stretch flex flex-col from-[rgba(15,23,43,0.85)] gap-[12px] h-[100px] items-start left-0 pt-[40px] px-[16px] to-[rgba(0,0,0,0)] top-[370.48px] w-[763px]" data-name="Container">
      <Container12 />
      <Container24 />
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute bg-[#0f172b] h-[470.484px] left-[28px] overflow-clip rounded-[16px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] top-[97.52px] w-[763px]" data-name="Container">
      <ImageWithFallback />
      <MotionDiv1 />
      <Container11 />
    </div>
  );
}

function Container4() {
  return (
    <div className="flex-[1_0_0] h-[664px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container5 />
        <Container7 />
        <Container10 />
      </div>
    </div>
  );
}

function Span9() {
  return <div className="bg-[#2b7fff] opacity-50 rounded-[16777200px] shrink-0 size-[6px]" data-name="span" />;
}

function H1() {
  return (
    <div className="flex-[1_0_0] h-[20.633px] min-h-px min-w-px relative" data-name="h3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[20.64px] relative shrink-0 text-[#1d293d] text-[13.76px] whitespace-nowrap">인식된 소리</p>
      </div>
    </div>
  );
}

function Span10() {
  return (
    <div className="bg-[#f1f5f9] h-[18.398px] relative rounded-[4px] shrink-0 w-[45.922px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[6px] py-[2px] relative size-full">
        <p className="font-['Noto_Sans_KR:Regular',sans-serif] font-normal leading-[14.4px] relative shrink-0 text-[#62748e] text-[9.6px] whitespace-nowrap">10/10개</p>
      </div>
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[20.633px] relative shrink-0 w-[135.078px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Span9 />
        <H1 />
        <Span10 />
      </div>
    </div>
  );
}

function ChevronRight() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="ChevronRight">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="ChevronRight">
          <path d="M5.25 10.5L8.75 7L5.25 3.5" id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[24px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <ChevronRight />
      </div>
    </div>
  );
}

function Div2() {
  return (
    <div className="h-[57px] relative shrink-0 w-[279px]" data-name="div">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-px px-[16px] relative size-full">
        <Container27 />
        <Button9 />
      </div>
    </div>
  );
}

function CheckSquare() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare />
      </div>
    </div>
  );
}

function Span11() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">00:03</p>
      </div>
    </div>
  );
}

function Span12() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">🐶</p>
      </div>
    </div>
  );
}

function Span13() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[60.906px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">강아지 짖음</p>
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span11 />
        <Span12 />
        <Span13 />
      </div>
    </div>
  );
}

function Container28() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button10 />
          <Button11 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare1() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare1 />
      </div>
    </div>
  );
}

function Span14() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">00:12</p>
      </div>
    </div>
  );
}

function Span15() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">🚪</p>
      </div>
    </div>
  );
}

function Span16() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[75.883px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">문 닫히는 소리</p>
      </div>
    </div>
  );
}

function Button13() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span14 />
        <Span15 />
        <Span16 />
      </div>
    </div>
  );
}

function Container29() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button12 />
          <Button13 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare2() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button14() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare2 />
      </div>
    </div>
  );
}

function Span17() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">00:28</p>
      </div>
    </div>
  );
}

function Span18() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">🎵</p>
      </div>
    </div>
  );
}

function Span19() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[72.391px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">배경음악 시작</p>
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span17 />
        <Span18 />
        <Span19 />
      </div>
    </div>
  );
}

function Container30() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button14 />
          <Button15 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare3() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button16() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare3 />
      </div>
    </div>
  );
}

function Span20() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">00:45</p>
      </div>
    </div>
  );
}

function Span21() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">👏</p>
      </div>
    </div>
  );
}

function Span22() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[49.422px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">박수 소리</p>
      </div>
    </div>
  );
}

function Button17() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span20 />
        <Span21 />
        <Span22 />
      </div>
    </div>
  );
}

function Container31() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button16 />
          <Button17 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare4() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button18() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare4 />
      </div>
    </div>
  );
}

function Span23() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">01:03</p>
      </div>
    </div>
  );
}

function Span24() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">🪟</p>
      </div>
    </div>
  );
}

function Span25() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[87.367px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">유리 깨지는 소리</p>
      </div>
    </div>
  );
}

function Button19() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span23 />
        <Span24 />
        <Span25 />
      </div>
    </div>
  );
}

function Container32() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button18 />
          <Button19 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare5() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button20() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare5 />
      </div>
    </div>
  );
}

function Span26() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">01:18</p>
      </div>
    </div>
  );
}

function Span27() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">📞</p>
      </div>
    </div>
  );
}

function Span28() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[60.906px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">전화벨 소리</p>
      </div>
    </div>
  );
}

function Button21() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span26 />
        <Span27 />
        <Span28 />
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button20 />
          <Button21 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare6() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button22() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare6 />
      </div>
    </div>
  );
}

function Span29() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">01:35</p>
      </div>
    </div>
  );
}

function Span30() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">🌧️</p>
      </div>
    </div>
  );
}

function Span31() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[34.445px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">빗소리</p>
      </div>
    </div>
  );
}

function Button23() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span29 />
        <Span30 />
        <Span31 />
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button22 />
          <Button23 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare7() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button24() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare7 />
      </div>
    </div>
  );
}

function Span32() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">02:01</p>
      </div>
    </div>
  );
}

function Span33() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">🎤</p>
      </div>
    </div>
  );
}

function Span34() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[49.422px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">노래 소리</p>
      </div>
    </div>
  );
}

function Button25() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span32 />
        <Span33 />
        <Span34 />
      </div>
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button24 />
          <Button25 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare8() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button26() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare8 />
      </div>
    </div>
  );
}

function Span35() {
  return (
    <div className="absolute content-stretch flex h-[16.32px] items-start left-0 top-[2.63px] w-[41.594px]" data-name="span">
      <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#155dfc] text-[10.88px]">02:30</p>
    </div>
  );
}

function Span36() {
  return (
    <div className="absolute h-[21.594px] left-[51.59px] top-0 w-[19.773px]" data-name="span">
      <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">💨</p>
    </div>
  );
}

function Span37() {
  return (
    <div className="absolute content-stretch flex h-[18.711px] items-start left-[81.37px] overflow-clip top-[1.44px] w-[49.422px]" data-name="span">
      <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#1447e6] text-[12.48px] whitespace-nowrap">바람 소리</p>
    </div>
  );
}

function MotionSpan3() {
  return <div className="bg-[#51a2ff] h-[3px] rounded-[16777200px] shrink-0 w-[2px]" data-name="motion.span" />;
}

function MotionSpan4() {
  return <div className="bg-[#51a2ff] h-[3px] rounded-[16777200px] shrink-0 w-[2px]" data-name="motion.span" />;
}

function MotionSpan5() {
  return <div className="bg-[#51a2ff] flex-[1_0_0] h-[3px] min-h-px min-w-px rounded-[16777200px]" data-name="motion.span" />;
}

function Span38() {
  return (
    <div className="absolute content-stretch flex gap-[2px] h-[12px] items-end left-[205px] top-[4.8px] w-[10px]" data-name="span">
      <MotionSpan3 />
      <MotionSpan4 />
      <MotionSpan5 />
    </div>
  );
}

function Button27() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Span35 />
        <Span36 />
        <Span37 />
        <Span38 />
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div className="bg-[#eff6ff] h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#dbeafe] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button26 />
          <Button27 />
        </div>
      </div>
    </div>
  );
}

function CheckSquare9() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="CheckSquare">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p10788d00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[16.67%_8.33%_41.67%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-10%_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 8">
            <path d={svgPaths.pcb8d0c0} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button28() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <CheckSquare9 />
      </div>
    </div>
  );
}

function Span39() {
  return (
    <div className="h-[16.32px] relative shrink-0 w-[41.594px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[16.32px] min-h-px min-w-px relative text-[#90a1b9] text-[10.88px]">02:55</p>
      </div>
    </div>
  );
}

function Span40() {
  return (
    <div className="h-[21.594px] relative shrink-0 w-[19.773px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[21.6px] left-0 text-[#0a0a0a] text-[14.4px] top-[-2.5px] whitespace-nowrap">🦅</p>
      </div>
    </div>
  );
}

function Span41() {
  return (
    <div className="h-[18.711px] relative shrink-0 w-[37.945px]" data-name="span">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#314158] text-[12.48px] whitespace-nowrap">새 소리</p>
      </div>
    </div>
  );
}

function Button29() {
  return (
    <div className="flex-[1_0_0] h-[21.594px] min-h-px min-w-px relative" data-name="button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative size-full">
        <Span39 />
        <Span40 />
        <Span41 />
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[39.594px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11px] py-px relative size-full">
          <Button28 />
          <Button29 />
        </div>
      </div>
    </div>
  );
}

function Div3() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[279px]" data-name="div">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-px items-start pt-[8px] px-[8px] relative size-full">
          <Container28 />
          <Container29 />
          <Container30 />
          <Container31 />
          <Container32 />
          <Container33 />
          <Container34 />
          <Container35 />
          <Container36 />
          <Container37 />
        </div>
      </div>
    </div>
  );
}

function Button30() {
  return (
    <div className="bg-[#eff6ff] content-stretch flex h-[34.711px] items-center justify-center py-[8px] relative rounded-[10px] shrink-0 w-full" data-name="button">
      <p className="font-['Noto_Sans_KR:Medium',sans-serif] font-medium leading-[18.72px] relative shrink-0 text-[#1447e6] text-[12.48px] text-center whitespace-nowrap">새 영상 변환하기</p>
    </div>
  );
}

function Div4() {
  return (
    <div className="h-[59.711px] relative shrink-0 w-[279px]" data-name="div">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-solid border-t inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[13px] px-[12px] relative size-full">
        <Button30 />
      </div>
    </div>
  );
}

function MotionAside() {
  return (
    <div className="bg-white h-[664px] relative shrink-0 w-[280px]" data-name="motion.aside">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-l border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-px relative size-full">
        <Div2 />
        <Div3 />
        <Div4 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[1099px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <Container4 />
        <MotionAside />
      </div>
    </div>
  );
}

function Div() {
  return (
    <div className="bg-[rgba(248,250,252,0.5)] content-stretch flex flex-col h-[716px] items-start relative shrink-0 w-full" data-name="div">
      <Header />
      <Container3 />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="영상 수정 페이지">
      <Div />
    </div>
  );
}