Design a modern desktop web application UI for an AI video caption platform for hearing accessibility.

Use a clean SaaS design style with a blue color theme inspired by hearing accessibility.

All interface text, buttons, and labels should be in Korean.

Create 4 main screens and connect them with simple user flows.

Screen 1 — Login Page

Design a login page.

Layout:

Center section:

Before / After video comparison

Left: normal video

Right: video with AI sound captions

Headline:

"눈으로 들으세요"

Description:

"AI가 영상 속 소리를 인식하여 자막과 이모티콘으로 보여줍니다."

Bottom section:

Large Kakao login button

Text:

"카카오톡으로 로그인"

Interaction:

When the Kakao login button is clicked,
the user should navigate to the Main Dashboard screen.

Screen 2 — Main Dashboard

Main workspace where users manage drives and videos.

Top Navigation Bar:

Left:

App logo

Right:

User profile avatar

Left Sidebar:

Title:

"드라이브"

Drive list showing drives shared with friends.

Buttons at bottom:

"친구 찾기"

"드라이브 만들기"

Main Content Area:

Grid layout displaying uploaded videos.

Top Center Filter Buttons:

"정렬"

"전체 영상"

"내가 만든 영상"

"내가 저장한 영상"

Floating Action Button (bottom right):

If user is inside My Drive

Show buttons:

"변환하기"

"업로드 하기"

If user is inside Shared Drive

Show buttons:

"공유하기"

"가져오기"

Interaction:

When the user clicks any of these action buttons
("변환하기", "업로드 하기", "공유하기", "가져오기")

the user should navigate to the Video Caption Generation Page.

Screen 3 — Video Caption Generation Page

Page where the user uploads a video and generates AI captions.

Layout:

Center:

Large video preview area

Below video:

Button:

"영상 업로드"

Button:

"AI 자막 생성"

Right Settings Panel:

Options:

"자막 표시"

"이모티콘 표시"

"소리 인식 민감도"

Bottom section:

AI processing progress bar

Text example:

"AI가 영상 속 소리를 분석 중입니다"

Screen 4 — Video Result / Playback Page

Video player showing generated captions and sound icons.

Center:

Large video player

Bottom center:

Dynamic captions showing detected sounds

Examples:

"[문 닫힘]"

"[강아지 짖음]"

Bottom left:

Toggle switch

"이모티콘 표시 ON / OFF"

Right side vertical panel:

Timeline of detected sounds

Each entry shows:

timestamp

sound type

Example:

00:12 강아지 짖음

00:28 문 닫힘

01:03 유리 깨짐

Panel includes a collapse / expand button.