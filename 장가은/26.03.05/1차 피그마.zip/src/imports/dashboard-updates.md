Update the Main Dashboard page (the first page after Kakao login) with the following strict rules.
Do not ignore these requirements.

--------------------------------------------------
1) REMOVE AI LABEL ON VIDEO CARDS
- Remove the top-left label/tag on each video thumbnail.
- Specifically delete any label such as: "AI 자막 표시" (or similar).

--------------------------------------------------
2) CHANGE "SAVED" TO "LIKED"
- Replace the tab/category "내가 저장한 영상" with "좋아요 누른 영상".
- The filter tabs should be:
  - "전체 영상"
  - "내가 만든 영상"
  - "좋아요 누른 영상"

--------------------------------------------------
3) CLEAR DRIVE SEPARATION (VERY IMPORTANT)
In the left sidebar, clearly separate drives into two groups with distinct styling:

A) "내 드라이브"
- visually grouped in its own section
- include a clear section header
- include a prominent button: "드라이브 만들기" (for my drives only)

B) "친구 드라이브"
- visually grouped in a separate section, clearly separated from "내 드라이브"
- include a clear section header
- show friend/people icon and/or different background tint to distinguish
- each friend drive item should show drive name + small friend avatar(s)

The separation must be obvious at a glance.

--------------------------------------------------
4) REMOVE THE MENU SECTION
- Remove any extra "메뉴" area or menu panel.
- Keep only: top bar (logo + profile), left sidebar (drives), main content (videos).

--------------------------------------------------
5) THREE-DOT MENU ON EACH VIDEO CARD (MY DRIVE ONLY)
- In "내 드라이브" context, each video card should have a three-dot (⋯) button.
- Clicking it opens a small dropdown with:
  - "편집"
  - "삭제"
- These options should not appear for friend videos that I did not upload.

--------------------------------------------------
6) FRIEND DRIVE RULES
In "친구 드라이브" context:

A) Like button behavior
- Each video card should show a Like (heart) button.
- When the user likes a video, it should appear in the "좋아요 누른 영상" tab.

B) Edit/Delete for my own uploads inside friend drives
- If the video in a friend drive was uploaded by me, show the three-dot menu (⋯) with:
  - "편집"
  - "삭제"
- If the video was uploaded by someone else, do NOT show edit/delete.

--------------------------------------------------
7) DISTINCT ACTION BUTTONS FOR EACH CONTEXT (VERY IMPORTANT)
The primary action buttons must be clearly different between contexts:

A) My Drive
- Prominent primary button: "드라이브 만들기"
- Video actions can include: "업로드 하기" and/or "변환하기"
- Use a clear blue primary style for my drive creation.

B) Friend Drive
- Prominent primary button: "가져오기"
- This button must look clearly different from "드라이브 만들기"
  (different icon, different color shade, or different button style such as outline vs solid)
- In friend drive context, emphasize collaboration/import behavior.

Make it immediately obvious whether the user is in "내 드라이브" or "친구 드라이브" by the action button styling and the page header context.

--------------------------------------------------
8) DESIGN STYLE
- White background (light theme)
- Blue as the primary accent color
- Clean modern SaaS dashboard layout
- Clear spacing and readability