/**
 * Shared video edit state management for Result Player
 * Handles state persistence and initialization across all entry paths
 * 
 * FLOW OVERVIEW:
 * 
 * 1. Entry Path: Dashboard → Click Video
 *    - User clicks video card in "내 드라이브"
 *    - Dashboard calls openResultPlayer(video)
 *    - Creates VideoEditState using createVideoEditStateFromSounds()
 *    - Navigates to /result with state
 *    - Saves to localStorage for persistence
 * 
 * 2. Entry Path: Dashboard → Upload/Convert → AI Caption Generate
 *    - User clicks FAB button → navigates to /caption
 *    - User uploads video and clicks "AI 자막 생성"
 *    - handleGenerate() processes video and detects sounds
 *    - Creates VideoEditState using createVideoEditStateFromSounds()
 *    - Saves to localStorage
 *    - Navigates to /result with state after completion
 * 
 * 3. Result Player Initialization:
 *    - initializeVideoEditState() checks in order:
 *      a. Route state (from navigation)
 *      b. localStorage (persisted from previous session)
 *      c. Default state (fallback with sample data)
 *    - Result Player always initializes correctly regardless of entry path
 * 
 * 4. State Persistence:
 *    - Timeline visibility changes → saved to localStorage
 *    - Emoji toggle changes → saved to localStorage
 *    - User can refresh page or navigate away and return with preserved state
 * 
 * 5. Direct Entry / Refresh Handling:
 *    - If user refreshes /result page, loads from localStorage
 *    - If localStorage is empty, uses default state with sample video
 *    - Never renders broken/empty player state
 */

export type TimelineItem = {
  id: number;
  time: string;
  emoji: string;
  label: string;
  colorClass: string;
  visible: boolean;
  type?: "environmental" | "speech"; // environmental = 환경음, speech = 사람 말소리
};

export type VideoEditState = {
  version?: number; // Schema version for migration
  videoId?: string;
  videoTitle?: string;
  videoThumbnail?: string;
  videoSource?: string;
  timeline: TimelineItem[];
  emojiOn: boolean;
  vibrationOn: boolean;
  captionOn: boolean;
  sensitivity?: number;
  captionStyle?: string;
  duration?: number;
};

const STORAGE_KEY = "soundsee_video_edit_state";
const CURRENT_VERSION = 3; // Increment when schema changes

// Default timeline for fallback
const DEFAULT_TIMELINE: TimelineItem[] = [
  { id: 0, time: "00:03", emoji: "💥", label: "펑 소리",            colorClass: "bg-amber-50  text-amber-700  border-amber-100",  visible: true, type: "environmental" },
  { id: 1, time: "00:06", emoji: "💬", label: "와 진짜 크다!",       colorClass: "bg-slate-50  text-slate-700  border-slate-200",  visible: true, type: "speech" },
  { id: 2, time: "00:12", emoji: "🎆", label: "큰 터지는 소리",     colorClass: "bg-purple-50 text-purple-700 border-purple-100", visible: true, type: "environmental" },
  { id: 3, time: "00:20", emoji: "👥", label: "사람들 웅성거림",     colorClass: "bg-pink-50   text-pink-700   border-pink-100",   visible: true, type: "environmental" },
  { id: 4, time: "00:28", emoji: "🎵", label: "배경음악 시작",      colorClass: "bg-cyan-50   text-cyan-700   border-cyan-100",   visible: true, type: "environmental" },
  { id: 5, time: "00:35", emoji: "💬", label: "지금 터진 거 봤어?", colorClass: "bg-slate-50  text-slate-700  border-slate-200",  visible: true, type: "speech" },
  { id: 6, time: "00:45", emoji: "👏", label: "박수 소리",          colorClass: "bg-green-50  text-green-700  border-green-100",  visible: true, type: "environmental" },
  { id: 7, time: "00:52", emoji: "💬", label: "와 대박이다!",       colorClass: "bg-slate-50  text-slate-700  border-slate-200",  visible: true, type: "speech" },
  { id: 8, time: "01:03", emoji: "🧨", label: "연속 폭발음",        colorClass: "bg-rose-50   text-rose-700   border-rose-100",   visible: true, type: "environmental" },
  { id: 9, time: "01:15", emoji: "💬", label: "사진 찍어!",         colorClass: "bg-slate-50  text-slate-700  border-slate-200",  visible: true, type: "speech" },
  { id: 10, time: "01:25", emoji: "🎇", label: "불꽃 치솟는 소리",  colorClass: "bg-amber-50  text-amber-700  border-amber-100",  visible: true, type: "environmental" },
  { id: 11, time: "01:40", emoji: "📣", label: "환호 소리",          colorClass: "bg-blue-50   text-blue-700   border-blue-100",   visible: true, type: "environmental" },
  { id: 12, time: "02:01", emoji: "💬", label: "아 진짜 예쁘다",    colorClass: "bg-slate-50  text-slate-700  border-slate-200",  visible: true, type: "speech" },
  { id: 13, time: "02:30", emoji: "💨", label: "바람 소리",          colorClass: "bg-teal-50   text-teal-700   border-teal-100",   visible: true, type: "environmental" },
];

const DEFAULT_VIDEO_THUMBNAIL = "https://images.unsplash.com/photo-1729931597118-e49ddbea68ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdodCUyMHNreSUyMGZpcmV3b3JrcyUyMGNvbG9yZnVsJTIwZXhwbG9zaW9uJTIwY2VsZWJyYXRpb258ZW58MXx8fHwxNzcyNjAxMDMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

/**
 * Save video edit state to localStorage
 */
export function saveVideoEditState(state: VideoEditState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.error("Failed to save video edit state:", error);
  }
}

/**
 * Load video edit state from localStorage
 */
export function loadVideoEditState(): VideoEditState | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error("Failed to load video edit state:", error);
  }
  return null;
}

/**
 * Get default video edit state
 */
export function getDefaultVideoEditState(): VideoEditState {
  return {
    version: CURRENT_VERSION,
    videoId: "default-video",
    videoTitle: "Sample Video",
    videoThumbnail: DEFAULT_VIDEO_THUMBNAIL,
    videoSource: DEFAULT_VIDEO_THUMBNAIL,
    timeline: DEFAULT_TIMELINE,
    emojiOn: true,
    vibrationOn: true,
    captionOn: true,
    sensitivity: 70,
    captionStyle: "기본",
    duration: 754,
  };
}

/**
 * Migrate timeline items to add missing type field
 */
function migrateTimeline(timeline: TimelineItem[]): TimelineItem[] {
  return timeline.map(item => ({
    ...item,
    type: item.type || "environmental", // Default to environmental if missing
  }));
}

/**
 * Initialize video edit state for Result Player
 * Priority: route state > localStorage > default
 */
export function initializeVideoEditState(routeState?: VideoEditState): VideoEditState {
  // Priority 1: Use route state if provided
  if (routeState && routeState.timeline && routeState.timeline.length > 0) {
    // Migrate timeline if needed
    const migratedState = {
      ...routeState,
      version: CURRENT_VERSION,
      timeline: migrateTimeline(routeState.timeline),
    };
    // Save to localStorage for future use
    saveVideoEditState(migratedState);
    return migratedState;
  }

  // Priority 2: Load from localStorage
  const stored = loadVideoEditState();
  if (stored && stored.timeline && stored.timeline.length > 0) {
    // Check version and force refresh if outdated (labels/data may have changed)
    if (!stored.version || stored.version < CURRENT_VERSION) {
      // Old version: replace with fresh defaults to pick up new labels & types
      const defaultState = getDefaultVideoEditState();
      saveVideoEditState(defaultState);
      return defaultState;
    }
    return stored;
  }

  // Priority 3: Use default
  const defaultState = getDefaultVideoEditState();
  saveVideoEditState(defaultState);
  return defaultState;
}

/**
 * Clear stored video edit state
 */
export function clearVideoEditState(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error("Failed to clear video edit state:", error);
  }
}

/**
 * Create video edit state from detected sounds (used after AI generation)
 */
export function createVideoEditStateFromSounds(
  sounds: Array<{ id: number; time: string; emoji: string; text: string; type?: "environmental" | "speech" }>,
  options?: {
    videoId?: string;
    videoTitle?: string;
    videoThumbnail?: string;
    videoSource?: string;
    emojiOn?: boolean;
    vibrationOn?: boolean;
    captionOn?: boolean;
    sensitivity?: number;
    captionStyle?: string;
    duration?: number;
  }
): VideoEditState {
  const colorClasses = [
    "bg-amber-50  text-amber-700  border-amber-100",
    "bg-slate-50  text-slate-700  border-slate-200",
    "bg-purple-50 text-purple-700 border-purple-100",
    "bg-pink-50   text-pink-700   border-pink-100",
    "bg-cyan-50   text-cyan-700   border-cyan-100",
    "bg-green-50  text-green-700  border-green-100",
    "bg-blue-50   text-blue-700   border-blue-100",
    "bg-rose-50   text-rose-700   border-rose-100",
    "bg-teal-50   text-teal-700   border-teal-100",
    "bg-lime-50   text-lime-700   border-lime-100",
  ];

  const timeline: TimelineItem[] = sounds.map((sound, index) => ({
    id: sound.id,
    time: sound.time,
    emoji: sound.emoji,
    label: sound.text,
    colorClass: colorClasses[index % colorClasses.length],
    visible: true,
    type: sound.type || "environmental",
  }));

  return {
    version: CURRENT_VERSION,
    videoId: options?.videoId || `video-${Date.now()}`,
    videoTitle: options?.videoTitle || "New Video",
    videoThumbnail: options?.videoThumbnail || DEFAULT_VIDEO_THUMBNAIL,
    videoSource: options?.videoSource || DEFAULT_VIDEO_THUMBNAIL,
    timeline,
    emojiOn: options?.emojiOn ?? true,
    vibrationOn: options?.vibrationOn ?? true,
    captionOn: options?.captionOn ?? true,
    sensitivity: options?.sensitivity ?? 70,
    captionStyle: options?.captionStyle ?? "기본",
    duration: options?.duration ?? 754,
  };
}