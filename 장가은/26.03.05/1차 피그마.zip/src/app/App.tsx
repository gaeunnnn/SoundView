import { RouterProvider } from "react-router";
import { router } from "./routes";

export default function App() {
  return (
    <div
      className="size-full"
      style={{ fontFamily: "'Noto Sans KR', sans-serif" }}
    >
      <RouterProvider router={router} />
    </div>
  );
}