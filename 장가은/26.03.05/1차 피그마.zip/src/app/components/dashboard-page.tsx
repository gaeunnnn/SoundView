import { useState, useEffect, useRef, forwardRef, useCallback } from "react";
import { useNavigate, useOutletContext } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { createVideoEditStateFromSounds, saveVideoEditState } from "../utils/video-state";
import {
  SlidersHorizontal,
  Play,
  MoreHorizontal,
  Wand2,
  CheckCircle2,
  Clock,
  ChevronDown,
  X,
  Heart,
  Edit,
  Trash2,
  Share2,
  AlertTriangle,
  Check,
  Users,
  Pencil,
  FolderInput,
  Film,
  MessageCircle,
  Send,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import type { LayoutContext } from "./app-layout";
import { DRIVES } from "./app-layout";
import type { CustomDrive } from "./app-layout";

// ── Images ───────────────────────────────────────────────────────────────────
const IMG_FIREWORK = "https://images.unsplash.com/photo-1753614982374-07f89c5024a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXJld29ya3MlMjBuaWdodCUyMHNreSUyMGZlc3RpdmFsfGVufDF8fHx8MTc3MjY0ODg3OHww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_ALLEY    = "https://images.unsplash.com/photo-1562829612-55b71f529a49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXJyb3clMjBhbGxleSUyMHN0cmVldCUyMGV2ZW5pbmclMjBrb3JlYXxlbnwxfHx8fDE3NzI2NzU0MTV8MA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_FOOD     = "https://images.unsplash.com/photo-1758779527927-56c21385ffce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMG1lYWwlMjBjaG9wc3RpY2tzJTIwcGxhdGUlMjByZXN0YXVyYW50fGVufDF8fHx8MTc3MjY3NTY4M3ww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_LATTE    = "https://images.unsplash.com/photo-1758180447681-970a25db7d98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWZlJTIwbGF0dGUlMjBhcnQlMjB0YWJsZSUyMGNvenl8ZW58MXx8fHwxNzcyNjc1NDE2fDA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_BRUNCH   = "https://images.unsplash.com/photo-1707222634706-e781864429fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicnVuY2glMjBwYW5jYWtlJTIwdGFibGUlMjBtb3JuaW5nfGVufDF8fHx8MTc3MjY3NTQyMHww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_RAINY    = "https://images.unsplash.com/photo-1638228236517-799a136763b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyYWlueSUyMHN0cmVldCUyMG5pZ2h0JTIwcmVmbGVjdGlvbiUyMHVyYmFufGVufDF8fHx8MTc3MjY3NTQxN3ww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_CAFE     = "https://images.unsplash.com/photo-1698548551773-ab5d78e994a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBjYWZlJTIwbGF0dGUlMjBjYXN1YWwlMjBzbWFydHBob25lfGVufDF8fHx8MTc3MjY3NTE1NHww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_SUNSET   = "https://images.unsplash.com/photo-1770021601385-af0bf0136762?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjByb29mdG9wJTIwY2l0eSUyMGV2ZW5pbmclMjBjYXN1YWx8ZW58MXx8fHwxNzcyNjc1NjgxfDA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_STREET_FOOD = "https://images.unsplash.com/photo-1761530481145-ff0a52e9e6ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBzdHJlZXQlMjBmb29kJTIwbWFya2V0JTIwbmlnaHR8ZW58MXx8fHwxNzcyNjAwNzM2fDA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_CHERRY    = "https://images.unsplash.com/photo-1615385649416-7ad33576b332?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVycnklMjBibG9zc29tJTIwcGFyayUyMHNwcmluZyUyMHdhbGt8ZW58MXx8fHwxNzcyNjk1MjgwfDA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_BOOKSTORE = "https://images.unsplash.com/photo-1739133087944-0a6311a2319b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwYm9va3N0b3JlJTIwcmVhZGluZyUyMGNvcm5lcnxlbnwxfHx8fDE3NzI2OTUyODB8MA&ixlib=rb-4.1.0&q=80&w=400";
const IMG_CAT       = "https://images.unsplash.com/photo-1705134770413-a0d76c25d895?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXQlMjBzbGVlcGluZyUyMHdpbmRvdyUyMHN1bmxpZ2h0fGVufDF8fHx8MTc3MjY5NTI4MXww&ixlib=rb-4.1.0&q=80&w=400";
const IMG_BEACH     = "https://images.unsplash.com/photo-1626559429369-37a6b6c71f3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFjaCUyMHdhdmVzJTIwb2NlYW4lMjBzdW5zZXQlMjB3YWxrfGVufDF8fHx8MTc3MjY5NTI4MXww&ixlib=rb-4.1.0&q=80&w=400";

type SortKey = "최신순" | "오래된 순" | "이름 순" | "길이 순";

// ── Reaction & Comment types ─────────────────────────────────────────────────
const REACTION_EMOJIS = ["👍", "❤️", "😂", "🔥", "👏"] as const;
type ReactionKey = typeof REACTION_EMOJIS[number];

type Comment = {
  id: number;
  author: string;
  text: string;
  time: string;
};

// Mock initial reactions & comments per video (keyed by video id)
const INITIAL_REACTIONS: Record<number, Record<ReactionKey, number>> = {
  1: { "👍": 2, "❤️": 1, "😂": 0, "🔥": 3, "👏": 0 },
  3: { "👍": 1, "❤️": 0, "😂": 1, "🔥": 0, "👏": 0 },
  6: { "👍": 1, "❤️": 2, "😂": 0, "🔥": 0, "👏": 1 },
  7: { "👍": 0, "❤️": 1, "😂": 1, "🔥": 0, "👏": 0 },
  8: { "👍": 0, "❤️": 1, "😂": 0, "🔥": 0, "👏": 0 },
  9: { "👍": 3, "❤️": 1, "😂": 0, "🔥": 2, "👏": 0 },
  10: { "👍": 0, "❤️": 3, "😂": 0, "🔥": 0, "👏": 0 },
  11: { "👍": 1, "❤️": 0, "😂": 2, "🔥": 0, "👏": 0 },
  12: { "👍": 0, "❤️": 2, "😂": 0, "🔥": 1, "👏": 1 },
  13: { "👍": 2, "❤️": 0, "😂": 0, "🔥": 0, "👏": 0 },
};
const INITIAL_MY_REACTIONS: Record<number, ReactionKey[]> = {
  6: ["❤️"],
  10: ["❤️"],
};
const INITIAL_COMMENTS: Record<number, Comment[]> = {
  1: [
    { id: 1, author: "김지은", text: "불꽃놀이 영상 대박이다!! 🎆", time: "4일 전" },
    { id: 2, author: "박민준", text: "이거 어디서 찍은 거야?", time: "4일 전" },
    { id: 3, author: "김지은", text: "한강이래!", time: "3일 전" },
  ],
  3: [
    { id: 1, author: "김지은", text: "우리 그날 진짜 맛있었는데 ㅋㅋ", time: "2일 전" },
  ],
  6: [
    { id: 1, author: "김지은", text: "이 카페 분위기 너무 좋다!", time: "2시간 전" },
    { id: 2, author: "박민준", text: "다음에 같이 가자 ☕", time: "1시간 전" },
  ],
  7: [
    { id: 1, author: "박준호", text: "노을 진짜 예쁘다 🌅", time: "3일 전" },
  ],
  8: [
    { id: 1, author: "김지은", text: "비 오는 날 감성 좋다 🌧️", time: "1주 전" },
  ],
  9: [
    { id: 1, author: "김지은", text: "여기 떡볶이 진짜 맛있었어!", time: "1일 전" },
    { id: 2, author: "박민준", text: "다음에 또 가자 🔥", time: "20시간 전" },
    { id: 3, author: "김지은", text: "ㅋㅋ 그때 너 순대 5인분 먹었잖아", time: "18시간 전" },
  ],
  10: [
    { id: 1, author: "김지은", text: "벚꽃 만개했을 때! 타이밍 완벽 🌸", time: "5일 전" },
  ],
  12: [
    { id: 1, author: "김지은", text: "우리 고양이 너무 귀여워 ㅠㅠ", time: "2일 전" },
    { id: 2, author: "박민준", text: "이름이 뭐야?", time: "2일 전" },
    { id: 3, author: "김지은", text: "모찌! 🐱", time: "1일 전" },
  ],
};

const ALL_VIDEOS = [
  { id: 1, title: "불꽃놀이",                thumb: IMG_FIREWORK, date: "2026.02.28", duration: "2:18",  owner: "my",    hasCaptions: true, liked: false, sharedTo: ["jieun"] },
  { id: 2, title: "퇴근길 골목 풍경",        thumb: IMG_ALLEY,    date: "2026.02.25", duration: "1:45",  owner: "my",    hasCaptions: true, liked: true  },
  { id: 3, title: "친구들이랑 저녁 먹는 중",  thumb: IMG_FOOD,     date: "2026.02.20", duration: "2:10",  owner: "my",    hasCaptions: true, liked: false, sharedTo: ["jieun"] },
  { id: 4, title: "카페에서 라떼 한 잔",      thumb: IMG_LATTE,    date: "2026.02.18", duration: "0:58",  owner: "my",    hasCaptions: true, liked: true  },
  { id: 5, title: "주말 브런치",              thumb: IMG_BRUNCH,   date: "2026.02.15", duration: "1:23",  owner: "my",    hasCaptions: true, liked: false },
  { id: 6, title: "카페에서 찍은 짧은 영상",  thumb: IMG_CAFE,     date: "2026.02.10", duration: "1:42",  owner: "jieun", hasCaptions: true, liked: true  },
  { id: 7, title: "옥상에서 본 노을",         thumb: IMG_SUNSET,   date: "2026.02.08", duration: "1:35",  owner: "junho", hasCaptions: true, liked: false },
  { id: 8, title: "비 오는 날 거리",          thumb: IMG_RAINY,    date: "2026.02.01", duration: "2:07",  owner: "my",    hasCaptions: true, liked: true, sharedTo: ["jieun"]  },
  { id: 9, title: "야시장 먹방 투어",         thumb: IMG_STREET_FOOD, date: "2026.02.22", duration: "3:15", owner: "jieun", hasCaptions: true, liked: false },
  { id: 10, title: "벚꽃길 산책",              thumb: IMG_CHERRY,   date: "2026.02.17", duration: "2:03",  owner: "jieun", hasCaptions: true, liked: true  },
  { id: 11, title: "동네 서점 구경",            thumb: IMG_BOOKSTORE, date: "2026.02.12", duration: "1:28", owner: "jieun", hasCaptions: true, liked: false },
  { id: 12, title: "모찌의 낮잠 타임",          thumb: IMG_CAT,      date: "2026.02.06", duration: "0:45", owner: "jieun", hasCaptions: true, liked: true  },
  { id: 13, title: "해변 산책 브이로그",        thumb: IMG_BEACH,    date: "2026.01.30", duration: "2:52", owner: "jieun", hasCaptions: true, liked: false },
];

// Mock timeline data for each video (simulating detected sounds)
const MOCK_SOUNDS = [
  { id: 0, time: "00:03", emoji: "🐶", text: "강아지 짖음" },
  { id: 1, time: "00:12", emoji: "🚪", text: "문 닫히는 소리" },
  { id: 2, time: "00:28", emoji: "🎵", text: "배경음악 시작" },
  { id: 3, time: "00:45", emoji: "👏", text: "박수 소리" },
  { id: 4, time: "01:03", emoji: "🪟", text: "유리 깨지는 소리" },
  { id: 5, time: "01:18", emoji: "📞", text: "전화벨 소리" },
  { id: 6, time: "01:35", emoji: "🌧️", text: "빗소리" },
  { id: 7, time: "02:01", emoji: "🎤", text: "노래 소리" },
  { id: 8, time: "02:30", emoji: "💨", text: "바람 소리" },
  { id: 9, time: "02:55", emoji: "🦅", text: "새 소리" },
];

// Per-video AI captions (fully applied, environmental + speech)
type ViewerCaption = { id: number; time: string; emoji: string; label: string; type: "environmental" | "speech" };
const VIDEO_CAPTIONS: Record<number, ViewerCaption[]> = {
  1: [
    { id: 0, time: "00:03", emoji: "💥", label: "펑 소리", type: "environmental" },
    { id: 1, time: "00:06", emoji: "💬", label: "와 진짜 크다!", type: "speech" },
    { id: 2, time: "00:12", emoji: "🎆", label: "큰 터지는 소리", type: "environmental" },
    { id: 3, time: "00:20", emoji: "👥", label: "사람들 웅성거림", type: "environmental" },
    { id: 4, time: "00:28", emoji: "🎵", label: "배경음악 시작", type: "environmental" },
    { id: 5, time: "00:35", emoji: "💬", label: "지금 터진 거 봤어?", type: "speech" },
    { id: 6, time: "00:45", emoji: "👏", label: "박수 소리", type: "environmental" },
    { id: 7, time: "00:52", emoji: "💬", label: "와 대박이다!", type: "speech" },
    { id: 8, time: "01:03", emoji: "🧨", label: "연속 폭발음", type: "environmental" },
    { id: 9, time: "01:15", emoji: "💬", label: "사진 찍어!", type: "speech" },
    { id: 10, time: "01:25", emoji: "🎇", label: "불꽃 치솟는 소리", type: "environmental" },
    { id: 11, time: "01:40", emoji: "📣", label: "환호 소리", type: "environmental" },
    { id: 12, time: "02:01", emoji: "💬", label: "아 진짜 예쁘다", type: "speech" },
  ],
  2: [
    { id: 0, time: "00:02", emoji: "👣", label: "발걸음 소리", type: "environmental" },
    { id: 1, time: "00:15", emoji: "🚗", label: "차 지나가는 소리", type: "environmental" },
    { id: 2, time: "00:30", emoji: "🐈", label: "고양이 울음", type: "environmental" },
    { id: 3, time: "00:42", emoji: "💬", label: "여기 분위기 좋다", type: "speech" },
    { id: 4, time: "01:05", emoji: "🍃", label: "바람에 나뭇잎 소리", type: "environmental" },
    { id: 5, time: "01:20", emoji: "🔔", label: "자전거 벨 소리", type: "environmental" },
    { id: 6, time: "01:35", emoji: "💬", label: "오늘 하루 힘들었다", type: "speech" },
  ],
  3: [
    { id: 0, time: "00:05", emoji: "🍳", label: "지글지글 굽는 소리", type: "environmental" },
    { id: 1, time: "00:12", emoji: "💬", label: "이거 진짜 맛있다!", type: "speech" },
    { id: 2, time: "00:28", emoji: "🥂", label: "잔 부딪히는 소리", type: "environmental" },
    { id: 3, time: "00:40", emoji: "😂", label: "웃음소리", type: "environmental" },
    { id: 4, time: "00:55", emoji: "💬", label: "한 입만 줘봐", type: "speech" },
    { id: 5, time: "01:10", emoji: "🍖", label: "고기 뒤집는 소리", type: "environmental" },
    { id: 6, time: "01:30", emoji: "💬", label: "더 시킬까?", type: "speech" },
    { id: 7, time: "01:50", emoji: "👏", label: "박수 소리", type: "environmental" },
    { id: 8, time: "02:02", emoji: "💬", label: "배불러~", type: "speech" },
  ],
  4: [
    { id: 0, time: "00:03", emoji: "☕", label: "커피 내리는 소리", type: "environmental" },
    { id: 1, time: "00:15", emoji: "🎵", label: "카페 배경음악", type: "environmental" },
    { id: 2, time: "00:30", emoji: "💬", label: "라떼 맛있다", type: "speech" },
    { id: 3, time: "00:45", emoji: "🥄", label: "스푼 젓는 소리", type: "environmental" },
  ],
  5: [
    { id: 0, time: "00:04", emoji: "🍽️", label: "접시 놓는 소리", type: "environmental" },
    { id: 1, time: "00:18", emoji: "💬", label: "와 예쁘다 이거!", type: "speech" },
    { id: 2, time: "00:35", emoji: "📸", label: "셔터 소리", type: "environmental" },
    { id: 3, time: "00:50", emoji: "🎵", label: "잔잔한 음악", type: "environmental" },
    { id: 4, time: "01:05", emoji: "💬", label: "먹기 아까워", type: "speech" },
  ],
  6: [
    { id: 0, time: "00:03", emoji: "☕", label: "에스프레소 추출 소리", type: "environmental" },
    { id: 1, time: "00:15", emoji: "🎵", label: "재즈 음악", type: "environmental" },
    { id: 2, time: "00:28", emoji: "💬", label: "여기 자주 와?", type: "speech" },
    { id: 3, time: "00:45", emoji: "🗣️", label: "대화 소리", type: "environmental" },
    { id: 4, time: "01:00", emoji: "💬", label: "분위기 진짜 좋다", type: "speech" },
    { id: 5, time: "01:20", emoji: "🥄", label: "찻잔 소리", type: "environmental" },
    { id: 6, time: "01:35", emoji: "💬", label: "다음에 또 오자!", type: "speech" },
  ],
  7: [
    { id: 0, time: "00:05", emoji: "💨", label: "바람 소리", type: "environmental" },
    { id: 1, time: "00:18", emoji: "💬", label: "와 하늘 봐봐", type: "speech" },
    { id: 2, time: "00:35", emoji: "🐦", label: "새 소리", type: "environmental" },
    { id: 3, time: "00:50", emoji: "📸", label: "셔터 소리", type: "environmental" },
    { id: 4, time: "01:05", emoji: "💬", label: "오늘 노을 미쳤다", type: "speech" },
    { id: 5, time: "01:25", emoji: "✈️", label: "비행기 소리", type: "environmental" },
  ],
  8: [
    { id: 0, time: "00:03", emoji: "🌧️", label: "빗소리", type: "environmental" },
    { id: 1, time: "00:20", emoji: "☂️", label: "우산에 빗방울 소리", type: "environmental" },
    { id: 2, time: "00:40", emoji: "💬", label: "비 진짜 많이 온다", type: "speech" },
    { id: 3, time: "01:00", emoji: "🚗", label: "차 물 튀기는 소리", type: "environmental" },
    { id: 4, time: "01:20", emoji: "⚡", label: "천둥 소리", type: "environmental" },
    { id: 5, time: "01:40", emoji: "💬", label: "빨리 들어가자", type: "speech" },
    { id: 6, time: "02:00", emoji: "👣", label: "물웅덩이 밟는 소리", type: "environmental" },
  ],
  9: [
    { id: 0, time: "00:05", emoji: "🔥", label: "불꽃 소리", type: "environmental" },
    { id: 1, time: "00:15", emoji: "💬", label: "이거 먹어볼까?", type: "speech" },
    { id: 2, time: "00:30", emoji: "🍳", label: "튀기는 소리", type: "environmental" },
    { id: 3, time: "00:50", emoji: "👥", label: "사람들 북적이는 소리", type: "environmental" },
    { id: 4, time: "01:10", emoji: "💬", label: "와 이거 대박", type: "speech" },
    { id: 5, time: "01:30", emoji: "🎵", label: "거리 음악", type: "environmental" },
    { id: 6, time: "01:50", emoji: "💬", label: "순대 5인분 주세요", type: "speech" },
    { id: 7, time: "02:10", emoji: "🛎️", label: "벨 소리", type: "environmental" },
    { id: 8, time: "02:30", emoji: "💬", label: "배 터지겠어 ㅋㅋ", type: "speech" },
    { id: 9, time: "03:00", emoji: "👏", label: "박수 소리", type: "environmental" },
  ],
  10: [
    { id: 0, time: "00:04", emoji: "🌸", label: "꽃잎 떨어지는 소리", type: "environmental" },
    { id: 1, time: "00:18", emoji: "💬", label: "진짜 예쁘다!", type: "speech" },
    { id: 2, time: "00:35", emoji: "🐦", label: "새 지저귀는 소리", type: "environmental" },
    { id: 3, time: "00:50", emoji: "💨", label: "바람 소리", type: "environmental" },
    { id: 4, time: "01:10", emoji: "💬", label: "여기서 사진 찍자", type: "speech" },
    { id: 5, time: "01:30", emoji: "📸", label: "셔터 소리", type: "environmental" },
    { id: 6, time: "01:50", emoji: "💬", label: "타이밍 완벽이다", type: "speech" },
  ],
  11: [
    { id: 0, time: "00:03", emoji: "📖", label: "책 넘기는 소리", type: "environmental" },
    { id: 1, time: "00:20", emoji: "🎵", label: "잔잔한 배경음악", type: "environmental" },
    { id: 2, time: "00:35", emoji: "💬", label: "이 책 재밌어 보인다", type: "speech" },
    { id: 3, time: "00:55", emoji: "👣", label: "발걸음 소리", type: "environmental" },
    { id: 4, time: "01:10", emoji: "💬", label: "여기 분위기 좋다", type: "speech" },
  ],
  12: [
    { id: 0, time: "00:02", emoji: "🐱", label: "골골 소리", type: "environmental" },
    { id: 1, time: "00:12", emoji: "💬", label: "모찌야 일어나", type: "speech" },
    { id: 2, time: "00:22", emoji: "😴", label: "코 고는 소리", type: "environmental" },
    { id: 3, time: "00:32", emoji: "💬", label: "너무 귀엽다 ㅠㅠ", type: "speech" },
    { id: 4, time: "00:40", emoji: "🐈", label: "하품 소리", type: "environmental" },
  ],
  13: [
    { id: 0, time: "00:05", emoji: "🌊", label: "파도 소리", type: "environmental" },
    { id: 1, time: "00:20", emoji: "💬", label: "바다 진짜 좋다", type: "speech" },
    { id: 2, time: "00:45", emoji: "🐚", label: "조개 밟는 소리", type: "environmental" },
    { id: 3, time: "01:05", emoji: "💨", label: "바람 소리", type: "environmental" },
    { id: 4, time: "01:25", emoji: "💬", label: "저기 일몰 봐", type: "speech" },
    { id: 5, time: "01:50", emoji: "🦅", label: "갈매기 소리", type: "environmental" },
    { id: 6, time: "02:15", emoji: "💬", label: "다음에 또 와야지", type: "speech" },
    { id: 7, time: "02:40", emoji: "🌅", label: "파도 크게 치는 소리", type: "environmental" },
  ],
};

function parseDuration(d: string): number {
  const parts = d.split(":").map(Number);
  return parts[0] * 60 + parts[1];
}

// ── Video Card ───────────────────────────────────────────────────────────────
type VideoCardProps = {
  video: typeof ALL_VIDEOS[0]; 
  onPlay: () => void;
  activeDriveId: string;
  onLikeToggle: (id: number) => void;
  onEdit?: (video: typeof ALL_VIDEOS[0]) => void;
  onShare?: (video: typeof ALL_VIDEOS[0]) => void;
  onDelete?: (video: typeof ALL_VIDEOS[0]) => void;
  onRenameTitle?: (videoId: number, newTitle: string) => void;
  isMenuOpen: boolean;
  onToggleMenu: (videoId: number) => void;
  onCloseMenu: () => void;
  onOpenComments?: (videoId: number) => void;
  commentCount?: number;
};

const VideoCard = forwardRef<HTMLDivElement, VideoCardProps>(function VideoCard({ 
  video, 
  onPlay, 
  activeDriveId, 
  onLikeToggle,
  onEdit,
  onShare,
  onDelete,
  onRenameTitle,
  isMenuOpen,
  onToggleMenu,
  onCloseMenu,
  onOpenComments,
  commentCount: commentCountProp,
}, ref) {
  const [isLiked, setIsLiked] = useState(video.liked);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editTitleValue, setEditTitleValue] = useState(video.title);
  const titleInputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  
  // Reactions & comments (shared drives only)
  const [reactions, setReactions] = useState<Record<ReactionKey, number>>(() => {
    const init = INITIAL_REACTIONS[video.id];
    return init ?? { "👍": 0, "❤️": 0, "😂": 0, "🔥": 0, "👏": 0 };
  });
  const [myReactions, setMyReactions] = useState<ReactionKey[]>(() => {
    return INITIAL_MY_REACTIONS[video.id] ?? [];
  });
  const commentCount = commentCountProp ?? 0;
  const [showReactionPicker, setShowReactionPicker] = useState(false);

  const isMyDrive = activeDriveId === "my";
  const isFriendDrive = activeDriveId !== "my";
  
  // Show edit/delete menu for ALL videos in my drive
  const showEditMenu = isMyDrive;
  
  // Show like button only in friend drives
  const showLikeButton = isFriendDrive;
  
  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
    onLikeToggle(video.id);
  };

  // Close menu on outside click
  useEffect(() => {
    if (!isMenuOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onCloseMenu();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isMenuOpen, onCloseMenu]);

  // Focus input when editing starts
  useEffect(() => {
    if (isEditingTitle && titleInputRef.current) {
      titleInputRef.current.focus();
      titleInputRef.current.select();
    }
  }, [isEditingTitle]);

  const handleTitleEditStart = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditTitleValue(video.title);
    setIsEditingTitle(true);
  };

  const handleTitleSave = () => {
    const trimmed = editTitleValue.trim();
    if (trimmed && trimmed !== video.title) {
      onRenameTitle?.(video.id, trimmed);
    }
    setIsEditingTitle(false);
  };

  const handleTitleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleTitleSave();
    } else if (e.key === "Escape") {
      setEditTitleValue(video.title);
      setIsEditingTitle(false);
    }
  };

  return (
    <motion.div
      ref={ref}
      className="bg-white rounded-2xl border border-slate-100 hover:border-slate-200 hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-all group overflow-hidden"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
      transition={{ duration: 0.3 }}
      layout
    >
      {/* Thumbnail — clickable to play */}
      <div className="relative aspect-video overflow-hidden bg-slate-50 cursor-pointer" onClick={onPlay}>
        <ImageWithFallback
          src={video.thumb}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-[1.04] transition-transform duration-700 ease-out"
        />
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <motion.button
            onClick={onPlay}
            className="w-11 h-11 rounded-full bg-white/95 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 shadow-xl"
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
          >
            <Play className="w-4 h-4 text-slate-800 ml-0.5" />
          </motion.button>
        </div>
        {/* Duration pill */}
        <div
          className="absolute bottom-2.5 right-2.5 bg-slate-900/75 text-white rounded-lg px-2 py-0.5 flex items-center gap-1"
          style={{ fontSize: "0.6rem", fontWeight: 500 }}
        >
          <Clock className="w-2.5 h-2.5 opacity-60" />
          {video.duration}
        </div>
        
        {/* Like button (Friend drives only) */}
        {showLikeButton && (
          <button
            onClick={handleLikeClick}
            className={`absolute top-2.5 left-2.5 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
              isLiked 
                ? "bg-red-500 text-white shadow-lg shadow-red-500/25" 
                : "bg-white/90 text-slate-400 hover:text-red-500 shadow-md"
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked ? "fill-current" : ""}`} />
          </button>
        )}
      </div>

      {/* Info */}
      <div className="px-3.5 py-3">
        <div className="flex items-start justify-between gap-1">
          {isEditingTitle ? (
            <input
              ref={titleInputRef}
              type="text"
              value={editTitleValue}
              onChange={(e) => setEditTitleValue(e.target.value)}
              onBlur={handleTitleSave}
              onKeyDown={handleTitleKeyDown}
              onClick={(e) => e.stopPropagation()}
              className="text-slate-800 flex-1 min-w-0 bg-slate-50 border border-blue-300 rounded-lg px-2 py-1 outline-none ring-2 ring-blue-100"
              style={{ fontSize: "0.82rem" }}
            />
          ) : (
            <div className="flex items-center gap-1 flex-1 min-w-0">
              <p className="text-slate-800 truncate" style={{ fontSize: "0.84rem", fontWeight: 520 }}>
                {video.title}
              </p>
              {isMyDrive && (
                <button
                  onClick={handleTitleEditStart}
                  className="shrink-0 w-5 h-5 flex items-center justify-center rounded-md text-slate-300 hover:text-blue-500 hover:bg-blue-50 transition-colors opacity-0 group-hover:opacity-100"
                  aria-label="제목 수정"
                >
                  <Pencil className="w-3 h-3" />
                </button>
              )}
            </div>
          )}
          
          {/* ⋯ menu button — always visible for all cards in my drive */}
          {showEditMenu && (
            <div className="relative shrink-0" ref={menuRef}>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  onToggleMenu(video.id);
                }}
                className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-slate-100 active:bg-slate-200 transition-colors text-slate-300 hover:text-slate-600"
                style={{ pointerEvents: "auto" }}
                aria-label="영상 메뉴"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>

              {/* Dropdown menu */}
              <AnimatePresence>
                {isMenuOpen && (
                  <motion.div
                    className="absolute right-0 top-8 w-36 bg-white border border-slate-100 rounded-xl py-1.5 z-[60]"
                    style={{
                      boxShadow: "0 12px 40px rgba(0,0,0,0.10), 0 2px 8px rgba(0,0,0,0.04)",
                    }}
                    onClick={(e) => e.stopPropagation()}
                    initial={{ opacity: 0, y: -4, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -4, scale: 0.96 }}
                    transition={{ duration: 0.12 }}
                  >
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onCloseMenu();
                        onEdit?.(video);
                      }}
                      className="flex items-center gap-2.5 w-full text-left px-3.5 py-2 hover:bg-slate-50 transition-colors text-slate-600 rounded-lg mx-0"
                      style={{ fontSize: "0.78rem" }}
                    >
                      <Edit className="w-3.5 h-3.5 text-slate-400" />
                      편집
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onCloseMenu();
                        onShare?.(video);
                      }}
                      className="flex items-center gap-2.5 w-full text-left px-3.5 py-2 hover:bg-slate-50 transition-colors text-slate-600 rounded-lg"
                      style={{ fontSize: "0.78rem" }}
                    >
                      <Share2 className="w-3.5 h-3.5 text-slate-400" />
                      공유
                    </button>
                    <div className="h-px bg-slate-100 my-1 mx-3" />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onCloseMenu();
                        onDelete?.(video);
                      }}
                      className="flex items-center gap-2.5 w-full text-left px-3.5 py-2 hover:bg-red-50 transition-colors text-red-500 rounded-lg"
                      style={{ fontSize: "0.78rem" }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      삭제
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 mt-1.5">
          <span className="text-slate-400" style={{ fontSize: "0.7rem" }}>
            {video.date}
          </span>
          {isFriendDrive && (
            <span
              className={`px-1.5 py-0.5 rounded-md border ${
                video.owner === "my"
                  ? "bg-blue-50 text-blue-500 border-blue-100"
                  : "bg-slate-50 text-slate-500 border-slate-100"
              }`}
              style={{ fontSize: "0.62rem", fontWeight: 500 }}
            >
              {video.owner === "my" ? "나" : video.owner === "jieun" ? "김지은" : "박준호"}
            </span>
          )}
          {!video.hasCaptions && (
            <span className="ml-auto text-slate-300" style={{ fontSize: "0.65rem" }}>
              자막 없음
            </span>
          )}
        </div>

        {/* ── Reactions & Comments (shared drives only) ── */}
        {isFriendDrive && (
          <div className="mt-2.5 pt-2.5 border-t border-slate-50" onClick={(e) => e.stopPropagation()}>
            {/* Reaction pills + add button */}
            <div className="flex items-center gap-1 flex-wrap">
              {REACTION_EMOJIS.filter(emoji => reactions[emoji] > 0 || myReactions.includes(emoji)).map((emoji) => {
                const isMine = myReactions.includes(emoji);
                const count = reactions[emoji];
                if (count === 0 && !isMine) return null;
                return (
                  <button
                    key={emoji}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (isMine) {
                        setMyReactions(prev => prev.filter(r => r !== emoji));
                        setReactions(prev => ({ ...prev, [emoji]: Math.max(0, prev[emoji] - 1) }));
                      } else {
                        setMyReactions(prev => [...prev, emoji]);
                        setReactions(prev => ({ ...prev, [emoji]: prev[emoji] + 1 }));
                      }
                    }}
                    className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded-lg border transition-all ${
                      isMine
                        ? "border-blue-200 bg-blue-50 text-blue-600"
                        : "border-slate-100 bg-slate-50/80 text-slate-500 hover:border-slate-200"
                    }`}
                    style={{ fontSize: "0.68rem" }}
                  >
                    <span style={{ fontSize: "0.72rem" }}>{emoji}</span>
                    <span style={{ fontWeight: isMine ? 600 : 450 }}>{count}</span>
                  </button>
                );
              })}

              {/* Add reaction button */}
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowReactionPicker(!showReactionPicker);
                  }}
                  className="w-6 h-6 rounded-lg border border-dashed border-slate-200 flex items-center justify-center text-slate-300 hover:text-slate-500 hover:border-slate-300 transition-all"
                  style={{ fontSize: "0.7rem" }}
                >
                  +
                </button>
                <AnimatePresence>
                  {showReactionPicker && (
                    <motion.div
                      className="absolute bottom-full left-0 mb-1.5 bg-white border border-slate-100 rounded-xl px-1.5 py-1 flex items-center gap-0.5 z-30"
                      style={{ boxShadow: "0 8px 24px rgba(0,0,0,0.08)" }}
                      initial={{ opacity: 0, y: 4, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 4, scale: 0.95 }}
                      transition={{ duration: 0.1 }}
                    >
                      {REACTION_EMOJIS.map((emoji) => (
                        <button
                          key={emoji}
                          onClick={(e) => {
                            e.stopPropagation();
                            const isMine = myReactions.includes(emoji);
                            if (!isMine) {
                              setMyReactions(prev => [...prev, emoji]);
                              setReactions(prev => ({ ...prev, [emoji]: prev[emoji] + 1 }));
                            } else {
                              setMyReactions(prev => prev.filter(r => r !== emoji));
                              setReactions(prev => ({ ...prev, [emoji]: Math.max(0, prev[emoji] - 1) }));
                            }
                            setShowReactionPicker(false);
                          }}
                          className={`w-7 h-7 rounded-lg flex items-center justify-center hover:bg-slate-50 transition-colors ${
                            myReactions.includes(emoji) ? "bg-blue-50" : ""
                          }`}
                          style={{ fontSize: "0.85rem" }}
                        >
                          {emoji}
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Comment button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenComments?.(video.id);
                }}
                className="ml-auto flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-slate-100 text-slate-400 hover:text-blue-500 hover:bg-blue-50 hover:border-blue-200 transition-all"
                style={{ fontSize: "0.72rem", fontWeight: 480 }}
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>댓글</span>
                {commentCount > 0 && (
                  <span className="bg-slate-100 text-slate-500 rounded-full px-1.5 min-w-[18px] text-center" style={{ fontSize: "0.62rem", fontWeight: 600 }}>
                    {commentCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
});

// ── Delete Confirmation Dialog ────────────────────────────────────────────────
function DeleteConfirmDialog({
  videoTitle,
  onConfirm,
  onCancel,
}: {
  videoTitle: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40" onClick={onCancel} />

      {/* Dialog */}
      <motion.div
        className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-100 w-[380px] overflow-hidden"
        initial={{ scale: 0.92, opacity: 0, y: 10 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 5 }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
      >
        <div className="px-6 pt-6 pb-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
              <Trash2 className="w-5 h-5 text-red-500" />
            </div>
            <h3 className="text-slate-900" style={{ fontSize: "1rem", fontWeight: 600 }}>
              영상 삭제
            </h3>
          </div>
          <p className="text-slate-500 ml-[56px]" style={{ fontSize: "0.85rem", lineHeight: "1.5" }}>
            이 영상을 삭제하시겠습니까?
          </p>
          <p className="text-slate-400 ml-[56px] mt-1 truncate" style={{ fontSize: "0.78rem" }}>
            "{videoTitle}"
          </p>
        </div>

        <div className="flex items-center gap-2.5 px-6 pb-5 pt-2 justify-end">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            style={{ fontSize: "0.82rem", fontWeight: 500 }}
          >
            취소
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white transition-colors shadow-sm"
            style={{ fontSize: "0.82rem", fontWeight: 500 }}
          >
            삭제
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ── Dashboard Page ────────────────────────────────────────────────────────────
export function DashboardPage() {
  const { activeDriveId, customDrives, driveRenames } = useOutletContext<LayoutContext>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("전체 영상");
  const [sortOpen, setSortOpen] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>("최신순");
  const [deletedIds, setDeletedIds] = useState<number[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<typeof ALL_VIDEOS[0] | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [menuOpen, setMenuOpen] = useState<number | null>(null);
  const [shareTarget, setShareTarget] = useState<typeof ALL_VIDEOS[0] | null>(null);
  const [selectedDriveId, setSelectedDriveId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "info">("success");
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importSelectedIds, setImportSelectedIds] = useState<number[]>([]);
  const [showMembersPopover, setShowMembersPopover] = useState(false);
  const membersButtonRef = useRef<HTMLButtonElement>(null);
  const membersPopoverRef = useRef<HTMLDivElement>(null);
  
  // Comment modal state
  const [commentModalVideoId, setCommentModalVideoId] = useState<number | null>(null);
  const [allComments, setAllComments] = useState<Record<number, Comment[]>>(() => ({ ...INITIAL_COMMENTS }));
  const [commentInput, setCommentInput] = useState("");
  const commentInputRef = useRef<HTMLInputElement>(null);
  
  // Close members popover on outside click
  useEffect(() => {
    if (!showMembersPopover) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (
        membersPopoverRef.current && !membersPopoverRef.current.contains(e.target as Node) &&
        membersButtonRef.current && !membersButtonRef.current.contains(e.target as Node)
      ) {
        setShowMembersPopover(false);
      }
    };
    // Use requestAnimationFrame to avoid the opening click from immediately closing
    const raf = requestAnimationFrame(() => {
      document.addEventListener("click", handleClickOutside, true);
    });
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, [showMembersPopover]);

  // Show toast helper
  const showToast = useCallback((message: string, type: "success" | "info" = "success") => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    setToastMessage(message);
    setToastType(type);
    toastTimerRef.current = setTimeout(() => setToastMessage(null), 3000);
  }, []);

  // Cleanup toast timer
  useEffect(() => {
    return () => {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    };
  }, []);

  // Handler to open Viewer page — shows completed video with captions
  const openVideoViewer = (video: typeof ALL_VIDEOS[0]) => {
    const ownerLabel = video.owner === "my" ? "나" : video.owner === "jieun" ? "김지은" : "박준호";
    const captions = VIDEO_CAPTIONS[video.id] ?? VIDEO_CAPTIONS[1] ?? [];
    navigate("/viewer", {
      state: {
        videoId: video.id,
        title: video.title,
        thumb: video.thumb,
        date: video.date,
        duration: video.duration,
        durationSeconds: parseDuration(video.duration),
        owner: video.owner,
        ownerLabel,
        captions,
        comments: allComments[video.id] ?? [],
        reactions: INITIAL_REACTIONS[video.id] ?? { "👍": 0, "❤️": 0, "😂": 0, "🔥": 0, "👏": 0 },
        myReactions: INITIAL_MY_REACTIONS[video.id] ?? [],
        liked: video.liked,
      },
    });
  };

  // Handle edit — opens result player for editing (caption editing UI)
  const handleEdit = (video: typeof ALL_VIDEOS[0]) => {
    const savedVideo = video as any;
    let videoEditState;
    if (savedVideo.timeline && savedVideo.timeline.length > 0) {
      videoEditState = {
        version: 3,
        videoId: `video-${video.id}`,
        videoTitle: video.title,
        videoThumbnail: video.thumb,
        videoSource: video.thumb,
        timeline: savedVideo.timeline,
        emojiOn: savedVideo.emojiOn ?? true,
        captionOn: true,
        sensitivity: 70,
        captionStyle: "기본",
        duration: 754,
      };
    } else {
      videoEditState = createVideoEditStateFromSounds(
        MOCK_SOUNDS,
        {
          videoId: `video-${video.id}`,
          videoTitle: video.title,
          videoThumbnail: video.thumb,
          videoSource: video.thumb,
          emojiOn: true,
          captionOn: true,
          sensitivity: 70,
          captionStyle: "기본",
          duration: 754,
        }
      );
    }
    saveVideoEditState(videoEditState);
    navigate("/result", { state: videoEditState });
  };

  // Handle share — open share modal
  const handleShareRequest = (video: typeof ALL_VIDEOS[0]) => {
    setShareTarget(video);
    setSelectedDriveId(null);
  };

  // Confirm share
  const handleShareConfirm = () => {
    if (!shareTarget || !selectedDriveId) return;

    // Duplicate video data into the selected friend drive
    const sharedVideosKey = `sharedVideos_${selectedDriveId}`;
    const existingJson = localStorage.getItem(sharedVideosKey);
    const existing = existingJson ? JSON.parse(existingJson) : [];
    
    // Create a copy with a new unique id and the friend as owner
    const sharedCopy = {
      ...shareTarget,
      id: Date.now(), // unique id for the copy
      owner: selectedDriveId,
      date: new Date().toISOString().slice(0, 10).replace(/-/g, "."),
    };
    existing.push(sharedCopy);
    localStorage.setItem(sharedVideosKey, JSON.stringify(existing));

    setShareTarget(null);
    setSelectedDriveId(null);
    showToast("선택한 드라이브에 공유되었습니다.", "success");
  };

  // Handle delete — show confirmation (does NOT actually delete)
  const handleDeleteRequest = (video: typeof ALL_VIDEOS[0]) => {
    setDeleteTarget(video);
  };

  // Confirm delete — actually remove the video
  const handleDeleteConfirm = () => {
    if (!deleteTarget) return;
    setDeletedIds(prev => [...prev, deleteTarget.id]);
    // Also remove from localStorage savedVideos if present
    const savedJson = localStorage.getItem('savedVideos');
    if (savedJson) {
      const saved = JSON.parse(savedJson);
      const filtered = saved.filter((v: any) => v.id !== deleteTarget.id);
      localStorage.setItem('savedVideos', JSON.stringify(filtered));
    }
    showToast(`"${deleteTarget.title}" 영상이 삭제되었습니다.`, "success");
    setDeleteTarget(null);
    setRefreshKey(prev => prev + 1);
  };

  // Load saved videos from localStorage
  const savedVideosJson = localStorage.getItem('savedVideos');
  const savedVideos = savedVideosJson ? JSON.parse(savedVideosJson) : [];

  // Load persisted title renames
  const renamedJson = localStorage.getItem('renamedTitles');
  const renamedTitles: Record<number, string> = renamedJson ? JSON.parse(renamedJson) : {};
  
  // Combine saved videos with initial videos, excluding deleted ones,
  // and apply any persisted title renames
  const allVideos = [...savedVideos, ...ALL_VIDEOS]
    .filter(v => !deletedIds.includes(v.id))
    .map(v => renamedTitles[v.id] ? { ...v, title: renamedTitles[v.id] } : v);

  const isMyDrive = activeDriveId === "my";

  let filtered = allVideos.filter((v) => {
    if (activeDriveId === "my") return v.owner === "my" || v.liked;
    return v.owner === activeDriveId || (v.sharedTo?.includes(activeDriveId) ?? false);
  });
  if (activeTab === "내가 만든 영상") filtered = filtered.filter((v) => v.owner === "my");
  if (activeTab === "좋아요 누른 영상") filtered = filtered.filter((v) => v.liked);

  const sorted = [...filtered].sort((a, b) => {
    if (sortKey === "이름 순") return a.title.localeCompare(b.title);
    if (sortKey === "오래된 순") return a.date.localeCompare(b.date);
    if (sortKey === "길이 순") return b.duration.localeCompare(a.duration);
    return b.date.localeCompare(a.date);
  });

  // Different tabs for "내 드라이브" vs "공유 드라이브"
  const TABS = isMyDrive 
    ? ["전체 영상", "좋아요 누른 영상"]
    : ["전체 영상", "내가 만든 영상"];
  const SORT_OPTIONS: SortKey[] = ["최신순", "오래된 순", "이름 순", "길이 순"];

  const driveName = (() => {
    if (activeDriveId === "my") return "내 드라이브";
    // Check built-in drives with renames
    const builtIn = DRIVES.find(d => d.id === activeDriveId);
    if (builtIn) return driveRenames?.[builtIn.id] || builtIn.name;
    // Check custom drives
    const custom = customDrives?.find(d => d.id === activeDriveId);
    return custom ? custom.name : "드라이브";
  })();

  // Compute drive members for shared drives
  const driveMembers: string[] = (() => {
    if (isMyDrive) return [];
    // Built-in shared drives: always 2 members (me + the other person)
    const BUILTIN_MEMBERS: Record<string, string[]> = {
      jieun: ["박민준", "김지은"],
      junho: ["박민준", "박준호"],
    };
    if (BUILTIN_MEMBERS[activeDriveId]) return BUILTIN_MEMBERS[activeDriveId];
    // Custom drives
    const custom = customDrives?.find(d => d.id === activeDriveId);
    return custom ? custom.members : [];
  })();

  // Avatar colors for member list
  const MEMBER_COLORS = [
    "from-blue-400 to-blue-600",
    "from-violet-400 to-pink-400",
    "from-emerald-400 to-teal-500",
    "from-amber-400 to-orange-500",
    "from-rose-400 to-red-500",
    "from-cyan-400 to-blue-500",
  ];

  return (
    <div className="relative flex flex-col h-full bg-[#fafbfc]" style={{ fontFamily: "'Inter', 'Noto Sans KR', sans-serif" }}>
      {/* Page header */}
      <div className="bg-white/80 border-b border-slate-100 px-8 pt-7 pb-5">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-slate-900" style={{ fontSize: "1.3rem", fontWeight: 680, letterSpacing: "-0.025em" }}>
                  {driveName}
                </h1>
              </div>
              <div className="flex items-center gap-2.5 mt-1">
                <div className="flex items-center gap-1.5">
                  <Film className="w-3 h-3 text-slate-300" />
                  <p className="text-slate-400" style={{ fontSize: "0.76rem", fontWeight: 450 }}>
                    {sorted.length}개의 영상
                  </p>
                </div>

                {/* Members badge (shared drives only) */}
                {!isMyDrive && driveMembers.length > 0 && (
                  <div className="relative">
                    <button
                      ref={membersButtonRef}
                      onClick={() => setShowMembersPopover(!showMembersPopover)}
                      className={`flex items-center gap-1 px-2 py-0.5 rounded-lg border transition-all ${
                        showMembersPopover
                          ? "border-blue-200 bg-blue-50 text-blue-600"
                          : "border-slate-150 text-slate-400 hover:bg-slate-50 hover:border-slate-200 hover:text-slate-500"
                      }`}
                      style={{ fontSize: "0.7rem", fontWeight: 500 }}
                    >
                      <Users className="w-3 h-3" />
                      <span>{driveMembers.length}명</span>
                    </button>

  
                    <AnimatePresence>
                      {showMembersPopover && (
                        <motion.div
                          ref={membersPopoverRef}
                          className="absolute left-0 top-full mt-2 w-56 bg-white border border-slate-100 rounded-xl py-2.5 z-30"
                          style={{
                            boxShadow: "0 12px 40px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04)",
                          }}
                          initial={{ opacity: 0, y: -4, scale: 0.96 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: -4, scale: 0.96 }}
                          transition={{ duration: 0.12 }}
                        >
                          <p
                            className="px-4 pb-2 text-slate-400 uppercase"
                            style={{ fontSize: "0.58rem", letterSpacing: "0.08em", fontWeight: 550 }}
                          >
                            참여자 {driveMembers.length}명
                          </p>
                          {driveMembers.map((member, idx) => {
                            const isMe = member === "박민준";
                            const colorClass = MEMBER_COLORS[idx % MEMBER_COLORS.length];
                            return (
                              <div
                                key={member}
                                className="flex items-center gap-2.5 px-4 py-2 hover:bg-slate-50 transition-colors"
                              >
                                <div
                                  className={`w-7 h-7 rounded-full bg-gradient-to-br ${colorClass} flex items-center justify-center text-white shrink-0`}
                                  style={{ fontSize: "0.55rem", fontWeight: 600 }}
                                >
                                  {member.charAt(0)}
                                </div>
                                <span className="text-slate-700 flex-1" style={{ fontSize: "0.8rem", fontWeight: 450 }}>
                                  {member}
                                </span>
                                {isMe && (
                                  <span
                                    className="text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded-md"
                                    style={{ fontSize: "0.58rem", fontWeight: 550 }}
                                  >
                                    나
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* "새 영상 변환" button (내 드라이브 only) */}
          {isMyDrive ? (
            <button
              onClick={() => navigate("/caption")}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors shadow-sm shadow-blue-500/20"
              style={{ fontSize: "0.8rem", fontWeight: 530 }}
            >
              <Wand2 className="w-3.5 h-3.5" />
              새 영상 변환
            </button>
          ) : (
            <button
              onClick={() => { setImportSelectedIds([]); setShowImportModal(true); }}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl transition-colors shadow-sm shadow-emerald-500/20"
              style={{ fontSize: "0.8rem", fontWeight: 530 }}
            >
              <FolderInput className="w-3.5 h-3.5" />
              가져오기
            </button>
          )}
        </div>

        {/* Filter tabs + Sort — same row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1 bg-slate-100/80 p-1 rounded-xl w-fit">
            {TABS.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-1.5 rounded-lg transition-all relative ${
                  activeTab === tab
                    ? "bg-white text-slate-800 shadow-sm"
                    : "text-slate-500 hover:text-slate-700"
                }`}
                style={{ fontSize: "0.78rem", fontWeight: activeTab === tab ? 550 : 430 }}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Sort */}
          <div className="relative">
            <button
              onClick={() => setSortOpen(!sortOpen)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-white border border-slate-150 rounded-xl text-slate-600 hover:bg-slate-50 hover:border-slate-200 transition-all"
              style={{ fontSize: "0.78rem", fontWeight: 480 }}
            >
              <SlidersHorizontal className="w-3 h-3 text-slate-400" />
              {sortKey}
              <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${sortOpen ? "rotate-180" : ""}`} />
            </button>
            <AnimatePresence>
              {sortOpen && (
                <motion.div
                  className="absolute right-0 top-full mt-1.5 w-40 bg-white border border-slate-100 rounded-xl py-1.5 z-20"
                  style={{ boxShadow: "0 12px 40px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04)" }}
                  initial={{ opacity: 0, y: -4, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -4, scale: 0.96 }}
                  transition={{ duration: 0.12 }}
                >
                  {SORT_OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => { setSortKey(opt); setSortOpen(false); }}
                      className={`w-full text-left px-4 py-2 hover:bg-slate-50 transition-colors flex items-center justify-between rounded-lg ${sortKey === opt ? "text-blue-600" : "text-slate-600"}`}
                      style={{ fontSize: "0.78rem", fontWeight: sortKey === opt ? 550 : 430 }}
                    >
                      {opt}
                      {sortKey === opt && <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Video grid */}
      <div className="flex-1 overflow-y-auto p-8 pb-24">
        {sorted.length > 0 ? (
          <motion.div className="grid grid-cols-2 xl:grid-cols-3 gap-5" layout>
            <AnimatePresence mode="popLayout">
              {sorted.map((video, i) => (
                <VideoCard 
                  key={video.id} 
                  video={video} 
                  onPlay={() => openVideoViewer(video)} 
                  activeDriveId={activeDriveId} 
                  onLikeToggle={(id) => {
                    const index = ALL_VIDEOS.findIndex(v => v.id === id);
                    if (index !== -1) {
                      ALL_VIDEOS[index].liked = !ALL_VIDEOS[index].liked;
                    }
                  }} 
                  onEdit={handleEdit}
                  onShare={handleShareRequest}
                  onDelete={handleDeleteRequest}
                  onRenameTitle={(videoId, newTitle) => {
                    // 1) Try hardcoded ALL_VIDEOS
                    const index = ALL_VIDEOS.findIndex(v => v.id === videoId);
                    if (index !== -1) {
                      ALL_VIDEOS[index].title = newTitle;
                    }
                    // 2) Try localStorage savedVideos
                    const savedJson = localStorage.getItem('savedVideos');
                    if (savedJson) {
                      const saved = JSON.parse(savedJson);
                      const savedIdx = saved.findIndex((v: any) => v.id === videoId);
                      if (savedIdx !== -1) {
                        saved[savedIdx].title = newTitle;
                        localStorage.setItem('savedVideos', JSON.stringify(saved));
                      }
                    }
                    // 3) Persist title rename
                    const renamedJson = localStorage.getItem('renamedTitles');
                    const renamedTitles: Record<number, string> = renamedJson ? JSON.parse(renamedJson) : {};
                    renamedTitles[videoId] = newTitle;
                    localStorage.setItem('renamedTitles', JSON.stringify(renamedTitles));
                    setRefreshKey(prev => prev + 1);
                    showToast("제목이 변경되었습니다.", "success");
                  }}
                  isMenuOpen={menuOpen === video.id}
                  onToggleMenu={(videoId) => setMenuOpen(prev => prev === videoId ? null : videoId)}
                  onCloseMenu={() => setMenuOpen(null)}
                  onOpenComments={(videoId) => {
                    setCommentModalVideoId(videoId);
                    setCommentInput("");
                    setTimeout(() => commentInputRef.current?.focus(), 150);
                  }}
                  commentCount={(allComments[video.id] ?? []).length}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <motion.div 
            className="flex flex-col items-center justify-center h-64 text-slate-400"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mb-4">
              <Film className="w-7 h-7 text-slate-300" />
            </div>
            <p className="text-slate-500" style={{ fontSize: "0.92rem", fontWeight: 520 }}>영상이 없습니다</p>
            <p className="mt-1.5 text-slate-300" style={{ fontSize: "0.78rem" }}>새 영상을 업로드해 시작하세요</p>
          </motion.div>
        )}
      </div>

      {/* Delete confirmation dialog */}
      <AnimatePresence>
        {deleteTarget && (
          <DeleteConfirmDialog
            videoTitle={deleteTarget.title}
            onConfirm={handleDeleteConfirm}
            onCancel={() => setDeleteTarget(null)}
          />
        )}
      </AnimatePresence>

      {/* Share modal */}
      <AnimatePresence>
        {shareTarget && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            <div className="absolute inset-0 bg-black/40" onClick={() => setShareTarget(null)} />
            <motion.div
              className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-100 w-[420px] overflow-hidden"
              initial={{ scale: 0.92, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 5 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
            >
              {/* Header */}
              <div className="px-6 pt-6 pb-3">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-11 h-11 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
                    <Share2 className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-slate-900" style={{ fontSize: "1rem", fontWeight: 600 }}>
                      드라이브에 공유
                    </h3>
                    <p className="text-slate-400 mt-0.5 truncate max-w-[260px]" style={{ fontSize: "0.75rem" }}>
                      "{shareTarget.title}"
                    </p>
                  </div>
                </div>
              </div>

              {/* Drive list */}
              <div className="px-6 pb-4">
                <p className="text-slate-500 mb-3" style={{ fontSize: "0.78rem", fontWeight: 450 }}>
                  공유할 드라이브를 선택하세요
                </p>
                <div className="flex flex-col gap-1.5">
                  {[...DRIVES.filter(d => d.type === "shared"), ...(customDrives || [])].map((drive) => {
                    const isSelected = selectedDriveId === drive.id;
                    const displayName = driveRenames?.[drive.id] || drive.name;
                    return (
                      <button
                        key={drive.id}
                        onClick={() => setSelectedDriveId(isSelected ? null : drive.id)}
                        className={`flex items-center gap-3 w-full text-left px-4 py-3 rounded-xl border transition-all ${
                          isSelected
                            ? "border-blue-500 bg-blue-50/60 ring-1 ring-blue-500/20"
                            : "border-slate-100 hover:border-slate-200 hover:bg-slate-50"
                        }`}
                      >
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                          isSelected ? "bg-blue-500 text-white" : "bg-slate-100 text-slate-500"
                        }`} style={{ fontSize: "0.65rem" }}>
                          {isSelected ? <Check className="w-4 h-4" /> : <Users className="w-4 h-4" />}
                        </div>
                        <span className={`${isSelected ? "text-blue-700" : "text-slate-700"}`} style={{ fontSize: "0.85rem", fontWeight: isSelected ? 550 : 430 }}>
                          {displayName}
                        </span>
                        {isSelected && (
                          <CheckCircle2 className="w-4 h-4 text-blue-500 ml-auto" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2.5 px-6 pb-5 pt-1 justify-end border-t border-slate-100">
                <button
                  onClick={() => setShareTarget(null)}
                  className="px-4 py-2 mt-3 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  style={{ fontSize: "0.82rem", fontWeight: 500 }}
                >
                  취소
                </button>
                <button
                  onClick={handleShareConfirm}
                  disabled={!selectedDriveId}
                  className={`px-4 py-2 mt-3 rounded-xl transition-colors shadow-sm ${
                    selectedDriveId
                      ? "bg-blue-600 hover:bg-blue-700 text-white"
                      : "bg-slate-100 text-slate-400 cursor-not-allowed"
                  }`}
                  style={{ fontSize: "0.82rem", fontWeight: 500 }}
                >
                  공유하기
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Import from My Drive modal */}
      <AnimatePresence>
        {showImportModal && (() => {
          // Get all videos from "내 드라이브"
          const myDriveVideos = allVideos.filter(v => v.owner === "my");
          const handleImportConfirm = () => {
            if (importSelectedIds.length === 0) return;
            const importedVideos = myDriveVideos.filter(v => importSelectedIds.includes(v.id));
            const sharedVideosKey = `sharedVideos_${activeDriveId}`;
            const existingJson = localStorage.getItem(sharedVideosKey);
            const existing = existingJson ? JSON.parse(existingJson) : [];
            for (const video of importedVideos) {
              existing.push({
                ...video,
                id: Date.now() + Math.random(),
                owner: activeDriveId,
                date: new Date().toISOString().slice(0, 10).replace(/-/g, "."),
              });
            }
            localStorage.setItem(sharedVideosKey, JSON.stringify(existing));
            setShowImportModal(false);
            setImportSelectedIds([]);
            showToast(`${importedVideos.length}개의 영상을 가져왔습니다.`, "success");
            setRefreshKey(prev => prev + 1);
          };

          return (
            <motion.div
              className="fixed inset-0 z-50 flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <div className="absolute inset-0 bg-black/40" onClick={() => setShowImportModal(false)} />
              <motion.div
                className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-100 w-[500px] max-h-[80vh] flex flex-col overflow-hidden"
                initial={{ scale: 0.92, opacity: 0, y: 10 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 5 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
              >
                {/* Header */}
                <div className="px-6 pt-6 pb-3 shrink-0">
                  <div className="flex items-center gap-3 mb-1">
                    <div className="w-11 h-11 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0">
                      <FolderInput className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <h3 className="text-slate-900" style={{ fontSize: "1rem", fontWeight: 600 }}>
                        내 드라이브에서 가져오기
                      </h3>
                      <p className="text-slate-400 mt-0.5" style={{ fontSize: "0.75rem" }}>
                        가져올 영상을 선택하세요
                      </p>
                    </div>
                  </div>
                </div>

                {/* Video list */}
                <div className="px-6 pb-4 flex-1 overflow-y-auto">
                  {myDriveVideos.length > 0 ? (
                    <div className="flex flex-col gap-1.5">
                      {myDriveVideos.map((video) => {
                        const isSelected = importSelectedIds.includes(video.id);
                        return (
                          <button
                            key={video.id}
                            onClick={() =>
                              setImportSelectedIds(prev =>
                                isSelected
                                  ? prev.filter(id => id !== video.id)
                                  : [...prev, video.id]
                              )
                            }
                            className={`flex items-center gap-3 w-full text-left px-3.5 py-3 rounded-xl border transition-all ${
                              isSelected
                                ? "border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500/20"
                                : "border-slate-100 hover:border-slate-200 hover:bg-slate-50"
                            }`}
                          >
                            {/* Thumbnail */}
                            <div className="w-16 h-10 rounded-lg overflow-hidden bg-slate-100 shrink-0">
                              <ImageWithFallback
                                src={video.thumb}
                                alt={video.title}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            {/* Info */}
                            <div className="flex-1 min-w-0">
                              <p className={`truncate ${isSelected ? "text-emerald-700" : "text-slate-700"}`} style={{ fontSize: "0.84rem", fontWeight: 480 }}>
                                {video.title}
                              </p>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="text-slate-400" style={{ fontSize: "0.68rem" }}>
                                  {video.date}
                                </span>
                                <span className="text-slate-300" style={{ fontSize: "0.68rem" }}>
                                  {video.duration}
                                </span>
                              </div>
                            </div>
                            {/* Checkbox */}
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 transition-all ${
                              isSelected
                                ? "bg-emerald-500 text-white"
                                : "border-2 border-slate-200"
                            }`}>
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-10 text-slate-400">
                      <Play className="w-8 h-8 text-slate-200 mb-2" />
                      <p style={{ fontSize: "0.84rem" }}>내 드라이브에 영상이 없습니다</p>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between px-6 pb-5 pt-3 border-t border-slate-100 shrink-0">
                  <span className="text-slate-400" style={{ fontSize: "0.75rem", fontWeight: 450 }}>
                    {importSelectedIds.length > 0
                      ? `${importSelectedIds.length}개 선택됨`
                      : "영상을 선택하세요"}
                  </span>
                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={() => setShowImportModal(false)}
                      className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                      style={{ fontSize: "0.82rem", fontWeight: 500 }}
                    >
                      취소
                    </button>
                    <button
                      onClick={handleImportConfirm}
                      disabled={importSelectedIds.length === 0}
                      className={`px-4 py-2 rounded-xl transition-colors shadow-sm ${
                        importSelectedIds.length > 0
                          ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                          : "bg-slate-100 text-slate-400 cursor-not-allowed"
                      }`}
                      style={{ fontSize: "0.82rem", fontWeight: 500 }}
                    >
                      가져오기
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {/* ── Comment Side Panel ── */}
      <AnimatePresence>
        {commentModalVideoId !== null && (() => {
          const video = allVideos.find(v => v.id === commentModalVideoId);
          if (!video) return null;
          const videoComments = allComments[commentModalVideoId] ?? [];

          const AUTHOR_COLORS: Record<string, string> = {
            "김지은": "from-violet-400 to-pink-400",
            "박준호": "from-emerald-400 to-teal-500",
            "박민준": "from-blue-400 to-blue-600",
          };

          const handleSendComment = () => {
            if (!commentInput.trim()) return;
            setAllComments(prev => ({
              ...prev,
              [commentModalVideoId]: [
                ...(prev[commentModalVideoId] ?? []),
                {
                  id: Date.now(),
                  author: "박민준",
                  text: commentInput.trim(),
                  time: "방금 전",
                },
              ],
            }));
            setCommentInput("");
            setTimeout(() => commentInputRef.current?.focus(), 50);
          };

          return (
            <motion.div
              className="fixed inset-0 z-50 flex items-end justify-end"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <div className="absolute inset-0 bg-black/40" onClick={() => setCommentModalVideoId(null)} />
              <motion.div
                className="relative bg-white shadow-2xl shadow-slate-400/30 border-l border-slate-100 w-[420px] h-full flex flex-col"
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 30, stiffness: 300 }}
              >
                {/* Close button */}
                <button
                  onClick={() => setCommentModalVideoId(null)}
                  className="absolute top-4 right-4 z-10 w-8 h-8 rounded-xl bg-white/80 flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-white transition-colors shadow-sm"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* Video preview area */}
                <div className="relative w-full aspect-video bg-slate-900 shrink-0 overflow-hidden">
                  <ImageWithFallback
                    src={video.thumb}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Play overlay */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-black/30 flex items-center justify-center">
                      <Play className="w-5 h-5 text-white ml-0.5" fill="white" />
                    </div>
                  </div>
                  {/* Video info overlay at bottom */}
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 to-transparent px-4 pb-3 pt-8">
                    <p className="text-white truncate" style={{ fontSize: "0.92rem", fontWeight: 560 }}>
                      {video.title}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-white/70" style={{ fontSize: "0.72rem" }}>
                        {video.owner === "my" ? "나" : video.owner === "jieun" ? "김지은" : "박준호"}
                      </span>
                      <span className="text-white/40" style={{ fontSize: "0.72rem" }}>·</span>
                      <span className="text-white/70" style={{ fontSize: "0.72rem" }}>{video.date}</span>
                      <span className="text-white/40" style={{ fontSize: "0.72rem" }}>·</span>
                      <span className="text-white/70" style={{ fontSize: "0.72rem" }}>{video.duration}</span>
                    </div>
                  </div>
                </div>

                {/* Comment count header */}
                <div className="px-5 py-3 border-b border-slate-100 shrink-0 flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-700" style={{ fontSize: "0.82rem", fontWeight: 540 }}>
                    댓글 {videoComments.length}개
                  </span>
                </div>

                {/* Comments list */}
                <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
                  {videoComments.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 text-slate-300">
                      <MessageCircle className="w-10 h-10 mb-3" />
                      <p style={{ fontSize: "0.88rem" }}>아직 댓글이 없어요</p>
                      <p className="mt-1 text-slate-300/80" style={{ fontSize: "0.75rem" }}>첫 번째 댓글을 남겨보세요!</p>
                    </div>
                  ) : (
                    videoComments.map((comment) => {
                      const colorClass = AUTHOR_COLORS[comment.author] ?? "from-amber-400 to-orange-500";
                      return (
                        <div key={comment.id} className="flex gap-3">
                          <div
                            className={`w-8 h-8 rounded-full bg-gradient-to-br ${colorClass} flex items-center justify-center text-white shrink-0`}
                            style={{ fontSize: "0.55rem", fontWeight: 600 }}
                          >
                            {comment.author.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-baseline gap-2">
                              <span className="text-slate-800" style={{ fontSize: "0.82rem", fontWeight: 560 }}>
                                {comment.author}
                              </span>
                              <span className="text-slate-300" style={{ fontSize: "0.68rem" }}>
                                {comment.time}
                              </span>
                            </div>
                            <p className="text-slate-600 mt-1" style={{ fontSize: "0.85rem", lineHeight: "1.55" }}>
                              {comment.text}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Input */}
                <div className="px-5 py-4 border-t border-slate-100 shrink-0 flex items-center gap-2.5 bg-white">
                  <div
                    className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white shrink-0"
                    style={{ fontSize: "0.55rem", fontWeight: 600 }}
                  >
                    박
                  </div>
                  <input
                    ref={commentInputRef}
                    type="text"
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleSendComment();
                      }
                    }}
                    placeholder="댓글 남기기..."
                    className="flex-1 min-w-0 bg-slate-50 border border-slate-100 rounded-xl px-3.5 py-2.5 text-slate-700 placeholder-slate-300 outline-none focus:border-blue-200 focus:ring-2 focus:ring-blue-100 transition-all"
                    style={{ fontSize: "0.85rem" }}
                  />
                  <button
                    onClick={handleSendComment}
                    disabled={!commentInput.trim()}
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                      commentInput.trim()
                        ? "bg-blue-500 text-white hover:bg-blue-600 shadow-sm shadow-blue-500/20"
                        : "bg-slate-100 text-slate-300"
                    }`}
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {/* Toast notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            className="fixed bottom-8 left-1/2 z-[70] flex items-center gap-2.5 px-5 py-3 bg-slate-900 text-white rounded-xl shadow-xl"
            style={{ fontSize: "0.84rem", fontWeight: 480 }}
            initial={{ opacity: 0, y: 20, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 10, x: "-50%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
          >
            {toastType === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}