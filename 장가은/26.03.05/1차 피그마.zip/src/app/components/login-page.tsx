import { useState } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "motion/react";
import { useNavigate } from "react-router";
import {
  Volume2,
  VolumeX,
  ArrowRight,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const fireworksThumb =
  "https://images.unsplash.com/photo-1729931597118-e49ddbea68ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdodCUyMHNreSUyMGZpcmV3b3JrcyUyMGNvbG9yZnVsJTIwZXhwbG9zaW9uJTIwY2VsZWJyYXRpb258ZW58MXx8fHwxNzcyNjAxMDMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

// ── Floating caption chips for AFTER card ──
const CAPTIONS = [
  { icon: "🎆", text: "[불꽃 터지는 소리]", delay: 0,   x: "5%",  y: "12%" },
  { icon: "👏", text: "[사람들 환호]",      delay: 1.8,  x: "46%", y: "48%" },
  { icon: "🔊", text: "폭발음",            delay: 3.2,  x: "7%",  y: "62%" },
  { icon: "🎇", text: "반짝이는 소리",     delay: 0.9,  x: "48%", y: "16%" },
];

function FloatingCaptions() {
  return (
    <>
      {CAPTIONS.map((c, i) => (
        <motion.div
          key={i}
          className="absolute z-10 flex items-center gap-1.5 bg-white/95 text-slate-800 px-3 py-1.5 rounded-full shadow-[0_4px_20px_rgba(0,0,0,0.12)]"
          style={{ left: c.x, top: c.y, fontSize: "0.66rem", whiteSpace: "nowrap", fontWeight: 550 }}
          initial={{ opacity: 0, scale: 0.5, y: 12 }}
          animate={{
            opacity: [0, 1, 1, 1, 0],
            scale: [0.5, 1.08, 1, 1, 0.9],
            y: [12, -2, 0, 0, -8],
          }}
          transition={{ duration: 4, delay: c.delay, repeat: Infinity, repeatDelay: 2, ease: "easeInOut" }}
        >
          <span className="text-sm">{c.icon}</span>
          <span>{c.text}</span>
        </motion.div>
      ))}
    </>
  );
}

// ── Sound wave rings (After card center) ──
function SoundWaveRings() {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="absolute rounded-full border-2 border-blue-400/30"
          animate={{
            width: [48, 120 + i * 40],
            height: [48, 120 + i * 40],
            opacity: [0.6, 0],
          }}
          transition={{
            duration: 2.5,
            delay: i * 0.6,
            repeat: Infinity,
            ease: "easeOut",
          }}
        />
      ))}
    </div>
  );
}

// ── Scanning line animation (After card) ──
function ScanLine() {
  return (
    <motion.div
      className="absolute left-0 right-0 h-[2px] z-20 pointer-events-none"
      style={{
        background: "linear-gradient(90deg, transparent 0%, rgba(96,165,250,0.6) 30%, rgba(59,130,246,0.9) 50%, rgba(96,165,250,0.6) 70%, transparent 100%)",
        boxShadow: "0 0 12px 3px rgba(59,130,246,0.25)",
      }}
      animate={{ top: ["8%", "85%", "8%"] }}
      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

// ── Noise static overlay (Before card) ──
function NoiseOverlay() {
  return (
    <div className="absolute inset-0 z-[2] pointer-events-none opacity-[0.04] mix-blend-overlay"
      style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='1'/%3E%3C/svg%3E")`,
        backgroundSize: "128px 128px",
      }}
    />
  );
}

// ── Kakao logo ──
function KakaoLogo() {
  return (
    <svg width="18" height="18" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M128 36C70.562 36 24 72.713 24 118.165C24 147.593 43.07 173.539 72.03 188.476L62.244 224.849C61.442 227.863 64.957 230.276 67.588 228.51L110.89 200.482C116.476 201.052 122.18 201.33 128 201.33C185.438 201.33 232 164.617 232 118.165C232 72.713 185.438 36 128 36Z"
        fill="#3C1E1E"
      />
    </svg>
  );
}

// ── SoundSee Logo SVG ──
function SoundSeeLogo({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="logoBg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2563EB" />
          <stop offset="100%" stopColor="#3B82F6" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="12" fill="url(#logoBg)" />
      {/* Eye shape - representing "See" */}
      <ellipse cx="20" cy="18" rx="11" ry="7" stroke="white" strokeWidth="1.8" fill="none" opacity="0.9" />
      {/* Pupil with sound wave inside */}
      <circle cx="20" cy="18" r="3.5" fill="white" opacity="0.95" />
      <circle cx="20" cy="18" r="1.5" fill="#2563EB" />
      {/* Sound waves emanating from the eye */}
      <path d="M26 14.5 Q28.5 18 26 21.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.7" />
      <path d="M28.5 12.5 Q32 18 28.5 23.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.4" />
      {/* Subtitle lines */}
      <rect x="10" y="29" width="8" height="1.6" rx="0.8" fill="white" opacity="0.8" />
      <rect x="20" y="29" width="11" height="1.6" rx="0.8" fill="white" opacity="0.8" />
      <rect x="10" y="32.5" width="13" height="1.6" rx="0.8" fill="white" opacity="0.45" />
      <rect x="25" y="32.5" width="6" height="1.6" rx="0.8" fill="white" opacity="0.45" />
    </svg>
  );
}

// ── Progress bar ──
function ProgressBar({ accent }: { accent: string }) {
  return (
    <div className="h-[2px] w-full bg-white/15 overflow-hidden">
      <motion.div
        className={`h-full ${accent}`}
        animate={{ width: ["0%", "100%"] }}
        transition={{ duration: 9, repeat: Infinity, ease: "linear" }}
      />
    </div>
  );
}

// ── Main ──
export function LoginPage() {
  const navigate = useNavigate();
  const [hovered, setHovered] = useState(false);

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 25, stiffness: 150 };
  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [5, -5]), springConfig);
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-5, 5]), springConfig);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    mouseX.set(x);
    mouseY.set(y);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
    setHovered(false);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col lg:flex-row" style={{ fontFamily: "'Inter', 'Noto Sans KR', sans-serif" }}>

      {/* ════ LEFT — Hero ════ */}
      <div className="flex flex-col justify-center px-8 py-14 lg:px-14 xl:px-20 lg:w-[46%] lg:min-h-screen relative">
        {/* Background accents */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 -right-32 w-72 h-72 rounded-full bg-blue-50/60" />
          <div className="absolute bottom-20 -left-16 w-48 h-48 rounded-full bg-slate-50/80" />
        </div>

        <div className="relative z-10 max-w-lg">
          {/* ── Logo ── */}
          <motion.div
            className="mb-16"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center gap-3">
              <SoundSeeLogo size={38} />
              <div className="flex flex-col">
                <span className="text-slate-900" style={{ fontSize: "1.1rem", fontWeight: 700, letterSpacing: "-0.025em" }}>
                  SoundSee
                </span>
                <span className="text-slate-400" style={{ fontSize: "0.58rem", fontWeight: 450, letterSpacing: "0.02em", marginTop: -1 }}>
                  AI Video Caption Platform
                </span>
              </div>
            </div>
          </motion.div>

          {/* ── Tagline ── */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.08 }}
          >
            <h1
              className="text-slate-900 mb-5"
              style={{
                fontSize: "clamp(2.4rem, 4.5vw, 3.4rem)",
                lineHeight: 1.1,
                letterSpacing: "-0.04em",
                fontWeight: 750,
              }}
            >
              소리를 눈으로
              <br />
              <span
                style={{
                  background: "linear-gradient(135deg, #2563EB 0%, #60A5FA 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                경험하세요
              </span>
            </h1>
          </motion.div>

          {/* ── Description ── */}
          <motion.p
            className="text-slate-500 mb-10"
            style={{ fontSize: "0.95rem", lineHeight: 1.8, fontWeight: 400 }}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.16 }}
          >
            AI가 영상 속 환경음과 대화를 인식하여
            <br />
            자막, 이모티콘, 진동으로 전달합니다.
          </motion.p>

          {/* ── Feature row ── */}
          <motion.div
            className="flex flex-wrap gap-3 mb-12"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.24 }}
          >
            {[
              { icon: "🎯", text: "환경음 인식" },
              { icon: "💬", text: "대화 자막" },
              { icon: "😊", text: "이모티콘" },
              { icon: "📳", text: "진동 피드백" },
            ].map((f, i) => (
              <motion.div
                key={i}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-100 text-slate-500"
                style={{ fontSize: "0.73rem", fontWeight: 480 }}
                whileHover={{ scale: 1.04 }}
                transition={{ type: "spring", stiffness: 400, damping: 20 }}
              >
                <span>{f.icon}</span>
                <span>{f.text}</span>
              </motion.div>
            ))}
          </motion.div>

          {/* ── Login button ── */}
          <motion.div
            className="mb-6"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.32 }}
          >
            <button
              onClick={() => navigate("/dashboard")}
              className="group flex items-center justify-center gap-2.5 w-full max-w-sm bg-[#FEE500] hover:bg-[#FDDC3F] text-[#191919] rounded-xl px-6 py-3.5 cursor-pointer transition-all hover:shadow-lg active:scale-[0.98]"
              style={{ fontSize: "0.88rem", fontWeight: 600 }}
            >
              <KakaoLogo />
              카카오톡으로 시작하기
              <ArrowRight className="w-4 h-4 opacity-0 -ml-2 group-hover:opacity-100 group-hover:ml-0 transition-all" />
            </button>
            <p className="text-slate-300 mt-3 text-center max-w-sm" style={{ fontSize: "0.66rem", fontWeight: 400 }}>
              로그인 시 서비스 이용약관 및 개인정보 처리방침에 동의합니다.
            </p>
          </motion.div>
        </div>
      </div>

      {/* ════ RIGHT — Before / After Preview ════ */}
      <div className="flex items-center justify-center bg-[#f5f7fa] px-6 py-10 lg:py-12 lg:px-10 lg:w-[54%] lg:min-h-screen relative overflow-hidden">
        {/* Decorative blobs */}
        <div className="absolute top-16 right-16 w-56 h-56 rounded-full bg-blue-100/30 pointer-events-none" />
        <div className="absolute bottom-24 left-8 w-40 h-40 rounded-full bg-indigo-50/50 pointer-events-none" />

        <div className="w-full max-w-2xl relative z-10">
          {/* Section label */}
          <motion.div
            className="flex items-center gap-2.5 mb-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.45 }}
          >
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
            <span className="text-slate-400" style={{ fontSize: "0.7rem", fontWeight: 550, letterSpacing: "0.06em", textTransform: "uppercase" }}>
              AI 자막 미리보기
            </span>
          </motion.div>

          {/* ── 3D Comparison Card ── */}
          <motion.div
            className="relative"
            style={{ perspective: 1200 }}
            initial={{ opacity: 0, y: 36 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.35, ease: "easeOut" }}
          >
            <motion.div
              className="rounded-2xl overflow-hidden bg-white shadow-[0_4px_32px_rgba(0,0,0,0.07)]"
              style={{
                rotateX,
                rotateY,
                transformStyle: "preserve-3d",
              }}
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setHovered(true)}
              onMouseLeave={handleMouseLeave}
              animate={{ y: [0, -5, 0] }}
              transition={{ y: { duration: 5, repeat: Infinity, ease: "easeInOut" } }}
            >
              <div className="grid grid-cols-2">
                {/* ─── BEFORE ─── */}
                <motion.div
                  className="relative"
                  style={{ transformStyle: "preserve-3d", transform: "translateZ(12px)" }}
                >
                  <div className="relative overflow-hidden">
                    <motion.div
                      animate={{ scale: hovered ? 1.04 : 1 }}
                      transition={{ duration: 0.6, ease: "easeOut" }}
                    >
                      <ImageWithFallback
                        src={fireworksThumb}
                        alt="일반 영상"
                        className="w-full object-cover grayscale brightness-[0.55] contrast-[0.85]"
                        style={{ aspectRatio: "16/10" }}
                      />
                    </motion.div>

                    {/* Dark desaturated overlay */}
                    <div className="absolute inset-0 bg-slate-900/20 z-[1]" />
                    <NoiseOverlay />

                    {/* Badge */}
                    <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 bg-slate-800/80 text-white/70 px-2.5 py-1 rounded-md" style={{ fontSize: "0.62rem", fontWeight: 500 }}>
                      <VolumeX className="w-3 h-3" />
                      소리 없음
                    </div>

                    {/* Center muted icon with X cross */}
                    <div className="absolute inset-0 flex items-center justify-center z-10">
                      <div className="relative">
                        <motion.div
                          className="w-16 h-16 rounded-full bg-slate-800/50 border-2 border-white/10 flex items-center justify-center"
                          animate={{ opacity: [0.6, 0.9, 0.6] }}
                          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                        >
                          <VolumeX className="w-7 h-7 text-white/50" />
                        </motion.div>
                      </div>
                    </div>

                    {/* Bottom bar - static, no subtitle */}
                    <div className="absolute bottom-0 left-0 right-0 z-10">
                      <ProgressBar accent="bg-slate-500" />
                      <div className="bg-slate-900/80 px-4 py-2 text-center" style={{ fontSize: "0.68rem" }}>
                        <span className="text-white/25">자막 없음</span>
                      </div>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="px-4 py-2.5 bg-slate-100/70 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-slate-400" style={{ fontSize: "0.64rem", fontWeight: 650, letterSpacing: "0.08em" }}>
                      BEFORE
                    </span>
                    <div className="flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                      <span className="text-slate-300" style={{ fontSize: "0.58rem", fontWeight: 450 }}>소리 정보 없음</span>
                    </div>
                  </div>

                  {/* Vertical divider */}
                  <div className="absolute top-0 right-0 bottom-0 w-px bg-slate-200/80 z-20" />
                </motion.div>

                {/* ─── AFTER ─── */}
                <motion.div
                  className="relative"
                  style={{ transformStyle: "preserve-3d", transform: "translateZ(28px)" }}
                >
                  <div className="relative overflow-hidden">
                    {/* Blue edge glow */}
                    <motion.div
                      className="absolute inset-0 z-[3] pointer-events-none rounded-sm"
                      animate={{
                        boxShadow: [
                          "inset 0 0 24px rgba(59,130,246,0.12), inset 0 0 60px rgba(59,130,246,0.05)",
                          "inset 0 0 36px rgba(59,130,246,0.22), inset 0 0 80px rgba(59,130,246,0.08)",
                          "inset 0 0 24px rgba(59,130,246,0.12), inset 0 0 60px rgba(59,130,246,0.05)",
                        ],
                      }}
                      transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    />

                    {/* Scanning line */}
                    <ScanLine />

                    <motion.div
                      animate={{ scale: hovered ? 1.06 : 1 }}
                      transition={{ duration: 0.6, ease: "easeOut" }}
                    >
                      <ImageWithFallback
                        src={fireworksThumb}
                        alt="AI 자막 영상"
                        className="w-full object-cover saturate-[1.15] brightness-[0.95]"
                        style={{ aspectRatio: "16/10" }}
                      />
                    </motion.div>

                    {/* Floating captions */}
                    <FloatingCaptions />

                    {/* Sound wave rings from center */}
                    <SoundWaveRings />

                    {/* Badge */}
                    <div className="absolute top-3 left-3 z-20 flex items-center gap-1.5 bg-blue-600 text-white px-2.5 py-1 rounded-md shadow-[0_2px_12px_rgba(37,99,235,0.35)]" style={{ fontSize: "0.62rem", fontWeight: 550 }}>
                      <motion.div
                        className="w-1.5 h-1.5 bg-emerald-300 rounded-full"
                        animate={{ scale: [1, 1.4, 1], opacity: [1, 0.6, 1] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      />
                      AI 자막 활성
                    </div>

                    {/* Center play icon + rings */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                      <motion.div
                        className="w-16 h-16 rounded-full bg-blue-600 border-2 border-blue-400/50 flex items-center justify-center shadow-[0_0_30px_rgba(37,99,235,0.4)]"
                        animate={{
                          scale: [1, 1.08, 1],
                          boxShadow: [
                            "0 0 0 0 rgba(37,99,235,0.5), 0 0 30px rgba(37,99,235,0.4)",
                            "0 0 0 18px rgba(37,99,235,0), 0 0 30px rgba(37,99,235,0.4)",
                            "0 0 0 0 rgba(37,99,235,0), 0 0 30px rgba(37,99,235,0.4)",
                          ],
                        }}
                        transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
                      >
                        <Volume2 className="w-7 h-7 text-white" />
                      </motion.div>
                    </div>

                    {/* Bottom subtitle bar */}
                    <div className="absolute bottom-0 left-0 right-0 z-20">
                      <ProgressBar accent="bg-blue-400" />
                      <div className="bg-black/75 px-4 py-2.5 flex items-center justify-center gap-2.5">
                        <motion.span
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                          style={{ fontSize: "0.85rem" }}
                        >
                          🎆
                        </motion.span>
                        <motion.span
                          className="text-white"
                          style={{ fontSize: "0.75rem", fontWeight: 500 }}
                          animate={{ opacity: [0.7, 1, 0.7] }}
                          transition={{ duration: 2.5, repeat: Infinity }}
                        >
                          [불꽃 터지는 소리]
                        </motion.span>
                        <span className="text-white/20 mx-0.5">|</span>
                        <motion.div className="flex items-end gap-[2px] h-3">
                          {[0, 1, 2, 3, 4].map((j) => (
                            <motion.div
                              key={j}
                              className="w-[3px] bg-blue-400 rounded-full"
                              animate={{ height: ["2px", `${8 + j * 2}px`, "2px"] }}
                              transition={{ duration: 0.6, delay: j * 0.08, repeat: Infinity, ease: "easeInOut" }}
                            />
                          ))}
                        </motion.div>
                      </div>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="px-4 py-2.5 bg-blue-50/50 border-t border-blue-100/50 flex items-center justify-between">
                    <span className="text-blue-600" style={{ fontSize: "0.64rem", fontWeight: 650, letterSpacing: "0.08em" }}>
                      AFTER
                    </span>
                    <div className="flex items-center gap-1.5 text-blue-500" style={{ fontSize: "0.58rem", fontWeight: 500 }}>
                      <motion.div
                        className="flex items-end gap-[2px] h-2.5"
                      >
                        {[0, 1, 2].map((j) => (
                          <motion.div
                            key={j}
                            className="w-[2px] bg-blue-400 rounded-full"
                            animate={{ height: ["2px", "8px", "2px"] }}
                            transition={{ duration: 0.5, delay: j * 0.1, repeat: Infinity }}
                          />
                        ))}
                      </motion.div>
                      <span>AI 자막 분석중</span>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>

            {/* ── Arrow indicator between cards ── */}
            <motion.div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 w-10 h-10 rounded-full bg-white shadow-[0_4px_20px_rgba(0,0,0,0.12)] border border-slate-100 flex items-center justify-center"
              animate={{ scale: [1, 1.08, 1] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <ArrowRight className="w-4 h-4 text-blue-600" />
            </motion.div>
          </motion.div>

          {/* Bottom stats */}
          <motion.div
            className="flex items-center justify-center gap-10 mt-7"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.5 }}
          >
            {[
              { value: "12+", label: "환경음 유형" },
              { value: "98%", label: "인식 정확도" },
              { value: "실시간", label: "자막 생성" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-slate-700" style={{ fontSize: "1rem", fontWeight: 700, letterSpacing: "-0.01em" }}>{stat.value}</div>
                <div className="text-slate-300" style={{ fontSize: "0.6rem", fontWeight: 450, marginTop: 2 }}>{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
}