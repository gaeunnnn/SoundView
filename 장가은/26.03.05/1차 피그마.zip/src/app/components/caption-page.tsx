import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { createVideoEditStateFromSounds, saveVideoEditState, type VideoEditState } from "../utils/video-state";
import {
  ArrowLeft,
  Subtitles,
  Download,
  SkipBack,
  SkipForward,
  Pause,
  Play,
  Volume2,
  Settings,
  Maximize2,
  Minimize2,
  ChevronRight,
  ChevronLeft,
  Smile,
  CheckSquare,
  Square,
  CloudUpload,
  Wand2,
  Mic,
  FileVideo,
  X,
  Loader2,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const IMG_FIREWORK = "https://images.unsplash.com/photo-1753614982374-07f89c5024a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXJld29ya3MlMjBuaWdodCUyMHNreSUyMGZlc3RpdmFsfGVufDF8fHx8MTc3MjY0ODg3OHww&ixlib=rb-4.1.0&q=80&w=400";

/* ─────────── Types & constants ─────────── */

type Phase = "idle" | "uploaded" | "processing" | "done";

type DetectedSound = {
  id: number;
  time: string;
  seconds: number;
  text: string;
  emoji: string;
  type?: "environmental" | "speech";
};

const STAGES = [
  { min: 0, max: 25, msg: "영상 파일을 읽는 중...", emoji: "📂" },
  { min: 25, max: 55, msg: "AI가 소리를 인식하는 중...", emoji: "🔊" },
  { min: 55, max: 80, msg: "자막을 생성하는 중...", emoji: "✍️" },
  { min: 80, max: 95, msg: "이모티콘을 매핑하는 중...", emoji: "😊" },
  { min: 95, max: 101, msg: "완료! 결과 플레이어로 전환합니다.", emoji: "✅" },
];

const MOCK_SOUNDS: DetectedSound[] = [
  { id: 1, time: "00:03", seconds: 3, text: "펑 소리", emoji: "💥", type: "environmental" },
  { id: 2, time: "00:06", seconds: 6, text: "와 진짜 크다!", emoji: "💬", type: "speech" },
  { id: 3, time: "00:12", seconds: 12, text: "큰 터지는 소리", emoji: "🎆", type: "environmental" },
  { id: 4, time: "00:20", seconds: 20, text: "사람들 웅성거림", emoji: "👥", type: "environmental" },
  { id: 5, time: "00:28", seconds: 28, text: "배경음악 시작", emoji: "🎵", type: "environmental" },
  { id: 6, time: "00:35", seconds: 35, text: "지금 터진 거 봤어?", emoji: "💬", type: "speech" },
  { id: 7, time: "00:45", seconds: 45, text: "박수 소리", emoji: "👏", type: "environmental" },
  { id: 8, time: "00:52", seconds: 52, text: "와 대박이다!", emoji: "💬", type: "speech" },
  { id: 9, time: "01:03", seconds: 63, text: "연속 폭발음", emoji: "🧨", type: "environmental" },
  { id: 10, time: "01:15", seconds: 75, text: "사진 찍어!", emoji: "💬", type: "speech" },
  { id: 11, time: "01:25", seconds: 85, text: "불꽃 치솟는 소리", emoji: "🎇", type: "environmental" },
  { id: 12, time: "01:40", seconds: 100, text: "환호 소리", emoji: "📣", type: "environmental" },
  { id: 13, time: "02:01", seconds: 121, text: "아 진짜 예쁘다", emoji: "💬", type: "speech" },
  { id: 14, time: "02:30", seconds: 150, text: "바람 소리", emoji: "💨", type: "environmental" },
];

const TOTAL_DURATION = 754;

function getStage(p: number) {
  return STAGES.find((s) => p >= s.min && p < s.max) ?? STAGES[4];
}

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

/* ── Reusable components ── */

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`relative w-11 h-6 rounded-full transition-all duration-300 ${
        checked ? "bg-blue-600" : "bg-slate-300"
      }`}
    >
      <motion.span
        className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-md"
        animate={{ x: checked ? 20 : 0 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
      />
    </button>
  );
}

function SmallToggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`relative w-9 h-5 rounded-full transition-all duration-300 ${
        checked ? "bg-blue-600" : "bg-slate-300"
      }`}
    >
      <motion.span
        className="absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow-md"
        animate={{ x: checked ? 16 : 0 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
      />
    </button>
  );
}

function SettingRow({
  icon,
  iconBg,
  label,
  sub,
  right,
}: {
  icon: React.ReactNode;
  iconBg: string;
  label: string;
  sub?: string;
  right: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
      <div className="flex items-center gap-2.5">
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${iconBg}`}>
          {icon}
        </div>
        <div>
          <p className="text-slate-700" style={{ fontSize: "0.8rem" }}>{label}</p>
          {sub && <p className="text-slate-400 mt-0.5" style={{ fontSize: "0.68rem" }}>{sub}</p>}
        </div>
      </div>
      {right}
    </div>
  );
}

function WaveformBars({ color = "#51a2ff" }: { color?: string }) {
  return (
    <div className="flex items-end gap-[2px] h-3 w-[10px]">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="w-[2px] rounded-full"
          style={{ backgroundColor: color }}
          animate={{ height: ["3px", `${6 + i * 2}px`, "3px"] }}
          transition={{ duration: 0.6 + i * 0.15, repeat: Infinity, ease: "easeInOut", delay: i * 0.12 }}
        />
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════
   MAIN COMPONENT
   ═══════════════════════════════════════════════ */

export function CaptionPage() {
  const navigate = useNavigate();

  /* ── Phase states ── */
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const [isDragOver, setIsDragOver] = useState(false);

  /* ── Settings (shown during idle/uploaded/processing) ── */
  const [captionOn, setCaptionOn] = useState(true);
  const [emojiOn, setEmojiOn] = useState(true);
  const [sensitivity, setSensitivity] = useState(70);
  const [captionStyle, setCaptionStyle] = useState("기본");
  const [settingsPanelOpen, setSettingsPanelOpen] = useState(true);

  /* ── Result player states (shown during done) ── */
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [soundVisibility, setSoundVisibility] = useState<Record<number, boolean>>(
    () => Object.fromEntries(MOCK_SOUNDS.map((s) => [s.id, true]))
  );
  const [activeSound, setActiveSound] = useState<DetectedSound | null>(null);
  const [rightPanelOpen, setRightPanelOpen] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [soundsPanelOpen, setSoundsPanelOpen] = useState(true);

  const videoRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const visibleCount = MOCK_SOUNDS.filter((s) => soundVisibility[s.id] !== false).length;

  /* ── Handlers ── */
  const handleUpload = () => setPhase("uploaded");

  const handleGenerate = () => {
    setPhase("processing");
    setProgress(0);
    intervalRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(intervalRef.current!);
          setPhase("done");
          setSoundVisibility(Object.fromEntries(MOCK_SOUNDS.map((s) => [s.id, true])));
          setActiveSound(MOCK_SOUNDS[8]); // 바람 소리 default
          setCurrentTime(150);
          
          // Create video edit state and navigate to Result Player
          const videoEditState = createVideoEditStateFromSounds(
            MOCK_SOUNDS.map(s => ({ id: s.id, time: s.time, emoji: s.emoji, text: s.text, type: s.type })),
            {
              videoId: `video-${Date.now()}`,
              videoTitle: "자연 다큐멘터리 Vol.1",
              videoThumbnail: IMG_FIREWORK,
              videoSource: IMG_FIREWORK,
              emojiOn: emojiOn,
              captionOn: captionOn,
              sensitivity: sensitivity,
              captionStyle: captionStyle,
              duration: TOTAL_DURATION,
            }
          );
          
          // Save to localStorage and navigate with state
          saveVideoEditState(videoEditState);
          
          // Navigate to Result Player after a short delay
          setTimeout(() => {
            navigate("/result", { state: videoEditState });
          }, 1500);
          
          return 100;
        }
        return prev + 1.5;
      });
    }, 50);
  };

  const handleSave = () => {
    alert("영상이 저장되었습니다!");
    navigate("/dashboard");
  };

  const handleNewConvert = () => {
    setPhase("idle");
    setProgress(0);
    setPlaying(false);
    setCurrentTime(0);
    setActiveSound(null);
    setIsFullscreen(false);
  };

  /* ── Playback simulation ── */
  useEffect(() => {
    if (phase === "done" && playing) {
      timerRef.current = setInterval(() => {
        setCurrentTime((t) => {
          if (t >= TOTAL_DURATION) { setPlaying(false); return 0; }
          const next = t + 1;
          const match = MOCK_SOUNDS.find((s) => s.seconds === next && soundVisibility[s.id] !== false);
          if (match) setActiveSound(match);
          return next;
        });
      }, 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [phase, playing, soundVisibility]);

  /* ── Fullscreen ── */
  const toggleFullscreen = useCallback(() => {
    setIsFullscreen((prev) => {
      if (!prev) setSoundsPanelOpen(true); // 전체화면 진입 시 패널 열기
      return !prev;
    });
  }, []);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFullscreen) setIsFullscreen(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isFullscreen]);

  /* ── Cleanup ── */
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const videoProgress = (currentTime / TOTAL_DURATION) * 100;
  const stage = getStage(Math.min(progress, 100));

  const soundDots = MOCK_SOUNDS.map((s) => ({
    ...s,
    pct: (s.seconds / TOTAL_DURATION) * 100,
    visible: soundVisibility[s.id] !== false,
  }));

  /* ═══════════════════════════════════════════════
     RENDER
     ═══════════════════════════════════════════════ */

  /* ── Done phase: Result Player (Figma design) ── */
  if (phase === "done") {
    return (
      <div className="flex flex-col h-screen bg-[rgba(248,250,252,0.5)]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
        {/* Header */}
        <header className="flex items-center h-[52px] px-5 bg-white border-b border-slate-100 shrink-0 z-20">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="flex items-center gap-2 text-slate-500 hover:text-slate-800 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span style={{ fontSize: "0.82rem" }}>대시보드로 돌아가기</span>
            </button>
            <div className="w-px h-5 bg-slate-200" />
            <div className="flex items-center gap-2 cursor-pointer select-none" onClick={() => navigate("/")}>
              <div className="w-6 h-6 rounded-md bg-blue-600 flex items-center justify-center">
                <Subtitles className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="text-slate-800" style={{ fontSize: "0.9rem" }}>SoundSee</span>
            </div>
          </div>
        </header>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Main area */}
          <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
            {/* Title row */}
            <div className="px-7 pt-7 pb-0 flex items-start justify-between shrink-0">
              <div>
                <h1 className="text-slate-900" style={{ fontSize: "1.2rem" }}>결과 플레이어</h1>
                <p className="text-slate-400 mt-0.5" style={{ fontSize: "0.78rem" }}>
                  자연_다큐멘터리_vol1.mp4 · AI 자막 적용됨
                </p>
              </div>
              <button
                onClick={handleSave}
                className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-[10px] shadow-sm transition-colors shrink-0"
                style={{ fontSize: "0.85rem" }}
              >
                <Download className="w-4 h-4" />
                저장하기
              </button>
            </div>

            {/* Video Player */}
            <div className="px-7 pt-5 pb-0 flex-1 min-h-0">
              <div
                ref={videoRef}
                className={`relative overflow-hidden bg-slate-900 shadow-lg ${
                  isFullscreen ? "fixed inset-0 z-50 rounded-none" : "rounded-2xl w-full"
                }`}
                style={isFullscreen ? undefined : { aspectRatio: "16/9" }}
              >
                <img src={IMG_FIREWORK} alt="영상" className="absolute inset-0 w-full h-full object-cover opacity-90" />

                {/* Floating emoji */}
                <AnimatePresence>
                  {activeSound && emojiOn && (
                    <motion.div
                      key={activeSound.id}
                      className="absolute top-5 right-5 select-none"
                      style={{ fontSize: "2.2rem" }}
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.5 }}
                    >
                      {activeSound.emoji}
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Caption overlay */}
                <AnimatePresence>
                  {activeSound && captionOn && soundVisibility[activeSound.id] !== false && (
                    <motion.div
                      className="absolute bottom-24 left-1/2 -translate-x-1/2 bg-slate-900/85 backdrop-blur-md text-white px-5 py-2.5 rounded-xl shadow-xl flex items-center gap-2.5"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                    >
                      {emojiOn && <span style={{ fontSize: "1.2rem" }}>{activeSound.emoji}</span>}
                      <span style={{ fontSize: "0.92rem" }}>{activeSound.text}</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Bottom gradient + controls */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[rgba(15,23,43,0.85)] to-transparent pt-10 px-4 pb-3 flex flex-col gap-3">
                  {/* Progress bar */}
                  <div className="relative h-1 bg-white/20 rounded-full w-full">
                    <div className="absolute left-0 top-0 h-full bg-blue-400 rounded-full" style={{ width: `${videoProgress}%` }} />
                    {soundDots.map((d) => (
                      <div
                        key={d.id}
                        className={`absolute top-0 w-1 h-1 rounded-full -translate-x-1/2 ${d.visible ? "bg-white/50" : "bg-white/20"}`}
                        style={{ left: `${d.pct}%` }}
                      />
                    ))}
                  </div>
                  {/* Transport controls */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-0">
                      <button className="w-8 h-8 flex items-center justify-center text-white/60 hover:text-white transition-colors">
                        <SkipBack className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setPlaying(!playing)}
                        className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
                      >
                        {playing ? <Pause className="w-3.5 h-3.5 text-white" /> : <Play className="w-3.5 h-3.5 text-white ml-0.5" />}
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-white/60 hover:text-white transition-colors">
                        <SkipForward className="w-4 h-4" />
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-white/60 hover:text-white transition-colors">
                        <Volume2 className="w-4 h-4" />
                      </button>
                      <span className="text-white/50 ml-1" style={{ fontSize: "0.72rem" }}>
                        {formatTime(currentTime)} / 12:34
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="text-white/60 hover:text-white transition-colors">
                        <Settings className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={toggleFullscreen} className="text-white/60 hover:text-white transition-colors">
                        {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Fullscreen overlays */}
                {isFullscreen && (
                  <>
                    {/* ── Bottom-left: Caption info + toggles ── */}
                    <div className="absolute bottom-20 left-4 flex flex-col gap-2 z-30">
                      {/* Current caption info bar */}
                      <AnimatePresence>
                        {activeSound && captionOn && soundVisibility[activeSound.id] !== false && (
                          <motion.div
                            className="flex items-center gap-2.5 bg-white/10 backdrop-blur-xl border border-white/20 px-3 py-2 rounded-xl"
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 8 }}
                          >
                            <Subtitles className="w-3.5 h-3.5 text-white/40" />
                            <div className="flex items-center gap-1 bg-teal-500/20 border border-teal-400/30 rounded-lg px-2 py-0.5">
                              <span className="text-teal-300" style={{ fontSize: "0.75rem" }}>
                                {emojiOn ? `${activeSound.emoji} ` : ""}[{activeSound.text}]
                              </span>
                            </div>
                            <span className="text-white/40" style={{ fontSize: "0.68rem" }}>{activeSound.time}</span>
                            <WaveformBars color="#93c5fd" />
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Toggle row: caption + emoji */}
                      <div className="flex items-center gap-2">
                        {/* Caption toggle */}
                        <div className="flex items-center gap-2 bg-white/10 backdrop-blur-xl border border-white/20 text-white px-3 py-2 rounded-xl">
                          <Subtitles className={`w-4 h-4 ${captionOn ? "text-blue-400" : "text-white/40"}`} />
                          <span style={{ fontSize: "0.78rem" }}>자막</span>
                          <SmallToggle checked={captionOn} onChange={setCaptionOn} />
                          <span className={captionOn ? "text-blue-400" : "text-white/40"} style={{ fontSize: "0.68rem" }}>
                            {captionOn ? "ON" : "OFF"}
                          </span>
                        </div>
                        {/* Emoji toggle */}
                        <div className="flex items-center gap-2 bg-white/10 backdrop-blur-xl border border-white/20 text-white px-3 py-2 rounded-xl">
                          <Smile className={`w-4 h-4 ${emojiOn ? "text-amber-400" : "text-white/40"}`} />
                          <span style={{ fontSize: "0.78rem" }}>이모티콘</span>
                          <SmallToggle checked={emojiOn} onChange={setEmojiOn} />
                          <span className={emojiOn ? "text-blue-400" : "text-white/40"} style={{ fontSize: "0.68rem" }}>
                            {emojiOn ? "ON" : "OFF"}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* ── Right: Sounds panel (expandable/collapsible) ── */}
                    <AnimatePresence>
                      {soundsPanelOpen && (
                        <motion.div
                          className="absolute top-4 right-4 bottom-20 w-[260px] bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 shadow-2xl flex flex-col overflow-hidden z-30"
                          initial={{ opacity: 0, x: 30 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 30 }}
                          transition={{ type: "spring", stiffness: 300, damping: 28 }}
                        >
                          <div className="flex items-center justify-between px-4 pt-3.5 pb-2.5 border-b border-white/10 shrink-0">
                            <div className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                              <h4 className="text-white/90" style={{ fontSize: "0.86rem" }}>인식된 소리</h4>
                              <span className="bg-white/15 text-white/70 px-1.5 py-0.5 rounded" style={{ fontSize: "0.6rem" }}>
                                {visibleCount}/{MOCK_SOUNDS.length}개
                              </span>
                            </div>
                            <button
                              onClick={() => setSoundsPanelOpen(false)}
                              className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/60 hover:text-white transition-colors"
                              title="패널 접기"
                            >
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
                            {MOCK_SOUNDS.map((sound) => {
                              const isVisible = soundVisibility[sound.id] !== false;
                              const isActive = activeSound?.id === sound.id;
                              return (
                                <button
                                  key={sound.id}
                                  onClick={() => setSoundVisibility((prev) => ({ ...prev, [sound.id]: !isVisible }))}
                                  onDoubleClick={() => {
                                    setActiveSound(sound);
                                    setCurrentTime(sound.seconds);
                                  }}
                                  className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-xl transition-all text-left ${
                                    isActive
                                      ? "bg-blue-500/25 border border-blue-400/40"
                                      : isVisible
                                        ? "bg-white/5 hover:bg-white/15"
                                        : "bg-white/[0.02] hover:bg-white/10 opacity-50"
                                  }`}
                                >
                                  {isVisible
                                    ? <CheckSquare className="w-4 h-4 text-blue-400 shrink-0" />
                                    : <Square className="w-4 h-4 text-white/30 shrink-0" />}
                                  <span className="text-white/50 shrink-0" style={{ fontSize: "0.68rem" }}>{sound.time}</span>
                                  <span style={{ fontSize: "0.9rem" }}>{sound.emoji}</span>
                                  <span className={`text-xs truncate ${isActive ? "text-blue-300" : isVisible ? "text-white/80" : "text-white/40 line-through"}`}>
                                    {sound.text}
                                  </span>
                                  {isActive && <WaveformBars color="#93c5fd" />}
                                </button>
                              );
                            })}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Collapsed panel open button */}
                    {!soundsPanelOpen && (
                      <motion.button
                        onClick={() => setSoundsPanelOpen(true)}
                        className="absolute top-1/2 -translate-y-1/2 right-4 flex items-center gap-2 bg-white/10 backdrop-blur-xl border border-white/20 px-3 py-2.5 rounded-xl text-white/60 hover:text-white hover:bg-white/20 transition-all shadow-lg z-30"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        title="인식된 소리 패널 펼치기"
                      >
                        <ChevronLeft className="w-4 h-4" />
                        <span style={{ fontSize: "0.72rem" }}>인식된 소리</span>
                      </motion.button>
                    )}

                    {/* Fullscreen exit */}
                    <button
                      onClick={toggleFullscreen}
                      className="absolute top-4 left-4 w-9 h-9 rounded-xl bg-white/10 backdrop-blur-xl border border-white/20 text-white/60 hover:text-white hover:bg-white/20 flex items-center justify-center z-30"
                      title="전체화면 종료 (ESC)"
                    >
                      <Minimize2 className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Bottom bar: caption info + emoji toggle */}
            <div className="px-7 pt-4 pb-7 flex items-center gap-3 shrink-0">
              <div className="flex-1 flex items-center gap-3 bg-white border border-slate-200 rounded-[14px] shadow-sm px-4 py-3 min-h-[52px]">
                <Subtitles className="w-4 h-4 text-slate-300 shrink-0" />
                {activeSound && captionOn && soundVisibility[activeSound.id] !== false ? (
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1 bg-teal-50 border border-teal-200 rounded-[10px] px-2.5 py-1">
                      <span className="text-teal-700" style={{ fontSize: "0.78rem" }}>
                        {emojiOn ? `${activeSound.emoji} ` : ""}[{activeSound.text}]
                      </span>
                    </div>
                    <span className="text-slate-400" style={{ fontSize: "0.72rem" }}>{activeSound.time}</span>
                    <WaveformBars />
                  </div>
                ) : (
                  <span className="text-slate-400" style={{ fontSize: "0.78rem" }}>자막 없음</span>
                )}
              </div>

              <div className="flex items-center gap-3 bg-white border border-slate-200 rounded-[14px] shadow-sm px-4 py-3 shrink-0">
                <Smile className={`w-4 h-4 ${emojiOn ? "text-amber-500" : "text-slate-300"}`} />
                <span className="text-slate-600" style={{ fontSize: "0.8rem" }}>이모티콘 표시</span>
                <SmallToggle checked={emojiOn} onChange={setEmojiOn} />
                <span className={emojiOn ? "text-blue-600" : "text-slate-400"} style={{ fontSize: "0.72rem" }}>
                  {emojiOn ? "ON" : "OFF"}
                </span>
              </div>
            </div>
          </div>

          {/* Right panel — 인식된 소리 */}
          <AnimatePresence>
            {rightPanelOpen && (
              <motion.aside
                className="w-[280px] bg-white border-l border-slate-100 flex flex-col shrink-0"
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 280, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex items-center justify-between px-4 h-[57px] border-b border-slate-100 shrink-0">
                  <div className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50" />
                    <h3 className="text-slate-800" style={{ fontSize: "0.86rem" }}>인식된 소리</h3>
                    <span className="bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded" style={{ fontSize: "0.6rem" }}>
                      {visibleCount}/{MOCK_SOUNDS.length}개
                    </span>
                  </div>
                  <button
                    onClick={() => setRightPanelOpen(false)}
                    className="w-6 h-6 rounded-[10px] flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto px-2 pt-2">
                  <div className="space-y-px">
                    {MOCK_SOUNDS.map((sound) => {
                      const isVisible = soundVisibility[sound.id] !== false;
                      const isActive = activeSound?.id === sound.id;
                      return (
                        <button
                          key={sound.id}
                          onClick={() => setSoundVisibility((prev) => ({ ...prev, [sound.id]: !isVisible }))}
                          onDoubleClick={() => {
                            setActiveSound(sound);
                            setCurrentTime(sound.seconds);
                          }}
                          className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-[10px] transition-all text-left ${
                            isActive
                              ? "bg-blue-50 border border-blue-200"
                              : isVisible
                                ? "hover:bg-slate-50"
                                : "opacity-50 hover:bg-slate-50"
                          }`}
                        >
                          {isVisible
                            ? <CheckSquare className="w-4 h-4 text-blue-600 shrink-0" />
                            : <Square className="w-4 h-4 text-slate-400 shrink-0" />}
                          <span className={`shrink-0 ${isActive ? "text-blue-600" : "text-slate-400"}`} style={{ fontSize: "0.68rem" }}>
                            {sound.time}
                          </span>
                          <span style={{ fontSize: "0.9rem" }}>{sound.emoji}</span>
                          <span
                            className={`flex-1 truncate ${
                              isActive ? "text-blue-700" : isVisible ? "text-slate-700" : "text-slate-400 line-through"
                            }`}
                            style={{ fontSize: "0.78rem" }}
                          >
                            {sound.text}
                          </span>
                          {isActive && <WaveformBars />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="p-3 border-t border-slate-100 shrink-0">
                  <button
                    onClick={handleNewConvert}
                    className="w-full py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-[10px] transition-colors text-center"
                    style={{ fontSize: "0.78rem" }}
                  >
                    새 영상 변환하기
                  </button>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {!rightPanelOpen && (
            <button
              onClick={() => setRightPanelOpen(true)}
              className="absolute top-[72px] right-0 bg-white border border-slate-200 rounded-l-lg p-2 shadow-sm text-slate-400 hover:text-slate-600 transition-colors z-10"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    );
  }

  /* ══════════════════════════════════════════════════════
     UPLOAD / SETTINGS / PROCESSING PHASES
     ══════════════════════════════════════════════════════ */
  return (
    <div className="flex flex-col h-screen bg-[rgba(248,250,252,0.5)]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
      {/* Header */}
      <header className="flex items-center h-[52px] px-5 bg-white border-b border-slate-100 shrink-0 z-20">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="flex items-center gap-2 text-slate-500 hover:text-slate-800 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span style={{ fontSize: "0.82rem" }}>대시보드로 돌아가기</span>
          </button>
          <div className="w-px h-5 bg-slate-200" />
          <div className="flex items-center gap-2 cursor-pointer select-none" onClick={() => navigate("/")}>
            <div className="w-6 h-6 rounded-md bg-blue-600 flex items-center justify-center">
              <Subtitles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-slate-800" style={{ fontSize: "0.9rem" }}>SoundSee</span>
          </div>
        </div>
      </header>

      {/* Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Main area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Page title */}
          <div className="bg-white border-b border-slate-100 px-7 py-5 flex items-center justify-between shrink-0">
            <div>
              <h1 className="text-slate-900" style={{ fontSize: "1.2rem" }}>AI 자막 생성</h1>
              <p className="text-slate-400 mt-0.5" style={{ fontSize: "0.78rem" }}>영상을 업로드하고 AI 자막을 자동으로 생성하세요</p>
            </div>
            <button
              onClick={() => setSettingsPanelOpen(!settingsPanelOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors"
              style={{ fontSize: "0.78rem" }}
            >
              설정
              <ChevronRight className={`w-3.5 h-3.5 text-slate-400 transition-transform ${settingsPanelOpen ? "rotate-180" : ""}`} />
            </button>
          </div>

          <div className="flex-1 flex flex-col p-7 overflow-y-auto">
            {/* ── Upload zone ── */}
            {phase === "idle" && (
              <motion.div
                className={`flex-1 flex flex-col items-center justify-center border-2 border-dashed rounded-2xl cursor-pointer transition-colors min-h-[300px] ${
                  isDragOver ? "border-blue-400 bg-blue-50" : "border-slate-200 hover:border-blue-300 bg-white hover:bg-slate-50"
                }`}
                onClick={handleUpload}
                onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={(e) => { e.preventDefault(); setIsDragOver(false); handleUpload(); }}
                whileHover={{ scale: 1.003 }}
                transition={{ duration: 0.15 }}
              >
                <motion.div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 ${isDragOver ? "bg-blue-100" : "bg-slate-100"}`}
                  animate={isDragOver ? { scale: [1, 1.08, 1] } : {}}
                  transition={{ duration: 0.4 }}
                >
                  <CloudUpload className={`w-7 h-7 ${isDragOver ? "text-blue-500" : "text-slate-400"}`} />
                </motion.div>
                <p className="text-slate-700 mb-1" style={{ fontSize: "0.95rem" }}>
                  영상을 드래그하거나 클릭하여 업로드
                </p>
                <p className="text-slate-400 mb-6" style={{ fontSize: "0.78rem" }}>
                  MP4, MOV, AVI 지원 · 최대 2GB
                </p>
                <button
                  onClick={(e) => { e.stopPropagation(); handleUpload(); }}
                  className="flex items-center gap-2 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shadow-sm"
                  style={{ fontSize: "0.82rem" }}
                >
                  <CloudUpload className="w-3.5 h-3.5" />
                  영상 업로드
                </button>
              </motion.div>
            )}

            {/* ── Uploaded preview ── */}
            {phase === "uploaded" && (
              <motion.div className="flex-1 flex flex-col" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}>
                <div className="relative rounded-2xl overflow-hidden bg-slate-900 flex-1 min-h-[280px]">
                  <ImageWithFallback src={IMG_FIREWORK} alt="업로드된 영상" className="w-full h-full object-cover opacity-90" />
                  <div className="absolute top-3.5 left-3.5 flex items-center gap-2 bg-white/90 backdrop-blur-sm text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200 shadow-sm">
                    <FileVideo className="w-3.5 h-3.5 text-blue-500" />
                    <span style={{ fontSize: "0.72rem" }}>자연_다큐멘터리_vol1.mp4</span>
                    <span className="text-slate-400" style={{ fontSize: "0.68rem" }}>248 MB</span>
                  </div>
                  <button
                    onClick={() => setPhase("idle")}
                    className="absolute top-3.5 right-3.5 w-7 h-7 rounded-lg bg-white/90 text-slate-600 hover:text-slate-900 flex items-center justify-center shadow-sm border border-slate-200"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-white/25 backdrop-blur-sm border border-white/40 flex items-center justify-center">
                      <span className="text-white ml-0.5" style={{ fontSize: "1rem" }}>▶</span>
                    </div>
                  </div>
                  <div className="absolute bottom-3 right-3 bg-slate-900/70 text-white rounded-md px-2 py-0.5 backdrop-blur-sm" style={{ fontSize: "0.68rem" }}>
                    12:34
                  </div>
                </div>
                <div className="flex items-center gap-2 mt-3 px-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="text-emerald-600" style={{ fontSize: "0.78rem" }}>업로드 완료 — 자연_다큐멘터리_vol1.mp4</span>
                </div>
              </motion.div>
            )}

            {/* ── Processing ── */}
            {phase === "processing" && (
              <motion.div className="flex-1 flex flex-col" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <div className="relative rounded-2xl overflow-hidden bg-slate-900 flex-1 min-h-[280px]">
                  <ImageWithFallback src={IMG_FIREWORK} alt="영상 처리 중" className="w-full h-full object-cover opacity-35" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                    <motion.div
                      className="w-14 h-14 rounded-full bg-blue-600/20 border border-blue-400/30 flex items-center justify-center"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }}
                    >
                      <Sparkles className="w-6 h-6 text-blue-300" />
                    </motion.div>
                    <div className="text-center">
                      <p className="text-white" style={{ fontSize: "0.9rem" }}>{stage.emoji} {stage.msg}</p>
                      <p className="text-white/50 mt-1" style={{ fontSize: "0.75rem" }}>AI가 영상 속 소리를 분석 중입니다</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Action buttons */}
            <div className="flex items-center gap-2.5 mt-5 shrink-0">
              <button
                onClick={handleUpload}
                disabled={phase === "processing"}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ fontSize: "0.82rem" }}
              >
                <CloudUpload className="w-3.5 h-3.5 text-slate-400" />
                영상 업로드
              </button>
              <button
                onClick={handleGenerate}
                disabled={phase === "idle" || phase === "processing"}
                className="flex items-center gap-2 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ fontSize: "0.82rem" }}
              >
                {phase === "processing"
                  ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />처리 중...</>
                  : <><Wand2 className="w-3.5 h-3.5" />AI 자막 생성</>}
              </button>
            </div>

            {/* Progress bar */}
            <AnimatePresence>
              {phase === "processing" && (
                <motion.div
                  className="mt-4 bg-white border border-slate-200 rounded-xl p-4 shrink-0"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-slate-600" style={{ fontSize: "0.8rem" }}>{stage.emoji} {stage.msg}</p>
                    <span className="text-blue-600" style={{ fontSize: "0.8rem" }}>
                      {Math.min(Math.round(progress), 100)}%
                    </span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full rounded-full bg-blue-500"
                      animate={{ width: `${Math.min(progress, 100)}%` }}
                      transition={{ ease: "easeOut" }}
                    />
                  </div>
                  <div className="flex items-center gap-1.5 mt-3">
                    {STAGES.map((s, i) => (
                      <div
                        key={i}
                        className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-center transition-colors ${
                          progress >= s.min ? "bg-blue-50 text-blue-600" : "bg-slate-100 text-slate-400"
                        }`}
                        style={{ fontSize: "0.62rem" }}
                      >
                        {s.emoji}
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* ── Settings Panel ── */}
        <AnimatePresence>
          {settingsPanelOpen && (
            <motion.aside
              className="w-[272px] bg-white border-l border-slate-100 flex flex-col shrink-0 overflow-y-auto"
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 272, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <div className="p-5">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-slate-800" style={{ fontSize: "0.9rem" }}>설정</h2>
                </div>

                {/* Caption toggles */}
                <section className="mb-5">
                  <p className="text-slate-400 mb-1 uppercase" style={{ fontSize: "0.6rem", letterSpacing: "0.08em" }}>자막 옵션</p>
                  <div className="bg-slate-50 rounded-xl px-3 divide-y divide-slate-100">
                    <SettingRow
                      icon={<Subtitles className="w-3.5 h-3.5 text-blue-500" />}
                      iconBg="bg-blue-50"
                      label="자막 표시"
                      sub="소리 텍스트 자막"
                      right={<Toggle checked={captionOn} onChange={setCaptionOn} />}
                    />
                    <SettingRow
                      icon={<Smile className="w-3.5 h-3.5 text-amber-500" />}
                      iconBg="bg-amber-50"
                      label="이모티콘 표시"
                      sub="소리 아이콘 표시"
                      right={<Toggle checked={emojiOn} onChange={setEmojiOn} />}
                    />
                  </div>
                </section>

                {/* Sensitivity */}
                <section className="mb-5">
                  <p className="text-slate-400 mb-1 uppercase" style={{ fontSize: "0.6rem", letterSpacing: "0.08em" }}>감도</p>
                  <div className="bg-slate-50 rounded-xl p-3">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-7 h-7 rounded-lg bg-violet-50 flex items-center justify-center">
                        <Mic className="w-3.5 h-3.5 text-violet-500" />
                      </div>
                      <span className="text-slate-700 flex-1" style={{ fontSize: "0.8rem" }}>소리 인식 민감도</span>
                      <span className="text-blue-600" style={{ fontSize: "0.78rem" }}>{sensitivity}%</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={sensitivity}
                      onChange={(e) => setSensitivity(Number(e.target.value))}
                      className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                      style={{ background: `linear-gradient(to right, #2563EB ${sensitivity}%, #E2E8F0 ${sensitivity}%)` }}
                    />
                    <div className="flex justify-between mt-1">
                      <span className="text-slate-400" style={{ fontSize: "0.62rem" }}>낮음</span>
                      <span className="text-slate-400" style={{ fontSize: "0.62rem" }}>높음</span>
                    </div>
                  </div>
                </section>

                {/* Caption style */}
                <section>
                  <p className="text-slate-400 mb-1 uppercase" style={{ fontSize: "0.6rem", letterSpacing: "0.08em" }}>자막 스타일</p>
                  <div className="grid grid-cols-3 gap-1.5">
                    {["기본", "크게", "배경 포함"].map((s) => (
                      <button
                        key={s}
                        onClick={() => setCaptionStyle(s)}
                        className={`py-2 rounded-lg border transition-all text-center ${
                          captionStyle === s
                            ? "bg-blue-50 border-blue-200 text-blue-700"
                            : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                        style={{ fontSize: "0.72rem" }}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </section>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}