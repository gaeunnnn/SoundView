/**
 * Result Player Page
 * 
 * Displays video with detected sound captions and timeline.
 * 
 * STATE INITIALIZATION:
 * - Loads state from: route state → localStorage → default
 * - Works identically from all entry paths:
 *   1. Dashboard → click video
 *   2. Upload → AI caption generate
 *   3. Direct navigation / page refresh
 * 
 * STATE PERSISTENCE:
 * - Timeline visibility changes are saved to localStorage
 * - Emoji toggle state is saved to localStorage
 * - User can refresh and return with preserved state
 */

import { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { initializeVideoEditState, saveVideoEditState, type VideoEditState, type TimelineItem } from "../utils/video-state";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  SkipBack,
  SkipForward,
  Settings,
  Download,
  SmileIcon,
  Subtitles,
  ArrowLeft,
  Minimize2,
  Vibrate,
  Eye,
  EyeOff,
  Sparkles,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// Fireworks background image (same as Login page)
const FIREWORKS_IMAGE =
  "https://images.unsplash.com/photo-1729931597118-e49ddbea68ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdodCUyMHNreSUyMGZpcmV3b3JrcyUyMGNvbG9yZnVsJTIwZXhwbG9zaW9uJTIwY2VsZWJyYXRpb258ZW58MXx8fHwxNzcyNjAxMDMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

const TOTAL = 754;

// Dynamic caption positions (cycling through different areas)
const CAPTION_POSITIONS = [
  { left: "8%", top: "15%" },
  { left: "52%", top: "22%" },
  { left: "12%", top: "58%" },
  { left: "58%", top: "48%" },
  { left: "28%", top: "32%" },
  { left: "68%", top: "62%" },
  { left: "18%", top: "42%" },
  { left: "48%", top: "68%" },
  { left: "38%", top: "18%" },
  { left: "72%", top: "35%" },
];

function fmt(s: number) {
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
}

export function ResultPage() {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Initialize video edit state from route state, localStorage, or default
  const initialState = initializeVideoEditState(location.state as VideoEditState | undefined);
  
  const [playing, setPlaying]       = useState(true);
  const [muted, setMuted]           = useState(false);
  const [emojiOn, setEmojiOn]       = useState(initialState.emojiOn);
  const [vibrationOn, setVibrationOn] = useState(initialState.vibrationOn ?? true);
  const [panelOpen, setPanelOpen]   = useState(true);
  const [time, setTime]             = useState(0);
  const [envCaptionIdx, setEnvCaptionIdx] = useState(0);
  const [speechCaptionIdx, setSpeechCaptionIdx] = useState(0);
  const [timeline, setTimeline]     = useState<TimelineItem[]>(initialState.timeline);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const videoRef = useRef<HTMLDivElement>(null);
  const [fsPanelOpen, setFsPanelOpen] = useState(true);
  const [shakeKey, setShakeKey] = useState(0);
  // Multi-caption: track which env captions are currently "active" (shown simultaneously)
  const [activeEnvSet, setActiveEnvSet] = useState<number[]>([0, 1]);
  const activeEnvCycleRef = useRef(0);

  // Derived: separate tracks
  const envTimeline = timeline.filter(item => item.type !== "speech");
  const speechTimeline = timeline.filter(item => item.type === "speech");
  const visibleEnv = envTimeline.filter(item => item.visible);
  const visibleSpeech = speechTimeline.filter(item => item.visible);

  // Current captions from each track
  const envCaption = visibleEnv.length > 0 ? visibleEnv[envCaptionIdx % visibleEnv.length] : null;
  const speechCaption = visibleSpeech.length > 0 ? visibleSpeech[speechCaptionIdx % visibleSpeech.length] : null;

  // Active environmental captions (multiple simultaneous)
  const activeEnvCaptions = activeEnvSet
    .filter(idx => idx < visibleEnv.length)
    .map(idx => ({ ...visibleEnv[idx], _posIdx: idx }));

  // Playback ticker
  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setTime((p) => { if (p >= TOTAL) { setPlaying(false); return TOTAL; } return p + 0.5; }), 500);
    return () => clearInterval(t);
  }, [playing]);

  // Environmental caption cycle
  useEffect(() => {
    if (!playing || visibleEnv.length === 0) return;
    // Multi-caption: rotate one slot at a time every 2s, showing up to 3 simultaneously
    const maxShow = Math.min(3, visibleEnv.length);
    // Initialize active set if needed
    setActiveEnvSet(prev => {
      if (prev.length === 0 || prev.every(i => i >= visibleEnv.length)) {
        return Array.from({ length: maxShow }, (_, i) => i % visibleEnv.length);
      }
      return prev.slice(0, maxShow);
    });
    const t = setInterval(() => {
      activeEnvCycleRef.current = (activeEnvCycleRef.current + 1) % maxShow;
      setActiveEnvSet(prev => {
        const next = [...prev];
        const allIndices = new Set(prev);
        let candidate = (Math.max(...prev) + 1) % visibleEnv.length;
        let attempts = 0;
        while (allIndices.has(candidate) && attempts < visibleEnv.length) {
          candidate = (candidate + 1) % visibleEnv.length;
          attempts++;
        }
        next[activeEnvCycleRef.current % next.length] = candidate;
        return next;
      });
      setEnvCaptionIdx((p) => (p + 1) % visibleEnv.length);
    }, 2500);
    return () => clearInterval(t);
  }, [playing, visibleEnv.length]);

  // Speech caption cycle
  useEffect(() => {
    if (!playing || visibleSpeech.length === 0) return;
    const t = setInterval(() => {
      setSpeechCaptionIdx((p) => (p + 1) % visibleSpeech.length);
    }, 4000);
    return () => clearInterval(t);
  }, [playing, visibleSpeech.length]);

  // Trigger shake on caption change when vibrationOn
  useEffect(() => {
    if (vibrationOn && playing) {
      setShakeKey(k => k + 1);
    }
  }, [envCaptionIdx, vibrationOn, playing]);

  const toggleVisibility = (id: number) => {
    setTimeline(prev => {
      const updated = prev.map(item => 
        item.id === id ? { ...item, visible: !item.visible } : item
      );
      const currentState = {
        ...initialState,
        timeline: updated,
        emojiOn,
        vibrationOn,
      };
      saveVideoEditState(currentState);
      return updated;
    });
  };
  
  const handleEmojiToggle = () => {
    const newEmojiOn = !emojiOn;
    setEmojiOn(newEmojiOn);
    const currentState = {
      ...initialState,
      timeline,
      emojiOn: newEmojiOn,
      vibrationOn,
    };
    saveVideoEditState(currentState);
  };

  const handleVibrationToggle = () => {
    const newVibrationOn = !vibrationOn;
    setVibrationOn(newVibrationOn);
    const currentState = {
      ...initialState,
      timeline,
      emojiOn,
      vibrationOn: newVibrationOn,
    };
    saveVideoEditState(currentState);
  };

  // Fullscreen toggle with fallback for permission restrictions
  const toggleFullscreen = async () => {
    if (!isFullscreen) {
      const element = videoRef.current as any;
      if (element) {
        try {
          if (element.requestFullscreen) {
            await element.requestFullscreen();
            setIsFullscreen(true);
          } else if (element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
            setIsFullscreen(true);
          }
        } catch (err) {
          setIsFullscreen(true);
        }
      }
    } else {
      const doc = document as any;
      try {
        if (doc.exitFullscreen && doc.fullscreenElement) {
          await doc.exitFullscreen();
        } else if (doc.webkitExitFullscreen && doc.webkitFullscreenElement) {
          doc.webkitExitFullscreen();
        }
      } catch (err) {}
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      const doc = document as any;
      const isVideoFullscreen = 
        doc.fullscreenElement === videoRef.current || 
        doc.webkitFullscreenElement === videoRef.current;
      if (!isVideoFullscreen && (doc.fullscreenElement || doc.webkitFullscreenElement)) {
        return;
      }
      setIsFullscreen(isVideoFullscreen);
    };
    document.addEventListener("fullscreenchange", handleFsChange);
    document.addEventListener("webkitfullscreenchange", handleFsChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFsChange);
      document.removeEventListener("webkitfullscreenchange", handleFsChange);
    };
  }, []);

  const handleSave = () => {
    const savedVideo = {
      id: Date.now(),
      title: "자연 다큐멘터리 Vol.1 (편집됨)",
      thumb: FIREWORKS_IMAGE,
      date: new Date().toISOString().split('T')[0].replace(/-/g, '.').slice(2),
      duration: "12:34",
      owner: "my",
      hasCaptions: true,
      liked: false,
      timeline: timeline,
      emojiOn: emojiOn,
      isEdited: true,
    };
    const existing = localStorage.getItem('savedVideos');
    const savedVideos = existing ? JSON.parse(existing) : [];
    savedVideos.unshift(savedVideo);
    localStorage.setItem('savedVideos', JSON.stringify(savedVideos));
    navigate('/dashboard');
  };

  const progress = (time / TOTAL) * 100;
  const visibleCount = timeline.filter(item => item.visible).length;

  /* ────────────────────── RENDER ────────────────────── */

  return (
    <div className="flex flex-col h-screen bg-[#f8f9fb] relative overflow-hidden" style={{ fontFamily: "'Inter', 'Noto Sans KR', sans-serif" }}>
      {/* ── Header ── */}
      <header className="flex items-center justify-between h-[54px] px-5 bg-white border-b border-slate-200/60 shrink-0 z-20">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 group"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-600 to-blue-500 flex items-center justify-center shadow-sm">
              <Subtitles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-slate-900" style={{ fontSize: "0.88rem", fontWeight: 600, letterSpacing: "-0.01em" }}>
              SoundSee
            </span>
          </button>
          <div className="w-px h-4 bg-slate-200 mx-1" />
          <button
            onClick={() => navigate("/dashboard")}
            className="flex items-center gap-1.5 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span style={{ fontSize: "0.78rem", fontWeight: 450 }}>대시보드</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            className="flex items-center gap-2 px-4 py-[7px] bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all shadow-sm hover:shadow-md active:scale-[0.98]"
            style={{ fontSize: "0.8rem", fontWeight: 500 }}
            onClick={handleSave}
          >
            <Download className="w-3.5 h-3.5" />
            저장하기
          </button>
        </div>
      </header>

      {/* ── Main Content ── */}
      <div className="flex flex-1 overflow-hidden">
        {/* Video Player Area */}
        <div className="flex-1 flex flex-col min-w-0 p-5 gap-4">
          {/* Title row */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-500" />
              <h1 className="text-slate-800" style={{ fontSize: "0.95rem", fontWeight: 600, letterSpacing: "-0.01em" }}>
                결과 플레이어
              </h1>
            </div>
            <span className="text-slate-300">·</span>
            <p className="text-slate-400" style={{ fontSize: "0.76rem", fontWeight: 400 }}>
              자연_다큐멘터리_vol1.mp4
            </p>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100" style={{ fontSize: "0.65rem", fontWeight: 500 }}>
              <span className="w-1 h-1 rounded-full bg-emerald-500" />
              AI 자막 적용됨
            </span>
          </div>

          {/* Video player */}
          <div 
            className={`relative bg-slate-950 rounded-xl overflow-hidden flex-1 min-h-[300px] ${
              isFullscreen ? 'fullscreen-player' : 'shadow-[0_1px_3px_rgba(0,0,0,0.08),0_8px_24px_rgba(0,0,0,0.06)]'
            }`} 
            ref={videoRef}
          >
            <ImageWithFallback
              src={FIREWORKS_IMAGE}
              alt="영상 재생 중"
              className="w-full h-full object-cover opacity-90"
            />

            {/* Vibration shake effect overlay */}
            <AnimatePresence>
              {vibrationOn && playing && envCaption?.visible && (
                <motion.div
                  key={`shake-${shakeKey}`}
                  className="absolute inset-0 pointer-events-none z-[5]"
                  initial={{ x: 0, y: 0 }}
                  animate={{
                    x: [0, -3, 3, -2, 2, -1, 1, 0],
                    y: [0, 2, -2, 1, -1, 0.5, -0.5, 0],
                  }}
                  transition={{ duration: 0.35, ease: "easeOut" }}
                >
                  <div className="w-full h-full border-2 border-orange-400/30 rounded-xl" />
                </motion.div>
              )}
            </AnimatePresence>

            {/* ── Fullscreen-specific overlays ── */}
            {isFullscreen && (
              <>
                {/* Top gradient */}
                <div className="absolute top-0 left-0 right-0 h-28 bg-gradient-to-b from-black/50 to-transparent pointer-events-none z-10" />

                {/* Fullscreen panel */}
                <AnimatePresence initial={false}>
                  {fsPanelOpen ? (
                    <motion.div
                      key="fs-panel-open"
                      className="absolute top-5 right-5 bottom-28 w-[320px] bg-black/40 border border-white/[0.08] rounded-2xl flex flex-col z-40 overflow-hidden"
                      initial={{ x: 380, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      exit={{ x: 380, opacity: 0 }}
                      transition={{ type: "spring", damping: 28, stiffness: 220 }}
                    >
                      <div className="flex items-center justify-between px-4 py-4 border-b border-white/[0.06]">
                        <div className="flex items-center gap-2.5">
                          <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse" />
                          <span className="text-white/90" style={{ fontSize: "0.82rem", fontWeight: 500 }}>인식된 소리</span>
                          <span className="text-white/30" style={{ fontSize: "0.7rem" }}>
                            {visibleCount}/{timeline.length}
                          </span>
                        </div>
                        <button
                          onClick={() => setFsPanelOpen(false)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-white/40 hover:text-white/70 transition-colors"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex-1 overflow-y-auto py-2 px-2 custom-scrollbar">
                        {timeline.map((item, i) => {
                          const isActive = i === envCaptionIdx && item.visible;
                          return (
                            <div
                              key={item.id}
                              className={`flex items-center gap-2.5 w-full px-3 py-2.5 rounded-xl mb-1 transition-all ${
                                isActive ? "bg-blue-500/20 border border-blue-400/30" : "hover:bg-white/[0.04] border border-transparent"
                              } ${!item.visible ? "opacity-25" : ""}`}
                            >
                              <button
                                onClick={() => toggleVisibility(item.id)}
                                className={`shrink-0 transition-colors ${item.visible ? "text-blue-400" : "text-white/20 hover:text-white/40"}`}
                              >
                                {item.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                              </button>
                              <button
                                onClick={() => {
                                  if (item.visible) {
                                    setEnvCaptionIdx(i);
                                    const [m, s] = item.time.split(":").map(Number);
                                    setTime(m * 60 + s);
                                  }
                                }}
                                disabled={!item.visible}
                                className="flex items-center gap-2.5 flex-1 text-left"
                              >
                                <span
                                  className={`shrink-0 tabular-nums font-mono ${isActive ? "text-blue-300" : "text-white/30"}`}
                                  style={{ fontSize: "0.72rem" }}
                                >
                                  {item.time}
                                </span>
                                <span style={{ fontSize: "1.05rem" }}>{item.emoji}</span>
                                <span
                                  className={`truncate flex-1 ${isActive ? "text-white" : "text-white/60"}`}
                                  style={{ fontSize: "0.8rem", fontWeight: isActive ? 500 : 400 }}
                                >
                                  {item.label}
                                </span>
                                {isActive && playing && (
                                  <div className="flex items-end gap-[3px] h-3.5 px-0.5">
                                    {[0, 1, 2].map((j) => (
                                      <motion.div
                                        key={j}
                                        className="w-[3px] bg-blue-400 rounded-full"
                                        animate={{ height: ["3px", "11px", "3px"] }}
                                        transition={{ duration: 0.55, delay: j * 0.1, repeat: Infinity }}
                                      />
                                    ))}
                                  </div>
                                )}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="fs-panel-closed"
                      className="absolute top-1/2 right-3 -translate-y-1/2 z-40"
                      initial={{ opacity: 0, x: 16 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 16 }}
                    >
                      <button
                        onClick={() => setFsPanelOpen(true)}
                        className="group flex flex-col items-center gap-2.5 px-2.5 py-5 bg-black/40 border border-white/[0.08] rounded-xl text-white/40 hover:text-white/80 hover:bg-black/50 transition-all"
                      >
                        <ChevronLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5" />
                        <span style={{ fontSize: "0.6rem", writingMode: "vertical-lr", letterSpacing: "0.1em", fontWeight: 500 }}>
                          SOUNDS
                        </span>
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Fullscreen env captions (multiple simultaneous) */}
                <AnimatePresence>
                  {activeEnvCaptions.map((cap, slotIdx) => {
                    if (!cap.visible || cap.type === "speech") return null;
                    const pos = CAPTION_POSITIONS[cap._posIdx % CAPTION_POSITIONS.length];
                    return (
                      <motion.div
                        key={`fs-multi-${cap.id}`}
                        className="absolute z-30 pointer-events-none"
                        style={{ left: pos.left, top: pos.top }}
                        initial={{ opacity: 0, scale: 0.7, y: 18 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.85, y: -10 }}
                        transition={{ duration: 0.4, ease: "easeOut", delay: slotIdx * 0.08 }}
                      >
                        {emojiOn ? (
                          <div className="relative">
                            <motion.div
                              className="absolute rounded-full bg-white/10"
                              animate={{ scale: [1, 1.5, 1], opacity: [0.4, 0, 0.4] }}
                              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                              style={{ width: 72, height: 72, top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
                            />
                            <span
                              style={{
                                fontSize: "3.2rem",
                                filter: "drop-shadow(0 0 14px rgba(255,255,255,0.7)) drop-shadow(0 4px 10px rgba(0,0,0,0.9))",
                              }}
                            >
                              {cap.emoji}
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 px-4 py-2 bg-black/50 border border-white/15 rounded-2xl shadow-2xl">
                            <span style={{ fontSize: "1.4rem" }}>{cap.emoji}</span>
                            <span className="text-white" style={{ fontSize: "1rem", fontWeight: 500 }}>
                              {cap.label}
                            </span>
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </AnimatePresence>

                {/* Fullscreen speech caption */}
                <AnimatePresence>
                  {speechCaption?.visible && speechCaption.type === "speech" && (
                    <motion.div
                      key={`fs-speech-${speechCaptionIdx}`}
                      className="absolute bottom-36 left-1/2 -translate-x-1/2 z-30 pointer-events-none"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.3, ease: "easeOut" }}
                    >
                      <div className="bg-black/70 text-white px-6 py-3 rounded-xl shadow-2xl border border-white/[0.08]">
                        <span style={{ fontSize: "1.5rem", lineHeight: "1.6", fontWeight: 500 }}>
                          {speechCaption.label}
                        </span>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </>
            )}

            {/* ── Normal mode captions ── */}
            {!isFullscreen && (
              <AnimatePresence>
                {activeEnvCaptions.map((cap, slotIdx) => {
                  if (!cap.visible || cap.type === "speech") return null;
                  const pos = CAPTION_POSITIONS[cap._posIdx % CAPTION_POSITIONS.length];
                  return (
                    <motion.div
                      key={`normal-multi-${cap.id}`}
                      className="absolute pointer-events-none"
                      style={{ left: pos.left, top: pos.top }}
                      initial={{ opacity: 0, scale: 0.75, y: 12 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.85, y: -8 }}
                      transition={{ duration: 0.35, ease: "easeOut", delay: slotIdx * 0.06 }}
                    >
                      {emojiOn ? (
                        <span
                          style={{
                            fontSize: "2rem",
                            filter: "drop-shadow(0 0 8px rgba(255,255,255,0.5)) drop-shadow(0 2px 4px rgba(0,0,0,0.8))",
                          }}
                        >
                          {cap.emoji}
                        </span>
                      ) : (
                        <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-black/45 border border-white/15 rounded-xl shadow-lg">
                          <span style={{ fontSize: "0.95rem" }}>{cap.emoji}</span>
                          <span className="text-white" style={{ fontSize: "0.7rem", fontWeight: 500 }}>
                            {cap.label}
                          </span>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            )}

            {/* Normal mode speech caption */}
            {!isFullscreen && (
              <AnimatePresence mode="wait">
                {speechCaption?.visible && speechCaption.type === "speech" && (
                  <motion.div
                    key={`speech-${speechCaptionIdx}`}
                    className="absolute bottom-16 left-1/2 -translate-x-1/2 pointer-events-none"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <div className="bg-black/70 text-white px-4 py-2 rounded-lg shadow-lg border border-white/[0.08]">
                      <span style={{ fontSize: "1rem", lineHeight: "1.5", fontWeight: 500 }}>
                        {speechCaption.label}
                      </span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            )}

            {/* Paused overlay */}
            <AnimatePresence>
              {!playing && (
                <motion.div
                  className="absolute inset-0 flex items-center justify-center bg-black/10"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                >
                  <button
                    onClick={() => setPlaying(true)}
                    className="w-16 h-16 rounded-full bg-white/95 flex items-center justify-center hover:bg-white transition-all shadow-[0_4px_24px_rgba(0,0,0,0.15)] hover:scale-105 active:scale-95"
                  >
                    <Play className="w-6 h-6 text-slate-800 ml-0.5" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ── Control bar ── */}
            <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent ${
              isFullscreen ? 'px-8 pt-20 pb-5 z-50' : 'px-4 pt-12 pb-3'
            }`}>
              {/* Seek bar */}
              <div
                className={`relative ${isFullscreen ? 'h-[6px]' : 'h-1'} bg-white/15 rounded-full mb-3 cursor-pointer group`}
                onClick={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  setTime(Math.round(((e.clientX - r.left) / r.width) * TOTAL));
                }}
              >
                <div className="h-full bg-blue-500 rounded-full relative" style={{ width: `${progress}%` }}>
                  <div className={`absolute right-0 top-1/2 -translate-y-1/2 ${isFullscreen ? 'w-4 h-4' : 'w-2.5 h-2.5'} rounded-full bg-white scale-0 group-hover:scale-100 transition-transform shadow-md`} />
                </div>
                {timeline.filter(item => item.visible).map((it) => {
                  const pct = (parseInt(it.time.slice(0, 2)) * 60 + parseInt(it.time.slice(3))) / TOTAL * 100;
                  return (
                    <div
                      key={it.id}
                      className="absolute top-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-white/40"
                      style={{ left: `${pct}%` }}
                    />
                  );
                })}
              </div>

              {/* Controls row */}
              <div className="flex items-center justify-between">
                <div className={`flex items-center ${isFullscreen ? 'gap-5' : 'gap-2'}`}>
                  <div className={`flex items-center ${isFullscreen ? 'gap-3' : 'gap-1.5'}`}>
                    <button onClick={() => setTime(Math.max(0, time - 10))} className="text-white/50 hover:text-white transition-colors p-1">
                      <SkipBack className={isFullscreen ? 'w-5 h-5' : 'w-3.5 h-3.5'} />
                    </button>
                    <button
                      onClick={() => setPlaying(!playing)}
                      className={`${isFullscreen ? 'w-10 h-10' : 'w-8 h-8'} rounded-full bg-white text-slate-900 flex items-center justify-center transition-all hover:scale-105 active:scale-95 shadow-sm`}
                    >
                      {playing ? <Pause className={isFullscreen ? 'w-5 h-5' : 'w-3.5 h-3.5'} /> : <Play className={`${isFullscreen ? 'w-5 h-5 ml-0.5' : 'w-3.5 h-3.5 ml-0.5'}`} />}
                    </button>
                    <button onClick={() => setTime(Math.min(TOTAL, time + 10))} className="text-white/50 hover:text-white transition-colors p-1">
                      <SkipForward className={isFullscreen ? 'w-5 h-5' : 'w-3.5 h-3.5'} />
                    </button>
                  </div>
                  <button onClick={() => setMuted(!muted)} className="text-white/50 hover:text-white transition-colors p-1">
                    {muted ? <VolumeX className={isFullscreen ? 'w-5 h-5' : 'w-3.5 h-3.5'} /> : <Volume2 className={isFullscreen ? 'w-5 h-5' : 'w-3.5 h-3.5'} />}
                  </button>
                  <span className="text-white/40 tabular-nums" style={{ fontSize: isFullscreen ? '0.82rem' : '0.7rem', fontWeight: 400 }}>
                    {fmt(time)} / 12:34
                  </span>
                </div>
                <div className={`flex items-center ${isFullscreen ? 'gap-2' : 'gap-1'}`}>
                  {/* Emoji & Vibration toggles — fullscreen only */}
                  {isFullscreen && (
                    <>
                      <div className="relative group/emoji">
                        <button
                          onClick={handleEmojiToggle}
                          className={`relative w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                            emojiOn
                              ? "bg-amber-500/20 text-amber-300 hover:bg-amber-500/30"
                              : "text-white/35 hover:text-white/60 hover:bg-white/[0.06]"
                          }`}
                        >
                          <SmileIcon className="w-[18px] h-[18px]" />
                          {emojiOn && (
                            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-amber-400 rounded-full border border-black/50" />
                          )}
                        </button>
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black/80 text-white rounded-md whitespace-nowrap opacity-0 group-hover/emoji:opacity-100 pointer-events-none transition-opacity" style={{ fontSize: "0.7rem" }}>
                          이모티콘 {emojiOn ? "ON" : "OFF"}
                        </div>
                      </div>

                      <div className="relative group/vib">
                        <button
                          onClick={handleVibrationToggle}
                          className={`relative w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                            vibrationOn
                              ? "bg-orange-500/20 text-orange-300 hover:bg-orange-500/30"
                              : "text-white/35 hover:text-white/60 hover:bg-white/[0.06]"
                          }`}
                        >
                          <Vibrate className="w-[18px] h-[18px]" />
                          {vibrationOn && (
                            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-orange-400 rounded-full border border-black/50" />
                          )}
                        </button>
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black/80 text-white rounded-md whitespace-nowrap opacity-0 group-hover/vib:opacity-100 pointer-events-none transition-opacity" style={{ fontSize: "0.7rem" }}>
                          진동 {vibrationOn ? "ON" : "OFF"}
                        </div>
                      </div>

                      <div className="w-px h-4 bg-white/10 mx-1" />
                    </>
                  )}
                  <button className="text-white/40 hover:text-white/70 transition-colors p-1">
                    <Settings className={isFullscreen ? 'w-[18px] h-[18px]' : 'w-3.5 h-3.5'} />
                  </button>
                  <button className="text-white/40 hover:text-white/70 transition-colors p-1" onClick={toggleFullscreen}>
                    {isFullscreen ? <Minimize2 className="w-[18px] h-[18px]" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ── Bottom bar: live caption + toggles ── */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Live caption */}
            <div className="flex-1 bg-white border border-slate-200/60 rounded-xl px-4 py-2.5 flex items-center min-h-[48px] shadow-[0_1px_2px_rgba(0,0,0,0.04)]">
              <AnimatePresence mode="wait">
                {activeEnvCaptions.length > 0 ? (
                  <motion.div
                    key={activeEnvSet.join("-")}
                    className="flex items-center gap-2.5 flex-wrap"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Subtitles className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                    {activeEnvCaptions.map((cap) => (
                      <span
                        key={cap.id}
                        className="inline-flex items-center gap-1.5 px-2 py-[3px] rounded-md bg-slate-50 text-slate-600 border border-slate-100"
                        style={{ fontSize: "0.74rem", fontWeight: 450 }}
                      >
                        <span>{cap.emoji}</span>
                        <span>{cap.label}</span>
                      </span>
                    ))}
                    {playing && (
                      <span className="flex gap-[2px] items-end h-3 ml-1">
                        {[0, 1, 2].map((i) => (
                          <motion.span
                            key={i}
                            className="block w-[3px] bg-blue-400 rounded-full"
                            animate={{ height: ["3px", "10px", "3px"] }}
                            transition={{ duration: 0.7, delay: i * 0.13, repeat: Infinity }}
                          />
                        ))}
                      </span>
                    )}
                  </motion.div>
                ) : (
                  <div className="flex items-center gap-2 text-slate-300">
                    <Subtitles className="w-3.5 h-3.5" />
                    <span style={{ fontSize: "0.74rem" }}>자막이 표시되지 않습니다</span>
                  </div>
                )}
              </AnimatePresence>
            </div>

            {/* Emoji toggle */}
            <button
              onClick={handleEmojiToggle}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl border transition-all shrink-0 ${
                emojiOn 
                  ? "bg-amber-50 border-amber-200/60 text-amber-700" 
                  : "bg-white border-slate-200/60 text-slate-400 hover:text-slate-500"
              } shadow-[0_1px_2px_rgba(0,0,0,0.04)]`}
            >
              <SmileIcon className="w-4 h-4" />
              <span style={{ fontSize: "0.74rem", fontWeight: 500 }}>이모티콘</span>
              <div className={`relative w-8 h-[18px] rounded-full transition-colors ${emojiOn ? "bg-amber-400" : "bg-slate-200"}`}>
                <span className={`absolute top-[2px] w-[14px] h-[14px] rounded-full bg-white shadow-sm transition-transform ${emojiOn ? "translate-x-[16px]" : "translate-x-[2px]"}`} />
              </div>
            </button>

            {/* Vibration toggle */}
            <button
              onClick={handleVibrationToggle}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl border transition-all shrink-0 ${
                vibrationOn 
                  ? "bg-orange-50 border-orange-200/60 text-orange-700" 
                  : "bg-white border-slate-200/60 text-slate-400 hover:text-slate-500"
              } shadow-[0_1px_2px_rgba(0,0,0,0.04)]`}
            >
              <Vibrate className="w-4 h-4" />
              <span style={{ fontSize: "0.74rem", fontWeight: 500 }}>진동</span>
              <div className={`relative w-8 h-[18px] rounded-full transition-colors ${vibrationOn ? "bg-orange-400" : "bg-slate-200"}`}>
                <span className={`absolute top-[2px] w-[14px] h-[14px] rounded-full bg-white shadow-sm transition-transform ${vibrationOn ? "translate-x-[16px]" : "translate-x-[2px]"}`} />
              </div>
            </button>
          </div>
        </div>

        {/* ── Timeline Panel ── */}
        <AnimatePresence initial={false}>
          {panelOpen ? (
            <motion.aside
              key="open"
              className="w-[284px] bg-white border-l border-slate-200/60 flex flex-col shrink-0"
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 284, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.22 }}
            >
              {/* Header */}
              <div className="flex items-center justify-between px-4 h-[54px] border-b border-slate-100/80 shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
                  <span className="text-slate-700" style={{ fontSize: "0.82rem", fontWeight: 600 }}>인식된 소리</span>
                  <span className="bg-slate-100 text-slate-400 rounded-md px-1.5 py-[1px]" style={{ fontSize: "0.6rem", fontWeight: 500 }}>
                    {visibleCount}/{timeline.length}
                  </span>
                </div>
                <button
                  onClick={() => setPanelOpen(false)}
                  className="w-6 h-6 flex items-center justify-center rounded-md hover:bg-slate-100 text-slate-400 transition-colors"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* List */}
              <div className="flex-1 overflow-y-auto py-1.5 px-2">
                {timeline.map((item, i) => {
                  const isActive = i === envCaptionIdx && item.visible;
                  return (
                    <div
                      key={item.id}
                      className={`flex items-center gap-2 w-full px-2.5 py-[9px] rounded-lg mb-0.5 transition-all cursor-default ${
                        isActive ? "bg-blue-50/80 ring-1 ring-blue-200/60" : "hover:bg-slate-50/80"
                      } ${!item.visible ? "opacity-30" : ""}`}
                    >
                      {/* Toggle visibility */}
                      <button
                        onClick={() => toggleVisibility(item.id)}
                        className={`shrink-0 transition-colors ${item.visible ? "text-blue-500 hover:text-blue-600" : "text-slate-300 hover:text-slate-400"}`}
                      >
                        {item.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => {
                          if (item.visible) {
                            setEnvCaptionIdx(i);
                            setTime(parseInt(item.time.slice(0, 2)) * 60 + parseInt(item.time.slice(3)));
                          }
                        }}
                        disabled={!item.visible}
                        className="flex items-center gap-2 flex-1 text-left min-w-0"
                      >
                        <span
                          className={`shrink-0 tabular-nums ${isActive ? "text-blue-500" : "text-slate-300"}`}
                          style={{ fontSize: "0.65rem", fontWeight: 500, minWidth: "2.4rem", fontFamily: "'Inter', monospace" }}
                        >
                          {item.time}
                        </span>
                        <span style={{ fontSize: "0.88rem" }}>{item.emoji}</span>
                        <span
                          className={`truncate ${isActive ? "text-blue-700" : "text-slate-600"}`}
                          style={{ fontSize: "0.76rem", fontWeight: isActive ? 500 : 400 }}
                        >
                          {item.label}
                        </span>
                        {isActive && playing && (
                          <span className="flex gap-[2px] ml-auto shrink-0 items-end h-3">
                            {[0, 1, 2].map((j) => (
                              <motion.span
                                key={j}
                                className="block w-[3px] bg-blue-400 rounded-full"
                                animate={{ height: ["3px", "9px", "3px"] }}
                                transition={{ duration: 0.65, delay: j * 0.11, repeat: Infinity }}
                              />
                            ))}
                          </span>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Footer */}
              <div className="p-3 border-t border-slate-100/80">
                <button
                  onClick={() => navigate("/caption")}
                  className="w-full flex items-center justify-center gap-1.5 py-2 bg-blue-50 hover:bg-blue-100/80 text-blue-600 rounded-lg transition-colors"
                  style={{ fontSize: "0.76rem", fontWeight: 500 }}
                >
                  새 영상 변환하기
                </button>
              </div>
            </motion.aside>
          ) : (
            <motion.div
              key="closed"
              className="flex items-start pt-4 border-l border-slate-200/60 bg-white shrink-0"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            >
              <button
                onClick={() => setPanelOpen(true)}
                className="flex flex-col items-center gap-2 px-2 py-3 text-slate-300 hover:text-blue-500 hover:bg-blue-50/50 rounded-l-lg transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span style={{ fontSize: "0.6rem", writingMode: "vertical-lr", letterSpacing: "0.05em", fontWeight: 500 }}>
                  인식된 소리
                </span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
