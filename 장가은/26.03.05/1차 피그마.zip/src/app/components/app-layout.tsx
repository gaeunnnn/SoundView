import { useState, useEffect, useRef, useCallback } from "react";
import { createPortal } from "react-dom";
import { Outlet, useNavigate, useLocation } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Subtitles,
  HardDrive,
  Users,
  Bell,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  FolderPlus,
  Search,
  LogOut,
  HelpCircle,
  Settings,
  Download,
  X,
  Plus,
  Pencil,
  Check,
  UserPlus,
  Trash2,
  Copy,
  Hash,
} from "lucide-react";

export type CustomDrive = {
  id: string;
  name: string;
  type: "shared";
  members: string[]; // participant names (always includes "박민준")
};

export type LayoutContext = {
  activeDriveId: string;
  setActiveDriveId: (id: string) => void;
  customDrives: CustomDrive[];
  driveRenames: Record<string, string>;
};

export const DRIVES = [
  { id: "my", name: "내 드라이브", type: "my" as const },
  { id: "jieun", name: "김지은", type: "shared" as const },
  { id: "junho", name: "박준호", type: "shared" as const },
];

// ── Helper: load / save custom drives ────────────────────────────────────────
function loadCustomDrives(): CustomDrive[] {
  try {
    const json = localStorage.getItem("customDrives");
    return json ? JSON.parse(json) : [];
  } catch { return []; }
}
function saveCustomDrives(drives: CustomDrive[]) {
  localStorage.setItem("customDrives", JSON.stringify(drives));
}

function loadDriveRenames(): Record<string, string> {
  try {
    const json = localStorage.getItem("driveRenames");
    return json ? JSON.parse(json) : {};
  } catch { return {}; }
}
function saveDriveRenames(renames: Record<string, string>) {
  localStorage.setItem("driveRenames", JSON.stringify(renames));
}

function loadLeftDriveIds(): string[] {
  try {
    const json = localStorage.getItem("leftDriveIds");
    return json ? JSON.parse(json) : [];
  } catch { return []; }
}
function saveLeftDriveIds(ids: string[]) {
  localStorage.setItem("leftDriveIds", JSON.stringify(ids));
}

// ── Helper: generate & persist unique 6-char user code ───────────────────────
function generateUserCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function getUserCode(): string {
  const stored = localStorage.getItem("userCode");
  if (stored && stored.length === 6) return stored;
  const code = generateUserCode();
  localStorage.setItem("userCode", code);
  return code;
}

// ── Predefined color pairs for avatars ───────────────────────────────────────
const AVATAR_COLORS = [
  "from-amber-400 to-orange-400",
  "from-cyan-400 to-blue-400",
  "from-pink-400 to-rose-400",
  "from-lime-400 to-emerald-400",
  "from-violet-400 to-purple-400",
  "from-teal-400 to-cyan-400",
];

const NAV_ITEMS = [
  { path: "/dashboard", label: "대시보드", icon: Subtitles },
  { path: "/caption", label: "AI 자막 생성", icon: HardDrive },
  { path: "/result", label: "결과 플레이어", icon: Users },
];

export function AppLayout() {
  const [activeDriveId, setActiveDriveId] = useState("my");
  const [profileOpen, setProfileOpen] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [customDrives, setCustomDrives] = useState<CustomDrive[]>(loadCustomDrives);
  const [driveRenames, setDriveRenames] = useState<Record<string, string>>(loadDriveRenames);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showFindFriendModal, setShowFindFriendModal] = useState(false);
  const [editingDriveId, setEditingDriveId] = useState<string | null>(null);
  const [editDriveName, setEditDriveName] = useState("");
  const [driveSettingsOpen, setDriveSettingsOpen] = useState<string | null>(null);
  const [driveSettingsPos, setDriveSettingsPos] = useState<{ top: number; left: number } | null>(null);
  const [driveSettingsData, setDriveSettingsData] = useState<{ id: string; name: string } | null>(null);
  const [leaveDriveTarget, setLeaveDriveTarget] = useState<{ id: string; name: string } | null>(null);
  const [leftDriveIds, setLeftDriveIds] = useState<string[]>(loadLeftDriveIds);
  const editInputRef = useRef<HTMLInputElement>(null);
  const driveSettingsRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const location = useLocation();

  // Focus rename input
  useEffect(() => {
    if (editingDriveId && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [editingDriveId]);

  // Close drive settings dropdown on outside click
  useEffect(() => {
    if (!driveSettingsOpen) return;
    const handleClick = (e: MouseEvent) => {
      if (driveSettingsRef.current && !driveSettingsRef.current.contains(e.target as Node)) {
        setDriveSettingsOpen(null);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [driveSettingsOpen]);

  const handleCreateDrive = (members: string[]) => {
    const id = `custom-${Date.now()}`;
    // If only 2 members (me + one other), show just the other person's name
    const otherMembers = members.filter(m => m !== "박민준");
    const name = otherMembers.length === 1 ? otherMembers[0] : members.join(", ");
    const drive: CustomDrive = { id, name, type: "shared", members };
    const updated = [...customDrives, drive];
    setCustomDrives(updated);
    saveCustomDrives(updated);
    setShowCreateModal(false);
    setActiveDriveId(id);
    navigate("/dashboard");
  };

  const handleRenameDriveSave = (driveId: string) => {
    const trimmed = editDriveName.trim();
    if (trimmed) {
      // Check if it's a custom drive
      const isCustom = customDrives.some(d => d.id === driveId);
      if (isCustom) {
        const updated = customDrives.map(d => d.id === driveId ? { ...d, name: trimmed } : d);
        setCustomDrives(updated);
        saveCustomDrives(updated);
      } else {
        // Built-in shared drive — persist rename separately
        const updated = { ...driveRenames, [driveId]: trimmed };
        setDriveRenames(updated);
        saveDriveRenames(updated);
      }
    }
    setEditingDriveId(null);
  };

  // Helper to get display name for any drive (built-in or custom)
  const getDriveName = (drive: { id: string; name: string }) => {
    return driveRenames[drive.id] || drive.name;
  };

  const handleCopy = (text: string, field: string) => {
    try {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1500);
    } catch {
      // silent fail
    }
  };

  const [userCode] = useState(() => getUserCode());

  // ── Sidebar collapse & resize ──
  const SIDEBAR_MIN = 180;
  const SIDEBAR_MAX = 400;
  const SIDEBAR_DEFAULT = 220;
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [sidebarWidth, setSidebarWidth] = useState(SIDEBAR_DEFAULT);
  const isResizing = useRef(false);
  const sidebarRef = useRef<HTMLDivElement>(null);

  const handleResizeStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isResizing.current = true;
    const startX = e.clientX;
    const startWidth = sidebarWidth;

    const onMouseMove = (ev: MouseEvent) => {
      if (!isResizing.current) return;
      const newWidth = Math.min(SIDEBAR_MAX, Math.max(SIDEBAR_MIN, startWidth + (ev.clientX - startX)));
      setSidebarWidth(newWidth);
    };

    const onMouseUp = () => {
      isResizing.current = false;
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };

    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  }, [sidebarWidth]);

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* ── Top Navbar ── */}
      <header className="flex items-center justify-between h-[52px] px-5 bg-white border-b border-slate-100 shrink-0 z-20">
        {/* Logo */}
        <div
          className="flex items-center gap-2 cursor-pointer select-none"
          onClick={() => navigate("/")}
        >
          <div className="w-6 h-6 rounded-md bg-blue-600 flex items-center justify-center">
            <Subtitles className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-slate-800" style={{ fontSize: "0.9rem" }}>
            SoundSee
          </span>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-0.5">
          <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-600">
            <HelpCircle className="w-4 h-4" />
          </button>
          <button className="relative w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-600">
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-blue-500 rounded-full" />
          </button>

          {/* Profile */}
          <div className="relative ml-1">
            <button
              onClick={() => setProfileOpen(!profileOpen)}
              className="flex items-center gap-2 cursor-pointer hover:bg-slate-100 rounded-lg px-2 py-1.5 transition-colors select-none"
            >
              <div
                className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center text-white shrink-0"
                style={{ fontSize: "0.6rem" }}
              >
                박
              </div>
              <span className="text-slate-700" style={{ fontSize: "0.82rem" }}>
                박민준
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {profileOpen && (
              <div className="absolute right-0 top-full mt-1 w-56 bg-white border border-slate-200 rounded-xl shadow-lg shadow-slate-100 py-1 z-50">
                <div className="px-3.5 py-2.5 border-b border-slate-100">
                  <p className="text-slate-800" style={{ fontSize: "0.82rem" }}>
                    박민준
                  </p>

                  {/* Email row */}
                  <div className="flex items-center gap-1 mt-1 group/email">
                    <p className="text-slate-400 flex-1 truncate" style={{ fontSize: "0.72rem" }}>
                      minj@example.com
                    </p>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleCopy("minj@example.com", "email"); }}
                      className={`w-5 h-5 flex items-center justify-center rounded transition-all shrink-0 ${
                        copiedField === "email"
                          ? "text-emerald-500 bg-emerald-50"
                          : "text-slate-300 hover:text-blue-500 hover:bg-blue-50"
                      }`}
                      title="이메일 복사"
                    >
                      {copiedField === "email" ? <Check className="w-2.5 h-2.5" /> : <Copy className="w-2.5 h-2.5" />}
                    </button>
                  </div>

                  {/* User code row */}
                  <div className="flex items-center gap-1 mt-1.5 group/code">
                    <div className="flex items-center gap-1 flex-1 min-w-0">
                      <Hash className="w-2.5 h-2.5 text-slate-300 shrink-0" />
                      <span className="text-blue-500 tracking-wide" style={{ fontSize: "0.7rem", fontFamily: "monospace" }}>
                        {userCode}
                      </span>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleCopy(userCode, "code"); }}
                      className={`w-5 h-5 flex items-center justify-center rounded transition-all shrink-0 ${
                        copiedField === "code"
                          ? "text-emerald-500 bg-emerald-50"
                          : "text-slate-300 hover:text-blue-500 hover:bg-blue-50"
                      }`}
                      title="코드 복사"
                    >
                      {copiedField === "code" ? <Check className="w-2.5 h-2.5" /> : <Copy className="w-2.5 h-2.5" />}
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => setProfileOpen(false)}
                  className="flex items-center gap-2 w-full px-3.5 py-2 text-slate-600 hover:bg-slate-50 transition-colors"
                  style={{ fontSize: "0.82rem" }}
                >
                  <Settings className="w-3.5 h-3.5 text-slate-400" />
                  설정
                </button>
                <button
                  onClick={() => { setProfileOpen(false); navigate("/"); }}
                  className="flex items-center gap-2 w-full px-3.5 py-2 text-slate-600 hover:bg-slate-50 transition-colors"
                  style={{ fontSize: "0.82rem" }}
                >
                  <LogOut className="w-3.5 h-3.5 text-slate-400" />
                  로그아웃
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* ── Left Sidebar ── */}
        <aside
          className="bg-white border-r border-slate-100 flex flex-col shrink-0 relative group/sidebar"
          ref={sidebarRef}
          style={{ width: sidebarCollapsed ? 48 : sidebarWidth, transition: isResizing.current ? "none" : "width 0.2s ease" }}
        >
          {/* Collapse / Expand toggle — vertically centered on sidebar edge */}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="absolute top-1/2 -translate-y-1/2 -right-3 z-20 w-6 h-6 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-400 hover:text-blue-500 hover:border-blue-300 hover:bg-blue-50 transition-all shadow-sm opacity-0 group-hover/sidebar:opacity-100"
          >
            {sidebarCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>

          {sidebarCollapsed ? (
            /* Collapsed: icon-only view */
            <div className="flex flex-col items-center py-4 gap-1 flex-1">
              <button
                onClick={() => { setActiveDriveId("my"); navigate("/dashboard"); }}
                className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                  activeDriveId === "my" ? "bg-blue-50 text-blue-600" : "text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                }`}
                title="내 드라이브"
              >
                <HardDrive className="w-4 h-4" />
              </button>
              <div className="w-6 border-t border-slate-100 my-1" />
              {DRIVES.filter(d => d.type === "shared" && !leftDriveIds.includes(d.id)).map((drive) => (
                <button
                  key={drive.id}
                  onClick={() => { setActiveDriveId(drive.id); navigate("/dashboard"); }}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                    activeDriveId === drive.id ? "bg-emerald-50 text-emerald-600" : "text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                  }`}
                  title={getDriveName(drive)}
                >
                  <div
                    className="w-5 h-5 rounded-full bg-gradient-to-br from-violet-400 to-pink-400 flex items-center justify-center text-white"
                    style={{ fontSize: "0.45rem" }}
                  >
                    {drive.id === "jieun" ? "지" : "준"}
                  </div>
                </button>
              ))}
              {customDrives.map((drive, idx) => (
                <button
                  key={drive.id}
                  onClick={() => { setActiveDriveId(drive.id); navigate("/dashboard"); }}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                    activeDriveId === drive.id ? "bg-emerald-50 text-emerald-600" : "text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                  }`}
                  title={drive.name}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-gradient-to-br ${AVATAR_COLORS[idx % AVATAR_COLORS.length]} flex items-center justify-center text-white`}
                    style={{ fontSize: "0.4rem" }}
                  >
                    {drive.members.length}
                  </div>
                </button>
              ))}
              <div className="flex-1" />
              <button
                onClick={() => { setSidebarCollapsed(false); setShowFindFriendModal(true); }}
                className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-all"
                title="친구 찾기"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>
          ) : (
            /* Expanded sidebar content */
            <>
              <div className="flex-1 overflow-y-auto py-4 px-2">
                {/* 내 드라이브 Section */}
                <div className="mb-5">
                  <p
                    className="text-slate-400 px-2.5 mb-1.5 uppercase"
                    style={{ fontSize: "0.6rem", letterSpacing: "0.08em" }}
                  >
                    내 드라이브
                  </p>
                  {DRIVES.filter(d => d.type === "my").map((drive) => {
                    const isActive = activeDriveId === drive.id;
                    return (
                      <button
                        key={drive.id}
                        onClick={() => { setActiveDriveId(drive.id); navigate("/dashboard"); }}
                        className={`flex items-center gap-2 w-full px-2.5 py-1.5 rounded-lg mb-px text-left transition-all ${
                          isActive
                            ? "bg-blue-50 text-blue-700"
                            : "text-slate-600 hover:bg-slate-50 hover:text-slate-800"
                        }`}
                        style={{ fontSize: "0.82rem" }}
                      >
                        <HardDrive className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-blue-500" : "text-slate-400"}`} />
                        <span className="truncate flex-1">{drive.name}</span>
                      </button>
                    );
                  })}
                  <button
                    onClick={() => setShowCreateModal(true)}
                    className="flex items-center justify-center gap-1.5 w-full mt-2 py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                    style={{ fontSize: "0.78rem" }}
                  >
                    <FolderPlus className="w-3 h-3" />
                    드라이브 만들기
                  </button>
                </div>

                {/* 공유 드라이브 Section */}
                <div className="pt-4 border-t border-slate-100">
                  <p
                    className="text-slate-400 px-2.5 mb-1.5 uppercase"
                    style={{ fontSize: "0.6rem", letterSpacing: "0.08em" }}
                  >
                    공유 드라이브
                  </p>
                  {/* Built-in shared drives */}
                  {DRIVES.filter(d => d.type === "shared" && !leftDriveIds.includes(d.id)).map((drive) => {
                    const isActive = activeDriveId === drive.id;
                    const isEditing = editingDriveId === drive.id;
                    const displayName = getDriveName(drive);

                    return (
                      <div key={drive.id} className="group relative">
                        {isEditing ? (
                          <div className="flex items-center gap-1 px-1.5 py-1 mb-px">
                            <input
                              ref={editInputRef}
                              type="text"
                              value={editDriveName}
                              onChange={e => setEditDriveName(e.target.value)}
                              onBlur={() => handleRenameDriveSave(drive.id)}
                              onKeyDown={e => {
                                if (e.key === "Enter") { e.preventDefault(); handleRenameDriveSave(drive.id); }
                                if (e.key === "Escape") setEditingDriveId(null);
                              }}
                              className="flex-1 min-w-0 bg-slate-50 border border-blue-300 rounded-md px-2 py-1 outline-none ring-2 ring-blue-100 text-slate-800"
                              style={{ fontSize: "0.78rem" }}
                            />
                            <button
                              onClick={() => handleRenameDriveSave(drive.id)}
                              className="w-6 h-6 flex items-center justify-center rounded-md bg-blue-600 text-white hover:bg-blue-700 shrink-0"
                            >
                              <Check className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <div
                            role="button"
                            tabIndex={0}
                            onClick={() => { setActiveDriveId(drive.id); navigate("/dashboard"); }}
                            className={`flex items-center gap-2 w-full px-2.5 py-1.5 rounded-lg mb-px text-left transition-all cursor-pointer ${
                              isActive
                                ? "bg-emerald-50 text-emerald-700"
                                : "text-slate-600 hover:bg-slate-50 hover:text-slate-800"
                            }`}
                            style={{ fontSize: "0.82rem" }}
                          >
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <Users className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-emerald-500" : "text-slate-400"}`} />
                              <span className="truncate flex-1">{displayName}</span>
                            </div>
                            {/* Settings button */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const rect = e.currentTarget.getBoundingClientRect();
                                setDriveSettingsPos({ top: rect.bottom + 4, left: rect.left });
                                setDriveSettingsData({ id: drive.id, name: displayName });
                                setDriveSettingsOpen(driveSettingsOpen === drive.id ? null : drive.id);
                              }}
                              className="w-5 h-5 flex items-center justify-center rounded text-slate-400 hover:text-blue-500 hover:bg-blue-50 transition-all shrink-0"
                            >
                              <Settings className="w-2.5 h-2.5" />
                            </button>
                            {/* Friend avatar */}
                            <div
                              className="w-5 h-5 rounded-full bg-gradient-to-br from-violet-400 to-pink-400 flex items-center justify-center text-white shrink-0"
                              style={{ fontSize: "0.5rem" }}
                            >
                              {drive.id === "jieun" ? "지" : "준"}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}

                  {/* Custom drives */}
                  {customDrives.map((drive, idx) => {
                    const isActive = activeDriveId === drive.id;
                    const isEditing = editingDriveId === drive.id;
                    const colorClass = AVATAR_COLORS[idx % AVATAR_COLORS.length];
                    const memberCount = drive.members.length;

                    return (
                      <div key={drive.id} className="group relative">
                        {isEditing ? (
                          <div className="flex items-center gap-1 px-1.5 py-1 mb-px">
                            <input
                              ref={editInputRef}
                              type="text"
                              value={editDriveName}
                              onChange={e => setEditDriveName(e.target.value)}
                              onBlur={() => handleRenameDriveSave(drive.id)}
                              onKeyDown={e => {
                                if (e.key === "Enter") { e.preventDefault(); handleRenameDriveSave(drive.id); }
                                if (e.key === "Escape") setEditingDriveId(null);
                              }}
                              className="flex-1 min-w-0 bg-slate-50 border border-blue-300 rounded-md px-2 py-1 outline-none ring-2 ring-blue-100 text-slate-800"
                              style={{ fontSize: "0.78rem" }}
                            />
                            <button
                              onClick={() => handleRenameDriveSave(drive.id)}
                              className="w-6 h-6 flex items-center justify-center rounded-md bg-blue-600 text-white hover:bg-blue-700 shrink-0"
                            >
                              <Check className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <div
                            role="button"
                            tabIndex={0}
                            onClick={() => { setActiveDriveId(drive.id); navigate("/dashboard"); }}
                            className={`flex items-center gap-2 w-full px-2.5 py-1.5 rounded-lg mb-px text-left transition-all cursor-pointer ${
                              isActive
                                ? "bg-emerald-50 text-emerald-700"
                                : "text-slate-600 hover:bg-slate-50 hover:text-slate-800"
                            }`}
                            style={{ fontSize: "0.82rem" }}
                          >
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <Users className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-emerald-500" : "text-slate-400"}`} />
                              <span className="truncate flex-1">{drive.name}</span>
                            </div>
                            {/* Settings button */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const rect = e.currentTarget.getBoundingClientRect();
                                setDriveSettingsPos({ top: rect.bottom + 4, left: rect.left });
                                setDriveSettingsData({ id: drive.id, name: drive.name });
                                setDriveSettingsOpen(driveSettingsOpen === drive.id ? null : drive.id);
                              }}
                              className="w-5 h-5 flex items-center justify-center rounded text-slate-400 hover:text-blue-500 hover:bg-blue-50 transition-all shrink-0"
                            >
                              <Settings className="w-2.5 h-2.5" />
                            </button>
                            {/* Member count badge */}
                            <div
                              className={`w-5 h-5 rounded-full bg-gradient-to-br ${colorClass} flex items-center justify-center text-white shrink-0`}
                              style={{ fontSize: "0.45rem" }}
                            >
                              {memberCount}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Footer */}
              <div className="p-3 border-t border-slate-100">
                <button
                  onClick={() => setShowFindFriendModal(true)}
                  className="flex items-center justify-center gap-1.5 w-full py-2 px-3 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  style={{ fontSize: "0.78rem" }}
                >
                  <Search className="w-3 h-3 text-slate-400" />
                  친구 찾기
                </button>
              </div>
            </>
          )}

          {/* Resize handle — only when expanded */}
          {!sidebarCollapsed && (
            <div
              className="absolute top-0 -right-1 bottom-0 w-2 cursor-col-resize z-10 group/resize"
              onMouseDown={handleResizeStart}
            >
              <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-px bg-transparent group-hover/resize:bg-blue-400 transition-colors" />
            </div>
          )}
        </aside>

        {/* ── Main content ── */}
        <main className="flex-1 overflow-y-auto bg-slate-50/50">
          <Outlet context={{ activeDriveId, setActiveDriveId, customDrives, driveRenames } as LayoutContext} />
        </main>
      </div>

      {/* ── Create Drive Modal ── */}
      <AnimatePresence>
        {showCreateModal && (
          <CreateDriveModal
            onClose={() => setShowCreateModal(false)}
            onCreate={handleCreateDrive}
          />
        )}
        {showFindFriendModal && (
          <FindFriendModal onClose={() => setShowFindFriendModal(false)} />
        )}
        {leaveDriveTarget && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            <div className="absolute inset-0 bg-black/40" onClick={() => setLeaveDriveTarget(null)} />
            <motion.div
              className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-200 w-[360px] overflow-hidden"
              initial={{ scale: 0.92, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 5 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
            >
              <div className="px-6 pt-6 pb-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center shrink-0">
                    <LogOut className="w-5 h-5 text-red-500" />
                  </div>
                  <h3 className="text-slate-900" style={{ fontSize: "1rem" }}>
                    드라이브 나가기
                  </h3>
                </div>
                <p className="text-slate-500 ml-[52px]" style={{ fontSize: "0.85rem", lineHeight: "1.5" }}>
                  정말 이 드라이브에서 나가시겠습니까?
                </p>
                <p className="text-slate-400 ml-[52px] mt-1 truncate" style={{ fontSize: "0.78rem" }}>
                  "{leaveDriveTarget.name}"
                </p>
                <p className="text-slate-300 ml-[52px] mt-2" style={{ fontSize: "0.72rem" }}>
                  나가면 드라이브의 영상에 더 이상 접근할 수 없습니다.
                </p>
              </div>
              <div className="flex items-center gap-2 px-6 pb-5 pt-2 justify-end border-t border-slate-100">
                <button
                  onClick={() => setLeaveDriveTarget(null)}
                  className="px-4 py-2 mt-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  style={{ fontSize: "0.82rem" }}
                >
                  취소
                </button>
                <button
                  onClick={() => {
                    if (!leaveDriveTarget) return;
                    const targetId = leaveDriveTarget.id;
                    // Check if it's a custom drive
                    const isCustom = customDrives.some(d => d.id === targetId);
                    if (isCustom) {
                      const updated = customDrives.filter(d => d.id !== targetId);
                      setCustomDrives(updated);
                      saveCustomDrives(updated);
                    } else {
                      // Built-in drive — add to leftDriveIds
                      const updated = [...leftDriveIds, targetId];
                      setLeftDriveIds(updated);
                      saveLeftDriveIds(updated);
                    }
                    // Navigate to my drive if currently viewing the left drive
                    if (activeDriveId === targetId) {
                      setActiveDriveId("my");
                      navigate("/dashboard");
                    }
                    setLeaveDriveTarget(null);
                  }}
                  className="px-4 py-2 mt-2 rounded-lg bg-red-500 hover:bg-red-600 text-white transition-colors shadow-sm"
                  style={{ fontSize: "0.82rem" }}
                >
                  나가기
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Drive Settings Dropdown (Portal) ── */}
      {driveSettingsOpen && driveSettingsPos && driveSettingsData && createPortal(
        <div
          ref={driveSettingsRef}
          className="fixed w-28 bg-white border border-slate-200 rounded-xl py-1"
          style={{
            top: driveSettingsPos.top,
            left: driveSettingsPos.left,
            zIndex: 99999,
            boxShadow: "0 8px 30px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06)",
          }}
        >
          <button
            onClick={() => {
              setDriveSettingsOpen(null);
              setEditDriveName(driveSettingsData.name);
              setEditingDriveId(driveSettingsData.id);
            }}
            className="flex items-center gap-2 w-full text-left px-3 py-1.5 hover:bg-slate-50 transition-colors text-slate-700"
            style={{ fontSize: "0.78rem" }}
          >
            <Pencil className="w-3 h-3 text-slate-400" />
            이름 수정
          </button>
          <button
            onClick={() => {
              setDriveSettingsOpen(null);
              setLeaveDriveTarget({ id: driveSettingsData.id, name: driveSettingsData.name });
            }}
            className="flex items-center gap-2 w-full text-left px-3 py-1.5 hover:bg-red-50 transition-colors text-red-500"
            style={{ fontSize: "0.78rem" }}
          >
            <LogOut className="w-3 h-3" />
            나가기
          </button>
        </div>,
        document.body
      )}
    </div>
  );
}

// ── Create Drive Modal Component ─────────────────────────────────────────────
function CreateDriveModal({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (members: string[]) => void;
}) {
  // "나(박민준)" is always included
  const [participants, setParticipants] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const allMembers = ["박민준", ...participants];
  const canCreate = participants.length >= 1; // 나 포함 최소 2명

  const handleAddParticipant = () => {
    const trimmed = inputValue.trim();
    if (!trimmed) return;
    if (trimmed === "박민준") return;
    if (participants.includes(trimmed)) return;
    setParticipants([...participants, trimmed]);
    setInputValue("");
    inputRef.current?.focus();
  };

  const handleRemoveParticipant = (name: string) => {
    setParticipants(participants.filter(p => p !== name));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddParticipant();
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    >
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <motion.div
        className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-200 w-[420px] overflow-hidden"
        initial={{ scale: 0.92, opacity: 0, y: 10 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 5 }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
              <FolderPlus className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <h3 className="text-slate-900" style={{ fontSize: "1rem" }}>
                드라이브 만들기
              </h3>
              <p className="text-slate-400 mt-0.5" style={{ fontSize: "0.72rem" }}>
                참여자를 추가하여 드라이브를 만드세요
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Participants */}
        <div className="px-6 pb-4">
          <p className="text-slate-500 mb-3" style={{ fontSize: "0.78rem" }}>
            참여자 추가
          </p>

          {/* Input */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex-1 flex items-center gap-2 border border-slate-200 rounded-xl px-3 py-2 focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-100 transition-all">
              <UserPlus className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="이름을 입력하세요"
                className="flex-1 outline-none text-slate-700 placeholder:text-slate-300 bg-transparent"
                style={{ fontSize: "0.82rem" }}
              />
            </div>
            <button
              onClick={handleAddParticipant}
              disabled={!inputValue.trim()}
              className={`px-3 py-2 rounded-xl transition-colors shrink-0 ${
                inputValue.trim()
                  ? "bg-blue-600 text-white hover:bg-blue-700"
                  : "bg-slate-100 text-slate-400 cursor-not-allowed"
              }`}
              style={{ fontSize: "0.78rem" }}
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Members list */}
          <div className="flex flex-col gap-1.5 max-h-[200px] overflow-y-auto">
            {/* 나(박민준) - always present */}
            <div className="flex items-center gap-3 px-3 py-2 bg-blue-50/60 border border-blue-100 rounded-xl">
              <div
                className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center text-white shrink-0"
                style={{ fontSize: "0.55rem" }}
              >
                박
              </div>
              <span className="text-slate-700 flex-1" style={{ fontSize: "0.82rem" }}>
                박민준 <span className="text-blue-500" style={{ fontSize: "0.7rem" }}>(나)</span>
              </span>
            </div>

            {/* Added participants */}
            <AnimatePresence>
              {participants.map((name, idx) => (
                <motion.div
                  key={name}
                  className="flex items-center gap-3 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl group/member"
                  initial={{ opacity: 0, y: -6, height: 0 }}
                  animate={{ opacity: 1, y: 0, height: "auto" }}
                  exit={{ opacity: 0, x: 20, height: 0 }}
                  transition={{ duration: 0.15 }}
                >
                  <div
                    className={`w-7 h-7 rounded-full bg-gradient-to-br ${AVATAR_COLORS[idx % AVATAR_COLORS.length]} flex items-center justify-center text-white shrink-0`}
                    style={{ fontSize: "0.55rem" }}
                  >
                    {name.charAt(0)}
                  </div>
                  <span className="text-slate-700 flex-1" style={{ fontSize: "0.82rem" }}>
                    {name}
                  </span>
                  <button
                    onClick={() => handleRemoveParticipant(name)}
                    className="w-5 h-5 flex items-center justify-center rounded text-slate-300 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover/member:opacity-100 transition-all shrink-0"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Member count indicator */}
          <div className="flex items-center gap-2 mt-3">
            <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${canCreate ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`} style={{ fontSize: "0.7rem" }}>
              <Users className="w-3 h-3" />
              {allMembers.length}명 참여
            </div>
            {!canCreate && (
              <span className="text-amber-500" style={{ fontSize: "0.7rem" }}>
                {1 - participants.length}명 더 추가하세요
              </span>
            )}
          </div>

          {/* Preview name */}
          {canCreate && (
            <div className="mt-3 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl">
              <p className="text-slate-400" style={{ fontSize: "0.68rem" }}>드라이브 이름 (나중에 수정 가능)</p>
              <p className="text-slate-700 mt-0.5 truncate" style={{ fontSize: "0.8rem" }}>
                {participants.length === 1 ? participants[0] : allMembers.join(", ")}
              </p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 px-6 pb-5 pt-2 justify-end border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 mt-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            style={{ fontSize: "0.82rem" }}
          >
            취소
          </button>
          <button
            onClick={() => canCreate && onCreate(allMembers)}
            disabled={!canCreate}
            className={`px-4 py-2 mt-2 rounded-lg transition-colors shadow-sm ${
              canCreate
                ? "bg-blue-600 hover:bg-blue-700 text-white"
                : "bg-slate-100 text-slate-400 cursor-not-allowed"
            }`}
            style={{ fontSize: "0.82rem" }}
          >
            만들기
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ── Mock user directory (searchable by code or email) ────────────────────────
type MockUser = {
  name: string;
  email: string;
  code: string;
  avatar: string;
  gradient: string;
};

const MOCK_USERS: MockUser[] = [
  { name: "이서연", email: "seoyeon@example.com", code: "WX2SDC", avatar: "이", gradient: "from-rose-400 to-pink-500" },
  { name: "김지은", email: "jieun@example.com", code: "JE83KP", avatar: "김", gradient: "from-violet-400 to-purple-500" },
  { name: "박준호", email: "junho@example.com", code: "JH47NR", avatar: "박", gradient: "from-cyan-400 to-blue-500" },
];

function loadAddedFriends(): string[] {
  try {
    const json = localStorage.getItem("addedFriends");
    return json ? JSON.parse(json) : [];
  } catch { return []; }
}
function saveAddedFriends(friends: string[]) {
  localStorage.setItem("addedFriends", JSON.stringify(friends));
}

// ── Find Friend Modal Component ─────────────────────────────────────────────
function FindFriendModal({
  onClose,
}: {
  onClose: () => void;
}) {
  const [query, setQuery] = useState("");
  const [searched, setSearched] = useState(false);
  const [results, setResults] = useState<MockUser[]>([]);
  const [addedFriends, setAddedFriends] = useState<string[]>(loadAddedFriends);
  const [justAdded, setJustAdded] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  const handleSearch = () => {
    const q = query.trim().toUpperCase();
    if (!q) return;
    setSearched(true);
    const found = MOCK_USERS.filter(
      (u) =>
        u.code.toUpperCase() === q ||
        u.email.toLowerCase() === query.trim().toLowerCase() ||
        u.name.includes(query.trim())
    );
    setResults(found.filter((u) => u.email !== "minj@example.com"));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSearch();
    }
  };

  const handleAddFriend = (user: MockUser) => {
    const updated = [...addedFriends, user.code];
    setAddedFriends(updated);
    saveAddedFriends(updated);
    setJustAdded(user.code);
    setTimeout(() => setJustAdded(null), 2000);
  };

  const isAlreadyAdded = (code: string) => addedFriends.includes(code);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    >
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <motion.div
        className="relative bg-white rounded-2xl shadow-2xl shadow-slate-300/50 border border-slate-200 w-[420px] overflow-hidden"
        initial={{ scale: 0.92, opacity: 0, y: 10 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 5 }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
              <Search className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <h3 className="text-slate-900" style={{ fontSize: "1rem" }}>
                친구 찾기
              </h3>
              <p className="text-slate-400 mt-0.5" style={{ fontSize: "0.72rem" }}>
                이메일 또는 개인 코드로 검색하세요
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search */}
        <div className="px-6 pb-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="flex-1 flex items-center gap-2 border border-slate-200 rounded-xl px-3 py-2 focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-100 transition-all">
              <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="이메일 또는 코드 입력"
                className="flex-1 outline-none text-slate-700 placeholder:text-slate-300 bg-transparent"
                style={{ fontSize: "0.82rem" }}
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={!query.trim()}
              className={`px-3 py-2 rounded-xl transition-colors shrink-0 ${
                query.trim()
                  ? "bg-blue-600 text-white hover:bg-blue-700"
                  : "bg-slate-100 text-slate-400 cursor-not-allowed"
              }`}
              style={{ fontSize: "0.78rem" }}
            >
              <Search className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Results */}
          <AnimatePresence mode="wait">
            {searched && results.length === 0 && (
              <motion.div
                key="empty"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center py-6 text-center"
              >
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                  <UserPlus className="w-5 h-5 text-slate-300" />
                </div>
                <p className="text-slate-400" style={{ fontSize: "0.82rem" }}>
                  검색 결과가 없습니다
                </p>
                <p className="text-slate-300 mt-1" style={{ fontSize: "0.72rem" }}>
                  이메일 또는 6자리 코드를 정확히 입력해 주세요
                </p>
              </motion.div>
            )}

            {results.length > 0 && (
              <motion.div
                key="results"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex flex-col gap-2"
              >
                <p className="text-slate-400 mb-1" style={{ fontSize: "0.72rem" }}>
                  {results.length}명을 찾았습니다
                </p>
                {results.map((user) => {
                  const added = isAlreadyAdded(user.code) || justAdded === user.code;
                  return (
                    <div
                      key={user.code}
                      className="flex items-center gap-3 px-3.5 py-3 bg-slate-50 border border-slate-200 rounded-xl"
                    >
                      <div
                        className={`w-9 h-9 rounded-full bg-gradient-to-br ${user.gradient} flex items-center justify-center text-white shrink-0`}
                        style={{ fontSize: "0.65rem" }}
                      >
                        {user.avatar}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-slate-800 truncate" style={{ fontSize: "0.82rem" }}>
                          {user.name}
                        </p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-slate-400 truncate" style={{ fontSize: "0.7rem" }}>
                            {user.email}
                          </span>
                          <span className="flex items-center gap-0.5 text-blue-400" style={{ fontSize: "0.65rem", fontFamily: "monospace" }}>
                            <Hash className="w-2 h-2" />
                            {user.code}
                          </span>
                        </div>
                      </div>
                      {added ? (
                        <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-50 text-emerald-600 shrink-0" style={{ fontSize: "0.72rem" }}>
                          <Check className="w-3 h-3" />
                          추가됨
                        </div>
                      ) : (
                        <button
                          onClick={() => handleAddFriend(user)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-colors shrink-0"
                          style={{ fontSize: "0.72rem" }}
                        >
                          <UserPlus className="w-3 h-3" />
                          친구 추가
                        </button>
                      )}
                    </div>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Hint when not searched yet */}
          {!searched && (
            <div className="flex flex-col items-center py-5 text-center">
              <div className="flex items-center gap-3 mb-3">
                <div className="px-2.5 py-1 bg-slate-100 rounded-lg">
                  <span className="text-slate-500" style={{ fontSize: "0.72rem" }}>이메일</span>
                </div>
                <span className="text-slate-300" style={{ fontSize: "0.72rem" }}>또는</span>
                <div className="px-2.5 py-1 bg-blue-50 rounded-lg">
                  <span className="text-blue-500" style={{ fontSize: "0.72rem", fontFamily: "monospace" }}>6자리 코드</span>
                </div>
              </div>
              <p className="text-slate-300" style={{ fontSize: "0.72rem" }}>
                프로필의 개인 코드를 공유하여 친구를 찾아보세요
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-2 px-6 pb-5 pt-2 justify-end border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 mt-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            style={{ fontSize: "0.82rem" }}
          >
            닫기
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}