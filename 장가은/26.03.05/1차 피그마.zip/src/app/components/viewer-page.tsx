import { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  SkipBack,
  SkipForward,
  Settings,
  ArrowLeft,
  Subtitles,
  SmileIcon,
  Vibrate,
  Heart,
  MessageCircle,
  Send,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

/* ── Types ── */

type CaptionItem = {
  id: number;
  time: string;
  emoji: string;
  label: string;
  type: "environmental" | "speech";
};

type VideoComment = {
  id: number;
  author: string;
  text: string;
  time: string;
};

type ReactionKey = "👍" | "❤️" | "😂" | "🔥" | "👏";
const REACTION_LIST: ReactionKey[] = ["👍", "❤️", "😂", "🔥", "👏"];

export type ViewerRouteState = {
  videoId: number;
  title: string;
  thumb: string;
  date: string;
  duration: string;
  durationSeconds: number;
  owner: string;
  ownerLabel: string;
  captions: CaptionItem[];
  comments: VideoComment[];
  reactions: Record<ReactionKey, number>;
  myReactions: ReactionKey[];
  liked: boolean;
};

const CAPTION_POSITIONS = [
  { left: "8%",  top: "15%" },
  { left: "52%", top: "22%" },
  { left: "12%", top: "58%" },
  { left: "58%", top: "48%" },
  { left: "28%", top: "32%" },
  { left: "68%", top: "62%" },
  { left: "18%", top: "42%" },
  { left: "48%", top: "68%" },
  { left: "38%", top: "18%" },
  { left: "72%", top: "35%" },
];

const AVATAR_COLORS: Record<string, string> = {
  "김지은": "from-violet-400 to-pink-400",
  "박준호": "from-emerald-400 to-teal-500",
  "박민준": "from-blue-400 to-blue-600",
  "나":     "from-blue-400 to-blue-600",
};

function fmt(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

/* ── Component ── */

export function ViewerPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const rs = location.state as ViewerRouteState | undefined;

  // playback
  const [playing, setPlaying] = useState(true);
  const [time, setTime] = useState(0);
  const [muted, setMuted] = useState(false);
  const [emojiOn, setEmojiOn] = useState(true);
  const [vibrationOn, setVibrationOn] = useState(true);
  const [shakeKey, setShakeKey] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // caption slots
  const [activeEnvSet, setActiveEnvSet] = useState<number[]>([0, 1]);
  const [speechIdx, setSpeechIdx] = useState(0);
  const [envCaptionIdx, setEnvCaptionIdx] = useState(0);
  const cycleRef = useRef(0);
  const videoRef = useRef<HTMLDivElement>(null);

  // sidebar
  const [panelOpen, setPanelOpen] = useState(true);
  const [fsPanelOpen, setFsPanelOpen] = useState(true);

  // social
  const [liked, setLiked] = useState(rs?.liked ?? false);
  const [comments, setComments] = useState<VideoComment[]>(rs?.comments ?? []);
  const [commentText, setCommentText] = useState("");
  const [reactions, setReactions] = useState<Record<ReactionKey, number>>(
    () => rs?.reactions ?? { "👍": 0, "❤️": 0, "😂": 0, "🔥": 0, "👏": 0 },
  );
  const [myReactions, setMyReactions] = useState<ReactionKey[]>(rs?.myReactions ?? []);

  const inputRef = useRef<HTMLInputElement>(null);
  const commentsEndRef = useRef<HTMLDivElement>(null);

  // redirect if no state
  useEffect(() => {
    if (!rs) navigate("/dashboard", { replace: true });
  }, [rs, navigate]);

  const TOTAL = rs?.durationSeconds ?? 138;
  const captions = rs?.captions ?? [];
  const envCaps = captions.filter(c => c.type === "environmental");
  const speechCaps = captions.filter(c => c.type === "speech");

  const activeEnvCaps = activeEnvSet
    .filter(i => i < envCaps.length)
    .map(i => ({ ...envCaps[i], posIdx: i }));
  const activeSpeech = speechCaps.length > 0 ? speechCaps[speechIdx % speechCaps.length] : null;

  // playback timer
  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setTime(prev => {
        if (prev >= TOTAL) { setPlaying(false); return TOTAL; }
        return prev + 0.5;
      });
    }, 500);
    return () => clearInterval(id);
  }, [playing, TOTAL]);

  // env caption rotation
  useEffect(() => {
    if (!playing || envCaps.length === 0) return;
    const maxShow = Math.min(3, envCaps.length);
    setActiveEnvSet(prev => {
      if (prev.length === 0 || prev.every(i => i >= envCaps.length)) {
        return Array.from({ length: maxShow }, (_, i) => i % envCaps.length);
      }
      return prev.slice(0, maxShow);
    });
    const id = setInterval(() => {
      cycleRef.current = (cycleRef.current + 1) % maxShow;
      setActiveEnvSet(prev => {
        const next = [...prev];
        const used = new Set(prev);
        let cand = (Math.max(...prev) + 1) % envCaps.length;
        let tries = 0;
        while (used.has(cand) && tries < envCaps.length) { cand = (cand + 1) % envCaps.length; tries++; }
        next[cycleRef.current % next.length] = cand;
        return next;
      });
      setEnvCaptionIdx(p => (p + 1) % envCaps.length);
    }, 2500);
    return () => clearInterval(id);
  }, [playing, envCaps.length]);

  // speech caption rotation
  useEffect(() => {
    if (!playing || speechCaps.length === 0) return;
    const id = setInterval(() => setSpeechIdx(p => (p + 1) % speechCaps.length), 4000);
    return () => clearInterval(id);
  }, [playing, speechCaps.length]);

  // shake trigger
  useEffect(() => {
    if (vibrationOn && playing) setShakeKey(k => k + 1);
  }, [envCaptionIdx, vibrationOn, playing]);

  // Fullscreen
  const toggleFullscreen = async () => {
    if (!isFullscreen) {
      const el = videoRef.current as any;
      if (el) {
        try {
          if (el.requestFullscreen) { await el.requestFullscreen(); setIsFullscreen(true); }
          else if (el.webkitRequestFullscreen) { el.webkitRequestFullscreen(); setIsFullscreen(true); }
        } catch { setIsFullscreen(true); }
      }
    } else {
      const doc = document as any;
      try {
        if (doc.exitFullscreen && doc.fullscreenElement) await doc.exitFullscreen();
        else if (doc.webkitExitFullscreen && doc.webkitFullscreenElement) doc.webkitExitFullscreen();
      } catch {}
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handler = () => {
      const doc = document as any;
      const isFs = doc.fullscreenElement === videoRef.current || doc.webkitFullscreenElement === videoRef.current;
      if (!isFs && (doc.fullscreenElement || doc.webkitFullscreenElement)) return;
      setIsFullscreen(isFs);
    };
    document.addEventListener("fullscreenchange", handler);
    document.addEventListener("webkitfullscreenchange", handler);
    return () => {
      document.removeEventListener("fullscreenchange", handler);
      document.removeEventListener("webkitfullscreenchange", handler);
    };
  }, []);

  const progress = (time / TOTAL) * 100;

  const sendComment = () => {
    const txt = commentText.trim();
    if (!txt) return;
    setComments(prev => [...prev, { id: Date.now(), author: "나", text: txt, time: "방금 전" }]);
    setCommentText("");
    setTimeout(() => {
      inputRef.current?.focus();
      commentsEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 50);
  };

  const toggleReaction = (emoji: ReactionKey) => {
    const has = myReactions.includes(emoji);
    setMyReactions(prev => has ? prev.filter(e => e !== emoji) : [...prev, emoji]);
    setReactions(prev => ({ ...prev, [emoji]: prev[emoji] + (has ? -1 : 1) }));
  };

  if (!rs) return null;

  /* ──────── RENDER ──────── */
  return (
    <div className="flex flex-col h-screen bg-[#f8f9fb] relative overflow-hidden" style={{ fontFamily: "'Inter', 'Noto Sans KR', sans-serif" }}>

      {/* ── Header ── */}
      <header className="flex items-center justify-between h-[54px] px-5 bg-white border-b border-slate-200/60 shrink-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 group">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-600 to-blue-500 flex items-center justify-center shadow-sm">
              <Subtitles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-slate-900" style={{ fontSize: "0.88rem", fontWeight: 600, letterSpacing: "-0.01em" }}>SoundSee</span>
          </button>
          <div className="w-px h-4 bg-slate-200 mx-1" />
          <button onClick={() => navigate("/dashboard")} className="flex items-center gap-1.5 text-slate-400 hover:text-slate-600 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span style={{ fontSize: "0.78rem", fontWeight: 450 }}>대시보드</span>
          </button>
        </div>

        {/* Like button in header */}
        <button
          onClick={() => setLiked(!liked)}
          className={`flex items-center gap-1.5 px-3.5 py-[7px] rounded-lg border transition-all ${liked ? "bg-red-50 border-red-100 text-red-500" : "bg-white border-slate-200/60 text-slate-400 hover:text-red-400"}`}
          style={{ fontSize: "0.8rem", fontWeight: 500 }}
        >
          <Heart className={`w-3.5 h-3.5 ${liked ? "fill-red-500" : ""}`} />
          좋아요
        </button>
      </header>

      {/* ── Main Content ── */}
      <div className="flex flex-1 overflow-hidden">

        {/* Video Player Area */}
        <div className="flex-1 flex flex-col min-w-0 p-5 gap-4">
          {/* Title row */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Subtitles className="w-4 h-4 text-blue-500" />
              <h1 className="text-slate-800" style={{ fontSize: "0.95rem", fontWeight: 600, letterSpacing: "-0.01em" }}>
                {rs.title}
              </h1>
            </div>
            <span className="text-slate-300">&middot;</span>
            <p className="text-slate-400" style={{ fontSize: "0.76rem", fontWeight: 400 }}>{rs.ownerLabel} &middot; {rs.date}</p>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100" style={{ fontSize: "0.65rem", fontWeight: 500 }}>
              <span className="w-1 h-1 rounded-full bg-emerald-500" />
              AI 자막 적용됨
            </span>
          </div>

          {/* Video player */}
          <div
            className={`relative bg-slate-950 rounded-xl overflow-hidden flex-1 min-h-[300px] ${
              isFullscreen ? "fullscreen-player" : "shadow-[0_1px_3px_rgba(0,0,0,0.08),0_8px_24px_rgba(0,0,0,0.06)]"
            }`}
            ref={videoRef}
          >
            <ImageWithFallback src={rs.thumb} alt={rs.title} className="w-full h-full object-cover opacity-90" />

            {/* Vibration shake */}
            <AnimatePresence>
              {vibrationOn && playing && activeEnvCaps.length > 0 && (
                <motion.div
                  key={`shk-${shakeKey}`}
                  className="absolute inset-0 pointer-events-none z-[5]"
                  initial={{ x: 0, y: 0 }}
                  animate={{ x: [0, -3, 3, -2, 2, -1, 1, 0], y: [0, 2, -2, 1, -1, 0.5, -0.5, 0] }}
                  transition={{ duration: 0.35, ease: "easeOut" }}
                >
                  <div className="w-full h-full border-2 border-orange-400/30 rounded-xl" />
                </motion.div>
              )}
            </AnimatePresence>

            {/* ── Fullscreen overlays ── */}
            {isFullscreen && (
              <>
                <div className="absolute top-0 left-0 right-0 h-28 bg-gradient-to-b from-black/50 to-transparent pointer-events-none z-10" />

                {/* Fullscreen comment panel */}
                <AnimatePresence initial={false}>
                  {fsPanelOpen ? (
                    <motion.div
                      key="fs-panel-open"
                      className="absolute top-5 right-5 bottom-28 w-[320px] bg-black/40 border border-white/[0.08] rounded-2xl flex flex-col z-40 overflow-hidden"
                      initial={{ x: 380, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      exit={{ x: 380, opacity: 0 }}
                      transition={{ type: "spring", damping: 28, stiffness: 220 }}
                    >
                      <div className="flex items-center justify-between px-4 py-4 border-b border-white/[0.06]">
                        <div className="flex items-center gap-2.5">
                          <MessageCircle className="w-4 h-4 text-blue-400" />
                          <span className="text-white/90" style={{ fontSize: "0.82rem", fontWeight: 500 }}>댓글</span>
                          <span className="text-white/30" style={{ fontSize: "0.7rem" }}>{comments.length}</span>
                        </div>
                        <button onClick={() => setFsPanelOpen(false)} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 text-white/40 hover:text-white/70 transition-colors">
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-3 custom-scrollbar">
                        {comments.length === 0 ? (
                          <div className="flex flex-col items-center justify-center py-10 text-white/20">
                            <MessageCircle className="w-7 h-7 mb-2" />
                            <p style={{ fontSize: "0.75rem" }}>아직 댓글이 없어요</p>
                          </div>
                        ) : (
                          comments.map(c => {
                            const grad = AVATAR_COLORS[c.author] ?? "from-amber-400 to-orange-500";
                            return (
                              <div key={c.id} className="flex gap-2.5">
                                <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white shrink-0`} style={{ fontSize: "0.4rem", fontWeight: 600 }}>
                                  {c.author.charAt(0)}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-baseline gap-1.5">
                                    <span className="text-white/80" style={{ fontSize: "0.72rem", fontWeight: 550 }}>{c.author}</span>
                                    <span className="text-white/20" style={{ fontSize: "0.6rem" }}>{c.time}</span>
                                  </div>
                                  <p className="text-white/60 mt-0.5" style={{ fontSize: "0.74rem", lineHeight: "1.45" }}>{c.text}</p>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="fs-panel-closed"
                      className="absolute top-1/2 right-3 -translate-y-1/2 z-40"
                      initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 16 }}
                    >
                      <button onClick={() => setFsPanelOpen(true)} className="group flex flex-col items-center gap-2.5 px-2.5 py-5 bg-black/40 border border-white/[0.08] rounded-xl text-white/40 hover:text-white/80 hover:bg-black/50 transition-all">
                        <ChevronLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5" />
                        <span style={{ fontSize: "0.6rem", writingMode: "vertical-lr", letterSpacing: "0.1em", fontWeight: 500 }}>COMMENTS</span>
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Fullscreen env captions */}
                <AnimatePresence>
                  {activeEnvCaps.map((cap, si) => {
                    const pos = CAPTION_POSITIONS[cap.posIdx % CAPTION_POSITIONS.length];
                    return (
                      <motion.div
                        key={`fs-ec-${cap.id}`}
                        className="absolute z-30 pointer-events-none"
                        style={{ left: pos.left, top: pos.top }}
                        initial={{ opacity: 0, scale: 0.7, y: 18 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.85, y: -10 }}
                        transition={{ duration: 0.4, ease: "easeOut", delay: si * 0.08 }}
                      >
                        {emojiOn ? (
                          <div className="relative">
                            <motion.div
                              className="absolute rounded-full bg-white/10"
                              animate={{ scale: [1, 1.5, 1], opacity: [0.4, 0, 0.4] }}
                              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                              style={{ width: 72, height: 72, top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}
                            />
                            <span style={{ fontSize: "3.2rem", filter: "drop-shadow(0 0 14px rgba(255,255,255,0.7)) drop-shadow(0 4px 10px rgba(0,0,0,0.9))" }}>
                              {cap.emoji}
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 px-4 py-2 bg-black/50 border border-white/15 rounded-2xl shadow-2xl">
                            <span style={{ fontSize: "1.4rem" }}>{cap.emoji}</span>
                            <span className="text-white" style={{ fontSize: "1rem", fontWeight: 500 }}>{cap.label}</span>
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </AnimatePresence>

                {/* Fullscreen speech caption */}
                <AnimatePresence>
                  {activeSpeech && (
                    <motion.div
                      key={`fs-sp-${speechIdx}`}
                      className="absolute bottom-36 left-1/2 -translate-x-1/2 z-30 pointer-events-none"
                      initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.3, ease: "easeOut" }}
                    >
                      <div className="bg-black/70 text-white px-6 py-3 rounded-xl shadow-2xl border border-white/[0.08]">
                        <span style={{ fontSize: "1.5rem", lineHeight: "1.6", fontWeight: 500 }}>{activeSpeech.label}</span>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </>
            )}

            {/* ── Normal mode captions ── */}
            {!isFullscreen && (
              <AnimatePresence>
                {activeEnvCaps.map((cap, si) => {
                  const pos = CAPTION_POSITIONS[cap.posIdx % CAPTION_POSITIONS.length];
                  return (
                    <motion.div
                      key={`nm-ec-${cap.id}`}
                      className="absolute pointer-events-none"
                      style={{ left: pos.left, top: pos.top }}
                      initial={{ opacity: 0, scale: 0.75, y: 12 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.85, y: -8 }}
                      transition={{ duration: 0.35, ease: "easeOut", delay: si * 0.06 }}
                    >
                      {emojiOn ? (
                        <span style={{ fontSize: "2rem", filter: "drop-shadow(0 0 8px rgba(255,255,255,0.5)) drop-shadow(0 2px 4px rgba(0,0,0,0.8))" }}>
                          {cap.emoji}
                        </span>
                      ) : (
                        <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-black/45 border border-white/15 rounded-xl shadow-lg">
                          <span style={{ fontSize: "0.95rem" }}>{cap.emoji}</span>
                          <span className="text-white" style={{ fontSize: "0.7rem", fontWeight: 500 }}>{cap.label}</span>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            )}

            {/* Normal mode speech caption */}
            {!isFullscreen && (
              <AnimatePresence mode="wait">
                {activeSpeech && (
                  <motion.div
                    key={`sp-${speechIdx}`}
                    className="absolute bottom-16 left-1/2 -translate-x-1/2 pointer-events-none"
                    initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <div className="bg-black/70 text-white px-4 py-2 rounded-lg shadow-lg border border-white/[0.08]">
                      <span style={{ fontSize: "1rem", lineHeight: "1.5", fontWeight: 500 }}>{activeSpeech.label}</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            )}

            {/* Paused overlay */}
            <AnimatePresence>
              {!playing && (
                <motion.div
                  className="absolute inset-0 flex items-center justify-center bg-black/10"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                >
                  <button
                    onClick={() => { setPlaying(true); if (time >= TOTAL) setTime(0); }}
                    className="w-16 h-16 rounded-full bg-white/95 flex items-center justify-center hover:bg-white transition-all shadow-[0_4px_24px_rgba(0,0,0,0.15)] hover:scale-105 active:scale-95"
                  >
                    <Play className="w-6 h-6 text-slate-800 ml-0.5" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ── Control bar ── */}
            <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent ${
              isFullscreen ? "px-8 pt-20 pb-5 z-50" : "px-4 pt-12 pb-3"
            }`}>
              {/* Seek bar */}
              <div
                className={`relative ${isFullscreen ? "h-[6px]" : "h-1"} bg-white/15 rounded-full mb-3 cursor-pointer group`}
                onClick={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  setTime(Math.round(((e.clientX - r.left) / r.width) * TOTAL));
                }}
              >
                <div className="h-full bg-blue-500 rounded-full relative" style={{ width: `${progress}%` }}>
                  <div className={`absolute right-0 top-1/2 -translate-y-1/2 ${isFullscreen ? "w-4 h-4" : "w-2.5 h-2.5"} rounded-full bg-white scale-0 group-hover:scale-100 transition-transform shadow-md`} />
                </div>
                {captions.map(c => {
                  const parts = c.time.split(":").map(Number);
                  const pct = ((parts[0] * 60 + parts[1]) / TOTAL) * 100;
                  return <div key={c.id} className="absolute top-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-white/40" style={{ left: `${pct}%` }} />;
                })}
              </div>

              {/* Controls row */}
              <div className="flex items-center justify-between">
                <div className={`flex items-center ${isFullscreen ? "gap-5" : "gap-2"}`}>
                  <div className={`flex items-center ${isFullscreen ? "gap-3" : "gap-1.5"}`}>
                    <button onClick={() => setTime(Math.max(0, time - 10))} className="text-white/50 hover:text-white transition-colors p-1">
                      <SkipBack className={isFullscreen ? "w-5 h-5" : "w-3.5 h-3.5"} />
                    </button>
                    <button
                      onClick={() => { if (time >= TOTAL) setTime(0); setPlaying(!playing); }}
                      className={`${isFullscreen ? "w-10 h-10" : "w-8 h-8"} rounded-full bg-white text-slate-900 flex items-center justify-center transition-all hover:scale-105 active:scale-95 shadow-sm`}
                    >
                      {playing ? <Pause className={isFullscreen ? "w-5 h-5" : "w-3.5 h-3.5"} /> : <Play className={`${isFullscreen ? "w-5 h-5 ml-0.5" : "w-3.5 h-3.5 ml-0.5"}`} />}
                    </button>
                    <button onClick={() => setTime(Math.min(TOTAL, time + 10))} className="text-white/50 hover:text-white transition-colors p-1">
                      <SkipForward className={isFullscreen ? "w-5 h-5" : "w-3.5 h-3.5"} />
                    </button>
                  </div>
                  <button onClick={() => setMuted(!muted)} className="text-white/50 hover:text-white transition-colors p-1">
                    {muted ? <VolumeX className={isFullscreen ? "w-5 h-5" : "w-3.5 h-3.5"} /> : <Volume2 className={isFullscreen ? "w-5 h-5" : "w-3.5 h-3.5"} />}
                  </button>
                  <span className="text-white/40 tabular-nums" style={{ fontSize: isFullscreen ? "0.82rem" : "0.7rem", fontWeight: 400 }}>
                    {fmt(time)} / {fmt(TOTAL)}
                  </span>
                </div>

                <div className={`flex items-center ${isFullscreen ? "gap-2" : "gap-1"}`}>
                  {/* Emoji toggle */}
                  <div className="relative group/emoji">
                    <button
                      onClick={() => setEmojiOn(!emojiOn)}
                      className={`relative ${isFullscreen ? "w-9 h-9" : "w-7 h-7"} rounded-lg flex items-center justify-center transition-all ${
                        emojiOn
                          ? "bg-amber-500/20 text-amber-300 hover:bg-amber-500/30"
                          : "text-white/35 hover:text-white/60 hover:bg-white/[0.06]"
                      }`}
                    >
                      <SmileIcon className={isFullscreen ? "w-[18px] h-[18px]" : "w-3.5 h-3.5"} />
                      {emojiOn && (
                        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-amber-400 rounded-full border border-black/50" />
                      )}
                    </button>
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black/80 text-white rounded-md whitespace-nowrap opacity-0 group-hover/emoji:opacity-100 pointer-events-none transition-opacity" style={{ fontSize: "0.7rem" }}>
                      이모티콘 {emojiOn ? "ON" : "OFF"}
                    </div>
                  </div>

                  {/* Vibration toggle */}
                  <div className="relative group/vib">
                    <button
                      onClick={() => setVibrationOn(!vibrationOn)}
                      className={`relative ${isFullscreen ? "w-9 h-9" : "w-7 h-7"} rounded-lg flex items-center justify-center transition-all ${
                        vibrationOn
                          ? "bg-orange-500/20 text-orange-300 hover:bg-orange-500/30"
                          : "text-white/35 hover:text-white/60 hover:bg-white/[0.06]"
                      }`}
                    >
                      <Vibrate className={isFullscreen ? "w-[18px] h-[18px]" : "w-3.5 h-3.5"} />
                      {vibrationOn && (
                        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-orange-400 rounded-full border border-black/50" />
                      )}
                    </button>
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black/80 text-white rounded-md whitespace-nowrap opacity-0 group-hover/vib:opacity-100 pointer-events-none transition-opacity" style={{ fontSize: "0.7rem" }}>
                      진동 {vibrationOn ? "ON" : "OFF"}
                    </div>
                  </div>

                  <div className="w-px h-4 bg-white/10 mx-0.5" />

                  <button className="text-white/40 hover:text-white/70 transition-colors p-1">
                    <Settings className={isFullscreen ? "w-[18px] h-[18px]" : "w-3.5 h-3.5"} />
                  </button>
                  <button className="text-white/40 hover:text-white/70 transition-colors p-1" onClick={toggleFullscreen}>
                    {isFullscreen ? <Minimize2 className="w-[18px] h-[18px]" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ── Reactions bar (below video) ── */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              {REACTION_LIST.map(emoji => {
                const cnt = reactions[emoji];
                const on = myReactions.includes(emoji);
                return (
                  <button
                    key={emoji}
                    onClick={() => toggleReaction(emoji)}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border transition-all ${on ? "bg-blue-50 border-blue-200 text-blue-600" : "bg-white border-slate-200/60 text-slate-400 hover:border-slate-300 hover:text-slate-500"} shadow-[0_1px_2px_rgba(0,0,0,0.04)]`}
                    style={{ fontSize: "0.76rem" }}
                  >
                    <span>{emoji}</span>
                    {cnt > 0 && <span style={{ fontWeight: 500 }}>{cnt}</span>}
                  </button>
                );
              })}
            </div>
            <div className="flex-1" />
            <span className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-50 border border-blue-100/60 text-blue-500" style={{ fontSize: "0.68rem", fontWeight: 500 }}>
              <Subtitles className="w-3 h-3" />
              환경음 {envCaps.length} &middot; 대화 {speechCaps.length}
            </span>
          </div>
        </div>

        {/* ── Comments Sidebar ── */}
        <AnimatePresence initial={false}>
          {panelOpen ? (
            <motion.aside
              key="comment-panel-open"
              className="w-[284px] bg-white border-l border-slate-200/60 flex flex-col shrink-0"
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 284, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.22 }}
            >
              {/* Header */}
              <div className="flex items-center justify-between px-4 h-[54px] border-b border-slate-100/80 shrink-0">
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-blue-500" />
                  <span className="text-slate-700" style={{ fontSize: "0.82rem", fontWeight: 600 }}>댓글</span>
                  <span className="bg-slate-100 text-slate-400 rounded-md px-1.5 py-[1px]" style={{ fontSize: "0.6rem", fontWeight: 500 }}>
                    {comments.length}
                  </span>
                </div>
                <button onClick={() => setPanelOpen(false)} className="w-6 h-6 flex items-center justify-center rounded-md hover:bg-slate-100 text-slate-400 transition-colors">
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Comment input */}
              <div className="px-3 py-3 border-b border-slate-50 flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white shrink-0" style={{ fontSize: "0.42rem", fontWeight: 600 }}>나</div>
                <input
                  ref={inputRef}
                  type="text"
                  value={commentText}
                  onChange={e => setCommentText(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); sendComment(); } }}
                  placeholder="댓글 남기기..."
                  className="flex-1 min-w-0 bg-slate-50 border border-slate-100 rounded-lg px-2.5 py-1.5 text-slate-700 placeholder-slate-300 outline-none focus:border-blue-200 focus:ring-2 focus:ring-blue-100 transition-all"
                  style={{ fontSize: "0.76rem" }}
                />
                <button
                  onClick={sendComment}
                  disabled={!commentText.trim()}
                  className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-all ${commentText.trim() ? "bg-blue-500 text-white hover:bg-blue-600" : "bg-slate-100 text-slate-300"}`}
                >
                  <Send className="w-3 h-3" />
                </button>
              </div>

              {/* Comment list */}
              <div className="flex-1 overflow-y-auto py-2 px-3 space-y-3">
                {comments.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-14 text-slate-300">
                    <MessageCircle className="w-8 h-8 mb-2" />
                    <p style={{ fontSize: "0.78rem" }}>아직 댓글이 없어요</p>
                    <p className="mt-1 text-slate-300/70" style={{ fontSize: "0.68rem" }}>첫 번째 댓글을 남겨보세요!</p>
                  </div>
                ) : (
                  comments.map(c => {
                    const grad = AVATAR_COLORS[c.author] ?? "from-amber-400 to-orange-500";
                    return (
                      <motion.div
                        key={c.id}
                        className="flex gap-2.5"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className={`w-7 h-7 rounded-full bg-gradient-to-br ${grad} flex items-center justify-center text-white shrink-0`} style={{ fontSize: "0.42rem", fontWeight: 600 }}>
                          {c.author.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-baseline gap-1.5">
                            <span className="text-slate-800" style={{ fontSize: "0.76rem", fontWeight: 560 }}>{c.author}</span>
                            <span className="text-slate-300" style={{ fontSize: "0.6rem" }}>{c.time}</span>
                          </div>
                          <p className="text-slate-600 mt-0.5" style={{ fontSize: "0.76rem", lineHeight: "1.5" }}>{c.text}</p>
                        </div>
                      </motion.div>
                    );
                  })
                )}
                <div ref={commentsEndRef} />
              </div>
            </motion.aside>
          ) : (
            <motion.div
              key="comment-panel-closed"
              className="flex items-start pt-4 border-l border-slate-200/60 bg-white shrink-0"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            >
              <button
                onClick={() => setPanelOpen(true)}
                className="flex flex-col items-center gap-2 px-2 py-3 text-slate-300 hover:text-blue-500 hover:bg-blue-50/50 rounded-l-lg transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span style={{ fontSize: "0.6rem", writingMode: "vertical-lr", letterSpacing: "0.05em", fontWeight: 500 }}>
                  댓글
                </span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
