
  # 디자인 수정

  This is a code bundle for 디자인 수정. The original project is available at https://www.figma.com/design/61bMIZhWcBhzB7PHhFdZCg/%EB%94%94%EC%9E%90%EC%9D%B8-%EC%88%98%EC%A0%95.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  